package com.alibaba.test.p3c;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @author caikang
 * @date 2019/09/29
 */
public class LockTest {
    private Lock lock = new ReentrantLock();

    public void testLock() {
        try {
            lock.lockInterruptibly();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        try {
            lock.lock();
            try {

            } finally {
            }
        } catch (Exception e) {

        } finally {
            lock.unlock();
        }
    }
}