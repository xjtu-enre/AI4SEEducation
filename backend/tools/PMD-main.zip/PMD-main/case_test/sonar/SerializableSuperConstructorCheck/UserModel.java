package com.ai.gcrm.usermodel.sys;

import java.io.Serializable;

import xframe.core.taglib.sql.SqlAttr;
import xframe.core.usermodel.BaseSearchModel;

@SuppressWarnings("serial")
public class UserModel extends BaseSearchModel implements Serializable{

	/**
	 * 属性使用@SqlAttr为查询数据库的字段，column="数据库字段名"
	 * 属性值为自动组装语句的条件 ：=
	 */
	@SqlAttr(column="user_login_name")
	private String userLoginName;
	@SqlAttr(column="mss_code")
	private String mssCode;

	private String password;
	
	@SqlAttr(column="employee_id")
//	private String empoyleeId;
	private String employeeId;
	
	@SqlAttr(column="user_id")
	private String userId;
	
	@SqlAttr(column="dept_id")
	private String deptId;
	
	@SqlAttr(column="dept_ptype")
	private String deptPtype;
	
	@SqlAttr(column="dept_type")
	private String deptType;
	
	@SqlAttr
	private String status;
	
	@SqlAttr(column="mobile_phone")
	private String mobilePhone;
	
	@SqlAttr(column="user_code")
	private String userCode;
	
	@SqlAttr(column="user_name")
	private String userName;
	
	@SqlAttr(column="city_code")
	private String cityCode;
	
	@SqlAttr(column="county_code")
	private String countyCode;
	
	private String userIdStr;
	
	private String userLevel;
	
	//验证码
	private String validateCode;
	
	//明文密码
	private String noMd5Pwd;
	
	//确认密码
	private String realPwd;
	
	//当前角色
	private Long currentRoleId;
	
	//登录方式   1帐号登陆 2 扫码登陆
    private String loginMode; 
    
    //扫码成功的uuid
    private String QRCodeUuid;
    
	//是否客户端登录，是=true， 否=false
	private Boolean isClient = false;
	
	//是否联通员工
	@SqlAttr(column="emp_yn")
	private String empYn;
	
	private String zbCodeStr;
	
	private String zbCode;
	
	private String exZbCodeStr;
	
	private String agentCodeStr;
	
	private String chnlKindId;//总部渠道三级类型
	
	private String localKindId;//总部渠道四级类型编码
	
	private String zbType;
	
	private String osType;
	
	public String getOsType() {
		return osType;
	}
	public void setOsType(String osType) {
		this.osType = osType;
	}
	public String getQRCodeUuid() {
		return QRCodeUuid;
	}
	public void setQRCodeUuid(String qRCodeUuid) {
		QRCodeUuid = qRCodeUuid;
	}
	public String getLoginMode() {
		return loginMode;
	}
	public void setLoginMode(String loginMode) {
		this.loginMode = loginMode;
	}
	
	public String getEmpYn() {
		return empYn;
	}
	public void setEmpYn(String empYn) {
		this.empYn = empYn;
	}		
	public String getUserLoginName() {
		return userLoginName;
	}
	public void setUserLoginName(String userLoginName) {
		this.userLoginName = userLoginName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
//	public String getEmpoyleeId() {
//		return empoyleeId;
//	}
//	public void setEmpoyleeId(String empoyleeId) {
//		this.empoyleeId = empoyleeId;
//	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDeptType() {
		return deptType;
	}
	public void setDeptType(String deptType) {
		this.deptType = deptType;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCityCode() {
		return cityCode;
	}
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}
	public String getCountyCode() {
		return countyCode;
	}
	public void setCountyCode(String countyCode) {
		this.countyCode = countyCode;
	}
	public String getUserIdStr() {
		return userIdStr;
	}
	public void setUserIdStr(String userIdStr) {
		this.userIdStr = userIdStr;
	}
	public String getUserLevel() {
		return userLevel;
	}
	public void setUserLevel(String userLevel) {
		this.userLevel = userLevel;
	}
	public String getDeptPtype() {
		return deptPtype;
	}
	public void setDeptPtype(String deptPtype) {
		this.deptPtype = deptPtype;
	}
	public String getValidateCode() {
		return validateCode;
	}
	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}
	public String getNoMd5Pwd() {
		return noMd5Pwd;
	}
	public void setNoMd5Pwd(String noMd5Pwd) {
		this.noMd5Pwd = noMd5Pwd;
	}
	public String getRealPwd() {
		return realPwd;
	}
	public void setRealPwd(String realPwd) {
		this.realPwd = realPwd;
	}
	public Boolean getIsClient() {
		return isClient;
	}
	public void setIsClient(Boolean isClient) {
		this.isClient = isClient;
	}
	public Long getCurrentRoleId() {
		return currentRoleId;
	}
	public void setCurrentRoleId(Long currentRoleId) {
		this.currentRoleId = currentRoleId;
	}
	public String getZbCodeStr() {
		return zbCodeStr;
	}
	public void setZbCodeStr(String zbCodeStr) {
		this.zbCodeStr = zbCodeStr;
	}
	public String getZbCode() {
		return zbCode;
	}
	public void setZbCode(String zbCode) {
		this.zbCode = zbCode;
	}
	public String getExZbCodeStr() {
		return exZbCodeStr;
	}
	public void setExZbCodeStr(String exZbCodeStr) {
		this.exZbCodeStr = exZbCodeStr;
	}
	public String getAgentCodeStr() {
		return agentCodeStr;
	}
	public void setAgentCodeStr(String agentCodeStr) {
		this.agentCodeStr = agentCodeStr;
	}
	public String getChnlKindId() {
		return chnlKindId;
	}
	public void setChnlKindId(String chnlKindId) {
		this.chnlKindId = chnlKindId;
	}
	public String getLocalKindId() {
		return localKindId;
	}
	public void setLocalKindId(String localKindId) {
		this.localKindId = localKindId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getZbType() {
		return zbType;
	}
	public void setZbType(String zbType) {
		this.zbType = zbType;
	}


	public String getMssCode() {
		return mssCode;
	}

	public void setMssCode(String mssCode) {
		this.mssCode = mssCode;
	}
}