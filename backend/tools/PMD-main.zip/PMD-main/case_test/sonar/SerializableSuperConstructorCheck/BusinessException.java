package com.ai.utils.Exception;

import java.io.Serializable;

public class BusinessException extends Exception implements Serializable {
	private static final long serialVersionUID = -8248090155724252769L;
	private String errorCode;
	/**
	 * add by sunyou 2015/06/01 
	 * 存放自定义错误信息，Exception中message属性应用于存放异常堆栈信息
	 */
	private String errorMsg;

	public BusinessException(String message, String code) {
		super(message);
		this.errorCode = code;
	}

	public String getErrorCode() {
		return errorCode;
	}
	
	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * 功能描述：添加具体异常信息
	 * @author sunyou
	 * @createDate 2015年6月1日
	 * @param errCode
	 * @param errMsg
	 * @param message
	 */
	public BusinessException(String errCode,String errMsg,String message){
		this(message,errCode);
		this.setErrorMsg(errMsg);
	}
}
