/**
 * MappException.java	  V1.0   May 16, 2011 3:22:48 PM
 *
 * Copyright 2011 AsiaInfo Linkage, All rights reserved.
 *
 * Modification history(By    Time    Reason):
 * 
 * Description:
 */

package com.ai.utils.Exception;

import java.io.Serializable;


/**
 * 功能描述：Mapp的异常信息
 *
 * @author  余根宁
 *
 * <p>修改历史：(修改人，修改时间，修改原因/内容)</p>
 */
public class MappException extends Exception implements Serializable {
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1841068542210156379L;
    
    /**
     * 异常代码
     */
    private String errCode;
    
    /**
     * 构造函数：
     *
     */
    public MappException() {

    }
    
    /**
     * 构造函数：
     *
     * @param message
     */
    public MappException(String message) {

        super(message);
    }
    
    /**
     * 构造函数：
     *
     * @param cause
     */
    public MappException(Throwable cause) {

        super(cause);
    }
    
    /**
     * 构造函数：
     *
     * @param message
     * @param cause
     */
    public MappException(String message, Throwable cause) {

        super(message, cause);
    }
    
    /**
     * 
     * 构造函数：通过异常代码和异常信息构造异常类
     *
     * @param exCode
     * @param message
     */
    public MappException(String exCode,String message){
        super(message);
        this.setErrCode(exCode);
    }

    
    /**
     * @return the errCode
     */
    public String getErrCode() {
    
        return errCode;
    }

    
    /**
     * @param errCode the errCode to set
     */
    public void setErrCode(String errCode) {
    
        this.errCode = errCode;
    }

    
    
}
