package com.dtt.sett.controller.sttl;

import java.util.Map;
import com.dtt.sett.settle.bean.SettlBasicResponse;
import com.dtt.sett.settle.bean.SettleAccount;
import com.dtt.sett.settle.createupdater.SettleAccountCreateUpdaterServicePrx;
import com.dtt.sett.settle.createupdater.SettleAccountCreateUpdaterServicePrxHelper;
import com.dtt.sett.settle.query.SettleAccountQueryServicePrx;
import com.dtt.sett.settle.query.SettleAccountQueryServicePrxHelper;

public class SettleCommonServiceImplClient {

	//自动创建结算单
	public static SettlBasicResponse settleAccountAutoCreateService() {
		int status = 0;
		Ice.Communicator ic = null;
		try {
			// 初始化通信器
			ic = Ice.Util.initialize();
			// 传入远程服务单元的名称、网络协议、IP以及端口，构造一个Proxy对象
			Ice.ObjectPrx base = ic.stringToProxy("SettleAccountCreateUpdaterService:default -p 10002");
			// 通过checkedCast向下转型，获取MyService接口的远程，并同时检测根据传入的名称获取服务单元是否OnlineBook的代理接口，如果不是则返回null对象
			SettleAccountCreateUpdaterServicePrx proxy = SettleAccountCreateUpdaterServicePrxHelper.uncheckedCast(base);
			if (proxy == null) {
				throw new Error("Invalid proxy");
			}
			// 调用服务方法
			SettlBasicResponse res = proxy.autoCreateSettleAccountByChinaUnicom();
			return res;
		} catch (Exception e) {
			e.printStackTrace();
			status = 1;
		} finally {
			if (ic != null) {
				ic.destroy();
			}
		}
		System.exit(status);
		return null;
	}

	/**
	 * 内部商城自动创建结算单
	 * @return
	 */
	public static SettlBasicResponse settleAccountAutoCreateServiceByEmall() {
		int status = 0;
		Ice.Communicator ic = null;
		try {
			// 初始化通信器
			ic = Ice.Util.initialize();
			// 传入远程服务单元的名称、网络协议、IP以及端口，构造一个Proxy对象
			Ice.ObjectPrx base = ic.stringToProxy("SettleAccountCreateUpdaterService:default -p 10002");
			// 通过checkedCast向下转型，获取MyService接口的远程，并同时检测根据传入的名称获取服务单元是否OnlineBook的代理接口，如果不是则返回null对象
			SettleAccountCreateUpdaterServicePrx proxy = SettleAccountCreateUpdaterServicePrxHelper.uncheckedCast(base);
			if (proxy == null) {
				throw new Error("Invalid proxy");
			}
			// 调用服务方法
			SettlBasicResponse res = proxy.autoCreateSettleAccountByEmall();
			return res;
		} catch (Exception e) {
			e.printStackTrace();
			status = 1;
		} finally {
			if (ic != null) {
				ic.destroy();
			}
		}
		System.exit(status);
		return null;
	}
	
	/**
     * 合作方查询
     * @param condiditon：查询条件
     * @return
     */
    public static SettlBasicResponse querySettlePartner(Map<String,String> vars){
		int status = 0;
		Ice.Communicator ic = null;
		try {
			// 初始化通信器
			ic = Ice.Util.initialize();
			// 传入远程服务单元的名称、网络协议、IP以及端口，构造一个Proxy对象
			Ice.ObjectPrx base = ic.stringToProxy("SettleAccountQueryService:default -p 10002");
			// 通过checkedCast向下转型，获取MyService接口的远程，并同时检测根据传入的名称获取服务单元是否OnlineBook的代理接口，如果不是则返回null对象
			SettleAccountQueryServicePrx proxy = SettleAccountQueryServicePrxHelper.uncheckedCast(base);
			if (proxy == null) {
				throw new Error("Invalid proxy");
			}
			// 调用服务方法
			SettlBasicResponse res = proxy.queryListSettlePartner(vars);
			return res;
		} catch (Exception e) {
			e.printStackTrace();
			status = 1;
		} finally {
			if (ic != null) {
				ic.destroy();
			}
		}
		System.exit(status);
		return null;
    }
}
