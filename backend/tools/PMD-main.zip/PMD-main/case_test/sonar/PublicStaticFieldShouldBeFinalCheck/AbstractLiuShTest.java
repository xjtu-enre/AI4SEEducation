package com.union.uflow.wtl.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.AbstractTransactionalDataSourceSpringContextTests;

/**
 * 测试驱动类
 * 
 * @author liuSh
 * @date 2010-6-10
 */
public class AbstractLiuShTest extends
		AbstractTransactionalDataSourceSpringContextTests {
	protected transient final Log log = LogFactory.getLog(getClass());
	ApplicationContext applicationContext;
	public static AbstractLiuShTest instance = null;

	public static synchronized AbstractLiuShTest getInstance() {
		if (instance == null)
			instance = new AbstractLiuShTest();
		return instance;
	}

	public String[] getConfigLocations() {
		setAutowireMode(AUTOWIRE_BY_NAME);
		return new String[] { "classpath:applicationContext.xml",
				"classpath:applicationContext-*.xml" };
	}

	public ApplicationContext getContext(String[] filePath) {
		return new ClassPathXmlApplicationContext(filePath);
	}

	public void doCommit() {
		setComplete();
	}

}