package com.dtt.sett.acc.weberpservice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dtt.sett.acc.accounting.AccCommonService;
import com.dtt.sett.acc.accounting.AccWebErpService;
import com.dtt.sett.acc.helper.AccCommonHelper;
import com.dtt.sett.acc.utils.AccConstantUtil;
import com.dtt.sett.acc.utils.AccEnumUtil;
import com.dtt.sett.acc.utils.AccRuleSqlUtil;
import com.dtt.sett.acc.utils.AccWebErpSqlUtil;
import com.dtt.sett.common.GeneralServiceResponse;
import com.dtt.sett.common.SMPEnumServicePrx;
import com.dtt.sett.common.SMPWriteLogRequest;
import com.dtt.sett.cons.innerquery.service.ConsInnerQueryServicePrx;
import com.dtt.sett.framework.constant.SMPEnumTypeCode;
import com.dtt.sett.framework.dao.BaseDaoUtil;
import com.dtt.sett.framework.dao.LogicDB;
import com.dtt.sett.framework.exception.SMPException;
import com.dtt.sett.framework.utils.DataUtil;
import com.dtt.sett.framework.utils.acc.SMPAccLogServiceUtil;
import com.dtt.sett.framework.utils.pay.ShareIdUtil;
import com.dtt.sett.invc.bean.InvcBasicResponse;
import com.dtt.sett.invc.bean.InvcSysUser;
import com.dtt.sett.invc.invcTicketService.InvcTicketManageServicePrx;
import com.dtt.sett.invc.invcquery.InvcUpdateBillDataServicePrx;
import com.dtt.sett.invc.visualization.InvoiceVisualizationServicePrx;
import com.dtt.sett.pay.bean.BasicPayResponse;
import com.dtt.sett.pay.bean.PaySysUser;
import com.dtt.sett.pay.service.processservice.PaymentProcessUpdaterServicePrx;
import com.dtt.sett.sys.bean.SysUser;

import Ice.Current;
import io.mycat.ice.utils.ICEClientUtil;
import io.mycat.ice.utils.SystemProperties;

public class AccWebERPService {
	/**
	 * 日志
	 */
	private Logger logger = LoggerFactory.getLogger(AccRuleSqlUtil.class);
	/**
	 * 接口业务处理类
	 */
	private static AccCommonWebService accComWebService=new AccCommonWebService();

/************************************内部私有方法区*****************************************************/

	/**
	 * 实现功能：查询状态为待传总账接口的数据
	 * 数据来源分为两部分：付款模块汇总凭证表、发票模块汇总凭证表
	 * @param queryVhSql 汇总总账凭证信息sql
	 * @param sysUser 用户
	 * @param res 基础服务应答对象
	 * @return GeneralServiceResponse
	 */
	public GeneralServiceResponse getInfos(String queryVhSql,List<Object> vhGroupValues,SysUser sysUser,GeneralServiceResponse res,String category) {
		AccWebErpService webErpService = new AccWebErpService();	//工具类
		JSONObject result = new JSONObject();
		AccCommonService commonService = new AccCommonService();
		//获取付款模块汇总总账凭证信息
		String queryVhSqlPay = queryVhSql;
//		JSONArray pay = webErpService.execQuerySql(queryVhSqlPay.replace("?l","t_sac_payment_acc_sum_vou_l")
//				.replace("?h","t_sac_payment_acc_sum_vou_h"),LogicDB.PAY_DB);
		JSONArray pay =
				commonService.execQuerySql(LogicDB.PAY_DB,queryVhSqlPay.replace("?l","t_sac_payment_acc_sum_vou_l")
						.replace("?h","t_sac_payment_acc_sum_vou_h"),null,vhGroupValues,null).getJSONArray("rows");
		//获取发票模块汇总总账凭证信息
		String queryVhSqlBL = queryVhSql;
//		JSONArray inv = webErpService.execQuerySql(queryVhSqlBL.replace("?l","t_sac_billing_acc_sum_vou_l")
//				.replace("?h","t_sac_billing_acc_sum_vou_h"),LogicDB.INVC_DB);
		JSONArray inv =
				commonService.execQuerySql(LogicDB.INVC_DB,queryVhSqlBL.replace("?l","t_sac_billing_acc_sum_vou_l")
						.replace("?h","t_sac_billing_acc_sum_vou_h"),null,vhGroupValues,null).getJSONArray("rows");
		//ERP-3217:获取应付票据汇总总账凭证信息
		String queryVhSqlBill = queryVhSql;
//		JSONArray bill = webErpService.execQuerySql(queryVhSqlBill.replace("?l","t_sac_payment_bill_sum_vou_l")
//				.replace("?h","t_sac_payment_bill_sum_vou_h"),LogicDB.PAY_DB);
		JSONArray bill =
				commonService.execQuerySql(LogicDB.PAY_DB,queryVhSqlBill.replace("?l","t_sac_payment_bill_sum_vou_l")
						.replace("?h","t_sac_payment_bill_sum_vou_h"),null,vhGroupValues,null).getJSONArray("rows");
		//设置返回值
		if(CollectionUtils.isEmpty(pay) && CollectionUtils.isEmpty(inv) && CollectionUtils.isEmpty(bill)){
			res.isSuccess = false;
			res.message = "满足传送总账接口的数据为空！";
		}else{
			//更新状态导入中
			updateSummaryImporting(pay,inv,bill,sysUser);

			if(!CollectionUtils.isEmpty(pay)){
				//ERP-3247财务核算优化——发票及付款核算增加总金额校验，规避风险 add by yanyang 2019-05-28 end
				if(AccEnumUtil.EXCHANGE_MARGIN.getValue().equals(category)) {
					result.put(AccConstantUtil.CHANGEPAY, setResult(pay));//处理个别字段的值
				} else {
					//ERP-3247财务核算优化——发票及付款核算增加总金额校验，规避风险 add by yanyang 2019-05-28 begin
					JSONArray successArray = accComWebService.verifyPayGLInterfaceAmount(pay,sysUser);
					result.put(AccConstantUtil.PAY, setResult(successArray));//处理个别字段的值
				}
			}
			if(!CollectionUtils.isEmpty(inv)){
				//ERP-4490发票总账凭证金额校验，规避风险 add by yanyang 2021-11-05 begin
				JSONArray successArray = accComWebService.verifyInvGLInterfaceAmount(inv,sysUser);
				//ERP-4490发票总账凭证金额校验，规避风险 add by yanyang 2021-11-05 end
				result.put(AccConstantUtil.INVC, setResult(successArray));//处理个别字段的值
			}
			if(!CollectionUtils.isEmpty(bill)){
				result.put(AccConstantUtil.BILL, setResult(bill));//处理个别字段的值
			}
			//针对验证失败需要重新进行导入操作的数据（业务表核算状态为导入成功），更新发票业务表核算状态初始化为待导入，重新走导入流程。
			if(!AccEnumUtil.EXCHANGE_MARGIN.getValue().equals(category)) {
				reUpdateInvTobeImport(pay,inv,bill,sysUser);
			}
			//设置返回值
			//ERP-4524内部优化—总账传送接口逻辑优化
			//因为ice服务最大查询maxsize限制，此处查询限制1000条数据，如果结果集等于1000条，表示可能还会有待传送需要二次查询，返回REDO_FLAG=1
			int count = pay.size() + inv.size() + bill.size();
			if(count == 1000){
				Map<String, String> map = new HashMap<>();
				map.put("REDO_FLAG", "1");
				res.params = map;
				logger.info("getImportGLCertificateInfoSrvInputItemCollection REDO_FLAG=1");
			}
			res.isSuccess = true;
			res.message = result.toString();
		}
		return res;
	}

	/**
	 * 实现功能：更新总账汇总凭证头接口状态为导入中,同时初始化汇总凭证行error_message字段为空
	 * @param pay 付款数据
	 * @param inv 发票数据
	 * @param sysUser 操作用户
	 */
	private void updateSummaryImporting(JSONArray pay, JSONArray inv,JSONArray bill,SysUser sysUser) {
		//工具方法
		if(pay != null && pay.size()>0){
			executeUpdateSummaryImporting(AccConstantUtil.PAY,pay,sysUser);
		}
		if(inv != null && inv.size()>0){
			executeUpdateSummaryImporting(AccConstantUtil.INVC,inv,sysUser);
		}
		//ERP-3217：新增应付票据（更新接口表状态为导入中）
		if(bill != null && bill.size()>0){
			executeUpdateSummaryImporting(AccConstantUtil.BILL,bill,sysUser);
		}
	}
	private void executeUpdateSummaryImporting(String keyModule,JSONArray array,SysUser sysUser){
		LogicDB logicdb = AccConstantUtil.INVC.equals(keyModule)?LogicDB.INVC_DB:LogicDB.PAY_DB;
		String dbName = AccConstantUtil.INVC.equals(keyModule)?"发票库":"付款库";
		JSONArray payHeadIds = new JSONArray();
		JSONArray infoIds = new JSONArray();
		//获取要更新的汇总凭证头ID
		for(int i = 0; i < array.size() ; i++){
			JSONObject o = array.getJSONObject(i);
			if(!payHeadIds.contains(o.getString("SUMMARY_VOUCHER_HEAD_ID"))){
				payHeadIds.add(o.getString("SUMMARY_VOUCHER_HEAD_ID"));
			}
			if(!infoIds.contains(o.getString("DOCUMENT_INFO_ID"))){
				infoIds.add(o.getString("DOCUMENT_INFO_ID"));
			}
		}
		//更新付款库汇总凭证头表导入状态为：导入中
		String paySql = AccWebErpSqlUtil.getSumImportingSql(keyModule,StringUtils.join(payHeadIds.toArray(),","),sysUser);
		//初始化汇总凭证行error_message字段为空
		String detailSql = AccWebErpSqlUtil.getDetailImportingSql(keyModule,StringUtils.join(payHeadIds.toArray(),","),sysUser);
		//根据BILLING_INFO_ID更新发票库业务表导入状态为：待导入
//		String accountedSql = AccWebErpSqlUtil.getReUpdateInvAccountedByInfoIdSql(
//				AccEnumUtil.ACCOUNTED.getValue(),StringUtils.join(infoIds.toArray(),","),sysUser);
//		if(AccConstantUtil.PAY.equals(type)){
//			//根据PAYMENT_LIST_ID更新发票库业务表导入状态为：待导入
//			accountedSql = AccWebErpSqlUtil.getReUpdatePayAccountedByInfoIdSql(
//				AccEnumUtil.ACCOUNTED.getValue(),StringUtils.join(infoIds.toArray(),","),sysUser);
//		}
		Connection con = null;
		PreparedStatement pre = null;
		int count = 0;
		try {
			//获取数据库连接
			con = BaseDaoUtil.getDaaSConnection(logicdb);
			con.setAutoCommit(false);
			//执行更新
			if(array!=null&&array.size()>0){
				pre = con.prepareStatement(paySql);
				count = pre.executeUpdate();
				logger.info(dbName + "汇总凭证头接口状态[导入中],核算状态[已核算]更新成功:"+ count +"条");
			}
			if(array!=null&&array.size()>0){
				pre = con.prepareStatement(detailSql);
				count = pre.executeUpdate();
				logger.info(dbName + "汇总凭证行表接口更新ERROR_MESSAGE字段为空，更新成功:"+ count +"条");
			}
//			if(array!=null&&array.size()>0){
//				pre = con.prepareStatement(detailSql);
//				count = pre.executeUpdate();
//				logger.info("总账接口导入前，更新"+dbName+"验证失败需要重新进行导入操作的数据接口状态[导入成功]为[已核算]更新成功:"+ count +"条");
//			}
			con.commit();
		} catch (SMPException | SQLException e) {
			logger.error("数据更新失败!",e);
			e.printStackTrace();
		}finally {
			if (pre!=null) {
				try {
					pre.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					BaseDaoUtil.closeDaaSConnection(con, logicdb);
				} catch (SMPException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 实现功能：待导入总账接口的数据，针对验证失败需要重新进行导入操作的数据（业务表核算状态为导入成功），更新发票业务表核算状态初始化为待导入，重新走导入流程。
	 * @param inv 发票数据
	 * @param sysUser 操作用户
	 */
	private void reUpdateInvTobeImport(JSONArray pay,JSONArray inv,JSONArray bill,SysUser sysUser) {
		//工具方法
		if(pay != null && pay.size()>0){
			AccWebErpService webErpService = new AccWebErpService();
			JSONArray infoIds = new JSONArray();
			//获取要更新的汇总凭证头ID
			for(int i = 0; i < pay.size() ; i++){
				JSONObject o = pay.getJSONObject(i);
				if(!infoIds.contains(o.getString("DOCUMENT_INFO_ID"))){
					infoIds.add(o.getString("DOCUMENT_INFO_ID"));
				}
			}
			//根据PAYMENT_LIST_ID更新发票库业务表导入状态为：待导入
			int updateCount = 0;
			String paySql = AccWebErpSqlUtil.getReUpdatePayAccountedByInfoIdSql(
					AccEnumUtil.ACCOUNTED.getValue(),StringUtils.join(infoIds.toArray(),","),sysUser);
			updateCount = paySql != null?webErpService.execEditStatusSql(paySql,LogicDB.PAY_DB):0;
			logger.info("总账接口导入前，更新付款验证失败需要重新进行导入操作的数据接口状态[导入成功]为[已核算]更新成功:"+ updateCount +"条");
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, StringUtils.join(infoIds.toArray(),","), SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, StringUtils.join(infoIds.toArray(),","),
							SMPAccLogServiceUtil.TABLE_OPRT, AccConstantUtil.T_SAC_PAYMENT_LIST,
							"总账接口导入前，更新付款验证失败需要重新进行导入操作的数据接口状态[导入成功]为[已核算]更新成功:"+ updateCount +"条");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
		if(inv != null && inv.size()>0){
			AccWebErpService webErpService = new AccWebErpService();
			JSONArray infoIds = new JSONArray();
			//获取要更新的汇总凭证头ID
			for(int i = 0; i < inv.size() ; i++){
				JSONObject o = inv.getJSONObject(i);
				if(!infoIds.contains(o.getString("DOCUMENT_INFO_ID"))){
					infoIds.add(o.getString("DOCUMENT_INFO_ID"));
				}
			}
			//根据BILLING_INFO_ID更新发票库业务表导入状态为：待导入
			int updateCount = 0;
			String invSql = AccWebErpSqlUtil.getReUpdateInvAccountedByInfoIdSql(
					AccEnumUtil.ACCOUNTED.getValue(),StringUtils.join(infoIds.toArray(),","),sysUser);
			updateCount = invSql != null?webErpService.execEditStatusSql(invSql,LogicDB.INVC_DB):0;
			logger.info("总账接口导入前，更新发票验证失败需要重新进行导入操作的数据接口状态[导入成功]为[已核算]更新成功:"+ updateCount +"条");
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, StringUtils.join(infoIds.toArray(),","), SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, StringUtils.join(infoIds.toArray(),","),
							SMPAccLogServiceUtil.TABLE_OPRT, AccConstantUtil.T_SAC_BILLING_INFO,
							"总账接口导入前，更新发票验证失败需要重新进行导入操作的数据接口状态[导入成功]为[已核算]更新成功:"+ updateCount +"条");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
		//ERP-3217：应付票据（导入前针对验证失败的数据更新业务表状态为已核算）
		if(bill != null && bill.size()>0){
			AccWebErpService webErpService = new AccWebErpService();
			JSONArray infoIds = new JSONArray();
			//获取要更新的汇总凭证头ID
			for(int i = 0; i < bill.size() ; i++){
				JSONObject o = bill.getJSONObject(i);
				if(!infoIds.contains(o.getString("DOCUMENT_INFO_ID"))){
					infoIds.add(o.getString("DOCUMENT_INFO_ID"));
				}
			}
			//根据PAYMENT_INFO_ID更新票据付款库业务表导入状态为：待导入
			int updateCount = 0;
			String billSql = AccWebErpSqlUtil.getReUpdateBillAccountedByInfoIdSql(
					AccEnumUtil.ACCOUNTED.getValue(),StringUtils.join(infoIds.toArray(),","),sysUser);
			updateCount = billSql != null?webErpService.execEditStatusSql(billSql,LogicDB.PAY_DB):0;
			logger.info("总账接口导入前，更新应付票据验证失败需要重新进行导入操作的数据接口状态[导入成功]为[已核算]更新成功:"+ updateCount +"条");
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, StringUtils.join(infoIds.toArray(),","), SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, StringUtils.join(infoIds.toArray(),","),
							SMPAccLogServiceUtil.TABLE_OPRT, AccConstantUtil.T_SAC_PAYMENT_LIST,
							"总账接口导入前，更新应付票据验证失败需要重新进行导入操作的数据接口状态[导入成功]为[已核算]更新成功:"+ updateCount +"条");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
	}

	/**
	 * 实现功能：业务数据枚举值转化
	 * @param result 业务数据
	 * @return JSONArray
	 */
	private JSONArray setResult(JSONArray result) {
		//获取ou组织名称
		Map<String,String> ous = getOrgNameVSOrgIdMap(result);
		String reference10 = "";
		for(int i = 0 ; i < result.size() ; i++){
			JSONObject o  = result.getJSONObject(i);
			//设置字段中枚举值，需要调用业务聚合服务
			SMPEnumServicePrx proxy = (SMPEnumServicePrx)ICEClientUtil.getSerivcePrx(SMPEnumServicePrx.class);
			//凭证类别枚举值设置
			o.put("USER_JE_CATEGORY_NAME",proxy.getEnumValueName(
					SMPEnumTypeCode.VOUCHER_CATEGORY, null, Integer.valueOf(o.getString("USER_JE_CATEGORY_NAME"))));
			//币种枚举值设置
			o.put("CURRENCY_CODE",proxy.getEnumValueCode(
					SMPEnumTypeCode.CURRENCY, Integer.valueOf(o.getString("CURRENCY_CODE"))) );
			//设置OU组织名称
			o.put("ORG_ID", ous.get(o.get("ORG_ID")));
			//ERP-3076子公司改造-核算、合作方账采取截取组织CODE获取分片和省码的排查和改造 add by yy 20190306
			//省码获取的方式不能截取，采用查询接口的方式
			o.put("PROVINCE_CODE",ShareIdUtil.getProvinceCodeByOrgCode(o.getString("ORG_CODE")));
			//行摘要字段长度限制，如果长度超过240,需要进行长度截取处理
			reference10 = o.getString("REFERENCE10");
			if(StringUtils.isNotEmpty(reference10)){
				int lengthCount = reference10.length();
				//根据一个中文占两个字节，假如一个字符的字节数大于8，则判断为中文。
				char[] c = reference10.toCharArray();
				for(int j = 0; j < c.length; j ++){
					String len = Integer.toBinaryString(c[j]);
					if(len.length() > 8)
						lengthCount++;
				}
				//如果长度大于240，需要截取处理。截取的方案为“_”后的保持不变，截取前面的，再拼接。
				if(lengthCount>=236){
					//分隔符以前的数据
					String priString = reference10.substring(0,reference10.lastIndexOf("_"));
					//分隔符以后的数据
					String suffString = reference10.substring(reference10.lastIndexOf("_")+1);
					//后缀长度+分隔符'_'的长度
					int suffCount = suffString.length()+1;
					char[] suffChar = suffString.toCharArray();
					//ERP侧数据库DESCRIPTION字段长度为240，超长数据进行截取。其中英文字符1位，中文占2位。实际测试239
					for(int s = 0; s < suffChar.length; s ++){
						String len = Integer.toBinaryString(suffChar[s]);
						if(len.length() > 8)
							suffCount++;
					}
					//前缀长度
					int priCount = priString.length();
					char[] priChar = priString.toCharArray();
					for(int s = 0; s < priChar.length; s ++){
						String len = Integer.toBinaryString(priChar[s]);
						if(len.length() > 8)
							priCount++;
					}
					while (priCount + suffCount >= 236) {
						priString = priString.substring(0, priString.length()-1);
						priCount = priString.length();
						priChar = priString.toCharArray();
						for(int s = 0; s < priChar.length; s ++){
							String len = Integer.toBinaryString(priChar[s]);
							if(len.length() > 8)
								priCount++;
						}

					}
					o.put("REFERENCE10", priString +"_" + suffString);
					logger.info("REFERENCE10截取后="+priString +"_" + suffString);
				}
			}
		}
		return result;
	}

	/**
	 * 实现功能：两个组装为一个jsonArray,然后返回
	 * @param pay 付款jsonArray
	 * @param inv 发票jsonArray
	 * @return JSONArray
	 */
	private JSONObject combination(JSONArray pay, JSONArray inv, JSONArray bill) {
		JSONObject result = new JSONObject();
		if(pay != null && !pay.isEmpty()){
			//ERP-3076子公司改造-核算、合作方账采取截取组织CODE获取分片和省码的排查和改造 add by yy 20190306
			//省码获取的方式不能截取，采用查询接口的方式
			JSONArray payGl = new JSONArray();
			JSONArray changePayGl = new JSONArray();
			for (int i = 0; i < pay.size(); i++) {
				JSONObject payObj  = pay.getJSONObject(i);
				payObj.put("PROVINCE_CODE",ShareIdUtil.getProvinceCodeByOrgCode(payObj.getString("PROVINCE_CODE")));
				String category = payObj.getString("CATEGORY");
				if(AccEnumUtil.EXCHANGE_MARGIN.getValue().equals(category)) {
					changePayGl.add(payObj);
				} else {
					payGl.add(payObj);
				}
			}
			result.put(AccConstantUtil.PAY,payGl);
			result.put(AccConstantUtil.CHANGEPAY,changePayGl);
		}
		if(inv != null && !inv.isEmpty()){
			//ERP-3076子公司改造-核算、合作方账采取截取组织CODE获取分片和省码的排查和改造 add by yy 20190306
			//省码获取的方式不能截取，采用查询接口的方式
			for (int i = 0; i < inv.size(); i++) {
				JSONObject invObj  = inv.getJSONObject(i);
				invObj.put("PROVINCE_CODE",ShareIdUtil.getProvinceCodeByOrgCode(invObj.getString("PROVINCE_CODE")));
			}
			result.put(AccConstantUtil.INVC,inv);
		}
		//ERP-3217：新增应付票据
		if(bill != null && !bill.isEmpty()){
			//ERP-3076子公司改造-核算、合作方账采取截取组织CODE获取分片和省码的排查和改造 add by yy 20190306
			//省码获取的方式不能截取，采用查询接口的方式
			for (int i = 0; i < bill.size(); i++) {
				JSONObject billObj  = bill.getJSONObject(i);
				billObj.put("PROVINCE_CODE",ShareIdUtil.getProvinceCodeByOrgCode(billObj.getString("PROVINCE_CODE")));
			}
			result.put(AccConstantUtil.BILL,bill);
		}
		return result;
	}
	/**
	 * 实现功能能：更新总账接口对应的汇总凭证头表信息
	 * @param module 模块类别
	 * @param statusSql 更新sql
	 * @return GeneralServiceResponse
	 */
	private GeneralServiceResponse updateResult(String module,String statusSql) {
		GeneralServiceResponse response = new  GeneralServiceResponse();//返回信息
		AccWebErpService webErpService = new AccWebErpService();//工具方法
		//分别更新结算模、块发票模块汇总总账凭证信息
		if(StringUtils.isNotEmpty(statusSql)){
			if(AccConstantUtil.PAY.equals(module) || AccConstantUtil.CHANGEPAY.equals(module)){//结算模块
				webErpService.execEditStatusSql(statusSql.replace("?h","t_sac_payment_acc_sum_vou_h")
						.replace("?l", "t_sac_payment_acc_sum_vou_l"),LogicDB.PAY_DB);
			}else if(AccConstantUtil.INVC.equals(module)){//发票模块
				webErpService.execEditStatusSql(statusSql.replace("?h","t_sac_billing_acc_sum_vou_h")
						.replace("?l", "t_sac_billing_acc_sum_vou_l"),LogicDB.INVC_DB);
			}else if(AccConstantUtil.BILL.equals(module)){//ERP-3217:应付票据
				webErpService.execEditStatusSql(statusSql.replace("?h","t_sac_payment_bill_sum_vou_h")
						.replace("?l", "t_sac_payment_bill_sum_vou_l"),LogicDB.PAY_DB);
			}
		}
		return response;
	}

	/**
	 * 返回需要验证的发票信息
	 * @param queryVhSql 应付发票SQL
	 * @param queryVirSql 虚拟发票sql
	 * @param queryPrepaySql 预付款应付发票sql
	 * @param queryPrebillSql 预付款核销发票sql
	 * @return GeneralServiceResponse
	 */
	public GeneralServiceResponse getValidateBillInfos(String queryVhSql, String queryVirSql, String queryPrepaySql,
													   String queryPrebillSql) {
		GeneralServiceResponse res = new GeneralServiceResponse();
		//执行sql语句的服务类
		AccWebErpService webErpService = new AccWebErpService();
		//发票sql语句
		String billSql = queryVhSql;
		//虚拟发票sql语句
		String virSql = queryVirSql;
		//获取结算模块需要验证的总账凭证信息
		JSONArray bill = webErpService.execQuerySql(billSql.replace("?","t_sac_billing_imp_ap_inv_h_if"),LogicDB.INVC_DB);
		//获取发票模块需要验证的总账凭证信息
		JSONArray vir = webErpService.execQuerySql(virSql.replace("?","t_sac_billing_imp_sac_vi_h_if"),LogicDB.INVC_DB);
		//获取结算模块需要验证的总账凭证信息
		JSONArray prepayBill = webErpService.execQuerySql(queryPrepaySql.replace("?","t_sac_payment_imp_ap_inv_h_if"),LogicDB.PAY_DB);
		//获取结算模块需要验证的总账凭证信息
		JSONArray prebillBill = webErpService.execQuerySql(queryPrebillSql.replace("?","t_sac_billing_imp_ap_inv_h_if"),LogicDB.INVC_DB);
		//组装jb,jc为一个jsonArray,然后返回
		JSONArray result = new JSONArray();
		if(!CollectionUtils.isEmpty(bill)){
			result.add(0,bill);
		}else{
			result.add(0,null);
		}
		if(!CollectionUtils.isEmpty(vir)){
			result.add(1,vir);
		}else{
			result.add(1,null);
		}
		if(!CollectionUtils.isEmpty(prepayBill)){
			result.add(2,prepayBill);
		}else{
			result.add(2,null);
		}
		if(!CollectionUtils.isEmpty(prebillBill)){
			result.add(3,prebillBill);
		}else{
			result.add(3,null);
		}
		//设置返回值
		if(CollectionUtils.isEmpty(result)){
			res.isSuccess = false;
			res.message = "{\"total\":0,\"rows\":[	{}]}";
		}else{
			res.isSuccess = true;
			res.message = result.toString();
		}
		return res;
	}

	/**
	 * 查询总账接口待验证的数据
	 * @param queryVhSql 查询总账接口待验证sql
	 * @return GeneralServiceResponse
	 */
	public GeneralServiceResponse getValidateInfos(String queryVhSql, String queryBillVhSql, String queryBillSql) {
		GeneralServiceResponse res = new GeneralServiceResponse();
		//执行sql语句的服务类
		AccWebErpService webErpService = new AccWebErpService();
		//付款模块SQL语句
		String queryVhSqlST = queryVhSql;
		//发票模块SQL语句
		String queryVhSqlBL = queryBillVhSql;
		//应付票据SQL语句
		String queryVhSqlBT = queryBillSql;
		//获取付款模块需要验证的总账凭证信息
		JSONArray jb = webErpService.execQuerySql(queryVhSqlST.replace("?","t_sac_payment_acc_sum_vou_h"),LogicDB.PAY_DB);
		//获取发票模块需要验证的总账凭证信息
		JSONArray jc = webErpService.execQuerySql(queryVhSqlBL.replace("?","t_sac_billing_acc_sum_vou_h"),LogicDB.INVC_DB);
		//ERP-3217：获取应付票据需要验证的总账凭证信息
		JSONArray jy = webErpService.execQuerySql(queryVhSqlBT.replace("?","t_sac_payment_bill_sum_vou_h"),LogicDB.PAY_DB);
		//组装jb,jc为一个jsonArray,然后返回
		JSONObject result = combination(jb,jc,jy);

		//设置返回值
		if(CollectionUtils.isEmpty(result)){
			res.isSuccess = false;
			res.message = "待验证数据为空！";
		}else{
			res.isSuccess = true;
			res.message = result.toString();
		}
		return res;
	}

	/**
	 * 组织名字对应组织id的map
	 * @param allJsonArray 数据集
	 * @return Map<String,String>
	 */
	public Map<String,String> getOrgNameVSOrgIdMap(JSONArray allJsonArray){
		String[] orgNameArray=new String[allJsonArray.size()];
		for (int i = 0; i < allJsonArray.size(); i++) {
			JSONObject object = allJsonArray.getJSONObject(i);
			orgNameArray[i]=object.getString("ORG_NAME").trim();
		}
		//调用聚合
		ConsInnerQueryServicePrx conInnerQuerySerproxy =
				(ConsInnerQueryServicePrx)ICEClientUtil.getSerivcePrx(ConsInnerQueryServicePrx.class);
		Map<String,String> map=conInnerQuerySerproxy.getOuOrgIdOuOrgNameByOuName(orgNameArray);
		return map;
	}

	/**
	 * 查询应付付款头表导入批次号后5位流水号最大值
	 * @return int
	 */
	public int getMaxBatchIdCode(){
		//查询最大值sql
		String sql=AccWebErpSqlUtil.getMaxBatchIdSql();
		AccWebErpService ser=new AccWebErpService();
		JSONArray jsonArray=ser.execQuerySql(sql, LogicDB.PAY_DB);
		String maxValueStr=jsonArray==null?"":jsonArray.getJSONObject(0).getString("MAX_CODE");
		return StringUtils.isNotEmpty(maxValueStr)?Integer.valueOf(maxValueStr):0;
	}

	/**
	 * 导入付款前验证应付发票接口表的发票编号验证未通过的数据，得到发票编号没有验证通过的汇总凭证头id
	 * @param queryParamMap 查询条件参数MAP,key为条件字段名称，value为条件值,value格式为：1111,2222,3333
	 * @param accWebErpService ERP接口服务
	 * @return String[]
	 */
	public String[] checkPaymentBillCodeNotValidateSussess(AccWebErpService accWebErpService,Map<String, String> queryParamMap){
		//1.查询需要导入ERP系统的付款的发票编号，因一个付款头会存在多个发票编号，故以付款行为基础数据
		AccCommonService commonService = new AccCommonService();
		List<Object> vhGroupValues = new ArrayList<>();
		String sql=AccWebErpSqlUtil.queryImportPaymentInfo(queryParamMap,vhGroupValues);
		JSONArray billCodeJsonArr = commonService.execQuerySql(LogicDB.PAY_DB,sql,null,vhGroupValues,null).getJSONArray("rows");
		if(billCodeJsonArr==null||billCodeJsonArr.size()==0) return null;
		//汇总凭证头ID对应多个开票编号的map
		Map<String, List<String>> headIdVsInvoNumMap =
				jsonArrayElementToValueListMap(billCodeJsonArr, "SUMMARY_VOUCHER_HEAD_ID","INVOICE_NUMBER");
		//过滤重复的开票编号
		Set<String> invoNumSet=filterMapValueRepeatInvoNum(headIdVsInvoNumMap);
		//2.在应付发票接口表查询发票编号的验证状态，验证通过标识Y，否则标识N
		String billCodeVsStatusSql=AccWebErpSqlUtil.getValidateSussBillCode("'"+StringUtils.join(invoNumSet, "','")+"'");
		JSONArray billCodeVsStatusJsonArray=accWebErpService.execQuerySql(billCodeVsStatusSql, LogicDB.INVC_DB);
		if(billCodeVsStatusJsonArray==null||billCodeVsStatusJsonArray.size()==0){
			return getJsonArrElementValueStrArr(billCodeJsonArr,"SUMMARY_VOUCHER_HEAD_ID");
		}else{
			Map<String,String> billCodeLastStatusMap=getBillCodeLastStatusMap(billCodeVsStatusJsonArray);
			//3.得到发票编号没有验证通过的对应的汇总凭证头id
			return getNotValidateBillCodeHeadIdValue(headIdVsInvoNumMap,billCodeLastStatusMap);
		}
	}
	/**
	 * 得到发票编号的验证通过的最后状态标识，同一个编号既有通过又有不通过的最后状态标识为N不通过
	 * @param billCodeVsStatusJsonArray
	 * @return Map<String, String>
	 */
	public Map<String, String> getBillCodeLastStatusMap(JSONArray billCodeVsStatusJsonArray){
		Map<String, String> map=new HashMap<String,String>();
		for (Iterator iterator = billCodeVsStatusJsonArray.iterator(); iterator.hasNext();) {
			JSONObject jo = (JSONObject) iterator.next();
			//发票编号
			String key=jo.getString("INVOICE_NUM");
			//发票编号验证通过标识，Y为通过，N为非通过
			String flag=jo.getString("FLAG");
			if("Y".equals(flag)&&"N".equals(map.get(key))){
				flag="N";
			}
			map.put(key, flag);
		}
		return map;
	}

	/**
	 * 过滤发票编号重复
	 * @param headIdVsInvoNumMap 发票编号集
	 * @return Set<String>
	 */
	public Set<String> filterMapValueRepeatInvoNum(Map<String, List<String>> headIdVsInvoNumMap){
		Set<String> set=new HashSet<>();
		for (Iterator iterator = headIdVsInvoNumMap.values().iterator(); iterator.hasNext();) {
			List<String> type = (List<String>) iterator.next();
			for (Iterator iterator2 = type.iterator(); iterator2.hasNext();) {
				String string = (String) iterator2.next();
				set.add(string);
			}
		}
		return set;
	}
	/**
	 * 得到发票编号没有验证通过的汇总凭证头id
	 * @param headIdVsInvoNumMap 汇总凭证头ID对应开票编号的map
	 * @param billCodeLastStatusMap 在应付发票接口表验证通过的开票编号map
	 * @return String[]
	 */
	public String[] getNotValidateBillCodeHeadIdValue(Map<String, List<String>> headIdVsInvoNumMap,Map<String, String> billCodeLastStatusMap){
		Set<String> headIdSet=new HashSet<String>();
		for (Iterator headIdVsInvoNumIte = headIdVsInvoNumMap.keySet().iterator(); headIdVsInvoNumIte.hasNext();) {
			String key=(String)headIdVsInvoNumIte.next();
			List<String> invoiceNumList=headIdVsInvoNumMap.get(key);
			for (Iterator invoiceNumIte = invoiceNumList.iterator(); invoiceNumIte.hasNext();) {
				String invoiceNumKey = (String) invoiceNumIte.next();
				String value=billCodeLastStatusMap.get(invoiceNumKey);
				//发票不存在或为N的都为验证不通过
				if(value==null||"N".equals(value)){
					headIdSet.add(key);
					break;
				}
			}
		}
		return headIdSet.toArray(new String[headIdSet.size()]);
	}
	/**
	 * 查询导入应付付款头和行数据,去除发票编号为验证通过的数据，并对可导入数据的导入状态改为导入中
	 * @param queryParamMap 查询条件参数MAP,key为条件字段名称，value为条件值,value格式为：1111,2222,3333
	 * @param sysUser 操作用户
	 * @return GeneralServiceResponse
	 */
	public GeneralServiceResponse queryImportPaymentHeadAndLineDate(Map<String, String> queryParamMap,SysUser sysUser){
		AccWebErpService accWebErpService=new AccWebErpService();
		AccCommonService commonService = new AccCommonService();
		//基础服务应答对象返回信息
		GeneralServiceResponse serResponse=new GeneralServiceResponse();
		logger.info("应付付款接口查询接口表数据begin-----" +queryParamMap.get("importTime"));
		//预付款核销
		LogicDB logicDB = "TRUE".equals(queryParamMap.get("PREBILL_FLAG"))
				? LogicDB.INVC_DB : LogicDB.PAY_DB;
		String interfaceTable = "TRUE".equals(queryParamMap.get("PREBILL_FLAG"))
				? AccConstantUtil.T_SAC_BILLING_IMP_AP_PAY_HEAD : AccConstantUtil.T_SAC_PAYMENT_IMP_AP_PAY_HEAD;
		//1.查询导入应付付款头数据
		List<Object> vhGroupValues = new ArrayList<>();
		String headSql=AccWebErpSqlUtil.queryImportPaymentHeadSql(queryParamMap,vhGroupValues);
		JSONArray headArray = commonService.execQuerySql(logicDB,headSql,null,vhGroupValues,null).getJSONArray("rows");
		//判断头表是否查到数据，如果查到则查询行数据并合并
		if(headArray==null||headArray.size()==0){
			serResponse.isSuccess = false;
			serResponse.message = "暂没有要推送的应付付款数据！";
			logger.info("应付付款接口查询接口表数据end,暂没有要推送的应付付款数据！" +queryParamMap.get("importTime"));
			return serResponse;
		}
		//得到需要导入ERP数据的PRI_KEY
		String[] priKeyArr=getJsonArrElementValueStrArr(headArray, "PRI_KEY");
		// 1.导入ERP前修改应付发票接口表的导入状态为导入中
		accComWebService.updateInteTabInteStateToImporting(logicDB,interfaceTable, priKeyArr);
		/**
		 * 因发票核算时，非合并单据已入账；合并单据核算时会做入账校验，这里就不再需要再校验了，屏蔽。*/
		String[] notValidateIdArr= null;
		JSONArray validateFailArray = new JSONArray();
		//ERP-4617  预付款退款-付款凭证导入顺序逻辑调整  这里判断下 是不是预付款退款
		String paymentRefundIds = AccWebErpSqlUtil.getPaymentRefundIdSql(StringUtils.join(getJsonArrElementValueStrArr(headArray, "DOCUMENT_INFO_ID"), ","));
		JSONArray paymentRefundIdsArray = accWebErpService.execQuerySql(paymentRefundIds, LogicDB.PAY_DB);
		//ERP-3236预付款支付核算——预付款支付核算接口处理
		//因预付款支付接口与发票接口同时生成，可能产生发票未入账支付就传送接口的情况，顾预付款需要再进行校验，非预付款不校验。
		if("TRUE".equals(queryParamMap.get("PREPAY_FLAG"))){
			//2.查询开票编号在应付发票中没有验证通过，回写反馈信息
			String[] documentInfoIds = getJsonArrElementValueStrArr(headArray, "DOCUMENT_INFO_ID");
			String prepayApBillValidateFailSql = AccWebErpSqlUtil
					.prepayApBillValidateFailSql(StringUtils.join(documentInfoIds, ","));
			validateFailArray.addAll(accWebErpService.execQuerySql(prepayApBillValidateFailSql, LogicDB.PAY_DB));
		}
		if(paymentRefundIdsArray.size() > 0){
			String[] documentInfoIds = getJsonArrElementValueStrArr(paymentRefundIdsArray, "DOCUMENT_INFO_ID");
			String payApAccountStatusFailSql = AccWebErpSqlUtil
					.payApAccountStatusFailSql(StringUtils.join(documentInfoIds, ","));
			Map<String, List<Object>> groupByInfoIds = accWebErpService.execQuerySql(payApAccountStatusFailSql, LogicDB.PAY_DB).stream().collect(Collectors.groupingBy(o -> {
				return ((JSONObject) o).getString("DOCUMENT_INFO_ID");
			}));
			paymentRefundIdsArray.forEach(o->{
				JSONObject obj = (JSONObject) o;
				if(!groupByInfoIds.containsKey(obj.getString("DOCUMENT_INFO_ID"))){
					validateFailArray.add(o);
				}else {
					JSONObject groupByInfoId = (JSONObject)(groupByInfoIds.get(obj.getString("DOCUMENT_INFO_ID")).get(0));
					if(!AccEnumUtil.VOUCHER_CREATED.getValue().equals(groupByInfoId.getString("ACCOUNTING_STATUS_ENUM_ID"))){
						validateFailArray.add(o);
					}
				}
			});
		}
		if(!CollectionUtils.isEmpty(validateFailArray)){
			notValidateIdArr = getJsonArrElementValueStrArr(validateFailArray, "DOCUMENT_INFO_ID");
			logger.info("notValidateIdArr = " + StringUtils.join(notValidateIdArr, ","));
			accWebErpService.updatePrepayApBillValidFail(LogicDB.PAY_DB,notValidateIdArr, sysUser);
		}
		//2.查询导入应付付款行数据
		vhGroupValues = new ArrayList<>();
		String lineSql=AccWebErpSqlUtil.queryImportPaymentLineSql(queryParamMap,vhGroupValues);
		JSONArray lineArray = commonService.execQuerySql(logicDB,lineSql,null,vhGroupValues,null).getJSONArray("rows");
		//3.合并导入应付付款头和行数据并设置批次号
		mergeImportPaymentHeadAndLineDate(headArray,lineArray,notValidateIdArr);
		//设置返回值
		if(!CollectionUtils.isEmpty(headArray)){
			serResponse.isSuccess = true;
			serResponse.message = headArray.toString();
		}else{
			serResponse.isSuccess = false;
			serResponse.message = "暂没有要推送的应付付款数据！";
		}
		logger.info("应付付款接口查询接口表数据end,查询数据" + (headArray==null || headArray.size()==0?"0":headArray.size())+"条-----" +queryParamMap.get("importTime"));
		return serResponse;
	}
	/**
	 * 合并导入应付付款头和行数据并设置批次号，针对发票编号没有验证的进行过滤
	 * @param headArray 应付付款头
	 * @param lineArray 应付付款行
	 * @param notValidateIdArr 发票编号没有验证通过的ID数组
	 */
	public void mergeImportPaymentHeadAndLineDate(JSONArray headArray,JSONArray lineArray,String[] notValidateIdArr){
		//批号后缀：时间+4位随机数
		String batchSuffix = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
		String str="0123456789";
		StringBuilder randomNum=new StringBuilder(4);
		for(int i=0;i<4;i++){
			char ch=str.charAt(new Random().nextInt(str.length()));
			randomNum.append(ch);
		}
		batchSuffix = batchSuffix + randomNum.toString();
		//生成批次号
		String batchCode = "SMP"+batchSuffix;
		//对行数据分组并放入批次号
		Map<String, List<Object>> lineArrayMap = jsonArrayToMap(lineArray, "IMPORT_ID", batchCode);
		JSONArray lineJsonArr=null;
		for (Iterator iterator = headArray.iterator(); iterator.hasNext();) {
			JSONObject headObject = (JSONObject) iterator.next();
			//得到付款头中元素的值
			String value = headObject.getString("IMPORT_ID");
			String documentInfoId = headObject.getString("DOCUMENT_INFO_ID");
			//根据发票编号没有验证通过的汇总凭证头ID过滤，去掉没有验证通过的
			if (notValidateIdArr != null && ArrayUtils.contains(notValidateIdArr, documentInfoId)) {
				iterator.remove();
				continue;
			}
			//设置付款头批次号
			headObject.put("BATCH_ID", batchCode);
			//得到付款头对应的付款行的数据集
			List<Object> lineList=lineArrayMap.get(value);
			lineJsonArr=new JSONArray();
			if(lineList!=null){
				//行数据集转为json格式字符串
				String lineJsonString=JSON.toJSON(lineList).toString();
				lineJsonArr.addAll(JSONArray.parseArray(lineJsonString));
			}
			//在付款头中放入付款行的信息
			headObject.put("APCertificateLinesInfoCollection", lineJsonArr);
			//因为付款摘要太长了，导入到ERP那边的时候超长到不导不进去导致导入异常。
			String description = headObject.getString("DESCRIPTION");
			int lengthCount = description.length();
			//根据一个中文占两个字节，假如一个字符的字节数大于8，则判断为中文。
			char[] c = description.toCharArray();
			for(int i = 0; i < c.length; i ++){
				String len = Integer.toBinaryString(c[i]);
				if(len.length() > 8)
					lengthCount++;
			}
			//ERP侧数据库DESCRIPTION字段长度为240，超长数据进行截取。其中英文字符1位，中文占2位。
			while (lengthCount>240){
				description = description.substring(0, description.length()-5);
				lengthCount = description.length();
				c = description.toCharArray();
				for(int i = 0; i < c.length; i ++){
					String len = Integer.toBinaryString(c[i]);
					if(len.length() > 8)
						lengthCount++;
				}
			}
			headObject.put("DESCRIPTION", description);
		}
		//删除发票编号没有验证通过的数据
		//headArray.removeAll(removeHeadArray);
	}

	/**
	 * 返回JSON数组中对象指定元素的值为键，JSON对象集合为值的map对象,并设置行批次号
	 * @param array json数组
	 * @param element json数组中json对象的元素名称
	 * @param batchCode 批次号
	 * @return Map<String, List<Object>>
	 */
	public Map<String, List<Object>> jsonArrayToMap(JSONArray array,String element,String batchCode){
		Map<String, List<Object>> map=new HashMap<String, List<Object>>();
		for (Iterator iterator = array.iterator(); iterator.hasNext();) {
			JSONObject object = (JSONObject) iterator.next();
			//设置行批次号
			object.put("BATCH_ID", batchCode);
			String elementValue=object.getString(element);
			List<Object> list=map.get(elementValue);
			if(list==null){
				list=new ArrayList<Object>();
			}
			list.add(object);
			map.put(elementValue, list);
		}
		return map;
	}

	/**
	 * 返回JSON数组中对象指定元素的值为键，JSON对象集合为值的map对象
	 * @param array json数组
	 * @param element json数组中json对象的元素名称
	 * @return Map<String, List<Object>>
	 */
	public Map<String, List<Object>> jsonArrayToMap(JSONArray array,String element){
		Map<String, List<Object>> map=new HashMap<String, List<Object>>();
		for (Iterator iterator = array.iterator(); iterator.hasNext();) {
			JSONObject object = (JSONObject) iterator.next();
			String elementValue=object.getString(element);
			List<Object> list=map.get(elementValue);
			if(list==null){
				list=new ArrayList<Object>();
			}
			list.add(object);
			map.put(elementValue, list);
		}
		return map;
	}

	/**
	 * 根据汇总凭证头（付款）表的汇总凭证头ID获取单据信息ID
	 * @param headIds 汇总凭证头ID
	 * @return String[]
	 */
	public String[] getDocumentInfoIdByHeadIdToArr(LogicDB logicDB,String interfaceHeadTable,String headIds){
		if(StringUtils.isEmpty(headIds)) return null;
		AccWebErpService ser=new AccWebErpService();
		String sql=AccWebErpSqlUtil.getDocumentInfoIdByHeadIdSql(interfaceHeadTable,headIds);
		JSONArray jsonArray=ser.execQuerySql(sql, logicDB);
		String[] strArr=getJsonArrElementValueStrArr(jsonArray,"DOCUMENT_INFO_ID");
		return strArr;
	}

	/**
	 * 返回验证应付付款信息验证成功的汇总凭证头id
	 * @param resultArray 信息验证数据集
	 * @return String[]
	 */
	public String[] getErpImpSussessHeaderIds(JSONArray resultArray,boolean prebillFlag){
		LogicDB logicDB = prebillFlag ? LogicDB.INVC_DB : LogicDB.PAY_DB;
		String interfaceHeadTable = prebillFlag ? AccConstantUtil.T_SAC_BILLING_IMP_AP_PAY_HEAD
				: AccConstantUtil.T_SAC_PAYMENT_IMP_AP_PAY_HEAD;
		//批次号
		String batchId="";
		//验证成功的 付款单号_付款清单行号(EAS编号)
		List<String> easReceiptNumberList=new ArrayList<String>();
		for (Iterator iterator = resultArray.iterator(); iterator.hasNext();) {
			JSONObject jsonObject = (JSONObject) iterator.next();
			//因为验证时是根据批次号分批验证，所以每次回写时的批次号相同
			batchId=jsonObject.getString("bATCH_ID");
			//判断验证成功
			if("Y".equals(jsonObject.getString("fLAG"))){
				easReceiptNumberList.add(jsonObject.getString("eAS_RECEIPT_NUMBER"));
			}
		}
		//没有验证成功的EAS编号，则直接返回null
		if(easReceiptNumberList.size()==0) return null;
		//查询验证应付付款成功的汇总凭证头ID SQL
		String sql = AccWebErpSqlUtil.getErpImpSussessHeaderIdSql(batchId,
				easReceiptNumberList.toArray(new String[easReceiptNumberList.size()]),interfaceHeadTable);
		AccWebErpService ser=new AccWebErpService();
		JSONArray jsonArray=ser.execQuerySql(sql, logicDB);
		String[] headerIdArr=getJsonArrElementValueStrArr(jsonArray,"SUMMARY_VOUCHER_HEAD_ID");
		return headerIdArr;
	}

	/**
	 * 根据指定元素名称得到JSONArray的值的字符串数组
	 * @param jsonArray 数据集
	 * @param elementName 元素名称
	 * @return String[]
	 */
	public String[] getJsonArrElementValueStrArr(JSONArray jsonArray,String elementName){
		if(jsonArray==null) return null;
		Set<String> set=new HashSet<String>();
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jo=jsonArray.getJSONObject(i);
			set.add(jo.getString(elementName));
		}
		return set.toArray(new String[set.size()]);
	}
	/**
	 * json数组指定元素转为MAP
	 * @param jsonArray 数据集
	 * @param keyElement 键元素名称
	 * @param valueElement 值元素名称
	 * @return Map<String, String>
	 */
	public Map<String, String> jsonArrayElementToMap(JSONArray jsonArray,String keyElement,String valueElement){
		Map<String, String> map=new HashMap<String,String>();
		String value=null;
		for (Iterator iterator = jsonArray.iterator(); iterator.hasNext();) {
			JSONObject jo = (JSONObject) iterator.next();
			value=map.get(jo.getString(keyElement));
			if(value==null){
				map.put(jo.getString(keyElement), jo.getString(valueElement));
			}
		}
		return map;
	}
	/**
	 * json数组指定元素转为MAP
	 * @param jsonArray 数据集
	 * @param keyElement 键元素名称
	 * @param valueElement 值元素名称
	 * @return Map<String, List<String>>
	 */
	public Map<String, List<String>> jsonArrayElementToValueListMap(JSONArray jsonArray,String keyElement,String valueElement){
		Map<String, List<String>> map=new HashMap<String,List<String>>();
		for (Iterator iterator = jsonArray.iterator(); iterator.hasNext();) {
			JSONObject jo = (JSONObject) iterator.next();
			String key=jo.getString(keyElement);
			List<String> valueList=map.get(key);
			if(valueList==null){
				valueList=new ArrayList<String>();
			}
			valueList.add(jo.getString(valueElement));
			map.put(key, valueList);
		}
		return map;
	}
	/**
	 * 撤销发票成功后批量修改汇总凭证头和相关业务表的核算状态
	 * @param sussessReceiptNumberArr 导入成功单据编号信息
	 * @param voucherCategoryId 凭证类别
	 * @param sumVouTableName 汇总凭证表
	 * @param sourceCode 数据来源编码，import 指导入成功的数据回写，validate 指验证成功的数据回写
	 * @param sysUser 操作用户
	 * @return boolean
	 */
	public boolean batchUpdateSumAccHeadAndBusinessTable(String[] sussessReceiptNumberArr,
														 String voucherCategoryId,String sumVouTableName,String sourceCode,SysUser sysUser){
		AccWebErpService accWebErpService=new AccWebErpService();
		//根据数据来源编码确认核算状态
		String accountStatusEnumId = AccConstantUtil.IMPORT.equals(sourceCode) ? AccEnumUtil.IMPORT_SUCCESS.getValue()
				: AccConstantUtil.VALIDATE.equals(sourceCode) ? AccEnumUtil.VOUCHER_CREATED.getValue() : "";
		//存放汇总凭证头表的汇总凭证头ID和单据信息ID
		JSONArray sussessSumAccHeadJsonArray=new JSONArray();
		//修改汇总凭证头表核算状态成功标识
		boolean updateSumAccHeadFlag=false;
		//预付款的凭证类别为：预付款发票+逗号+预付款支付(即：5000404,5000169)
		String advVoucherCategoryIds=AccEnumUtil.PREPAYMENT_INVOICE.getValue() + "," + AccEnumUtil.ADVANCE_PAYMENT.getValue();
		//ERP-2820财务核算优化——逆向核算及撤销接口逻辑改造 原逻辑屏蔽
		/**
		 //虚拟发票、应付发票撤销特殊处理，虚拟发票需要虚拟发票和应付发票都成功才能回写汇总凭证头
		 if(AccEnumUtil.VIRTUAL_INVOICE.getValue().equals(voucherCategoryId)||AccEnumUtil.PAYABLE_INVOICE.getValue().equals(voucherCategoryId)){
		 String sql=AccWebErpSqlUtil.getImpSussHeadIdAndDocInfoIdSql( "'"+StringUtils.join(sussessReceiptNumberArr,"','")+"'",voucherCategoryId);
		 sussessSumAccHeadJsonArray=accWebErpService.execQuerySql(sql, LogicDB.INVC_DB);
		 String[] sumAccHeadIdArr=getJsonArrElementValueStrArr(sussessSumAccHeadJsonArray, "SUMMARY_VOUCHER_HEAD_ID");
		 updateSumAccHeadFlag=updateSumAccTableAccStatus(sumAccHeadIdArr, voucherCategoryId,sourceCode,sysUser);
		 //预付款支付、预付款发票(预付款的凭证类别传递参数为:5000404,5000169)
		 }else if(advVoucherCategoryIds.equals(voucherCategoryId)){
		 //预付款的设置凭证类别为预付款支付，为了后面更新业务表找到对应的表信息
		 voucherCategoryId=AccEnumUtil.ADVANCE_PAYMENT.getValue();
		 //得到撤销预付款的汇总凭证头id
		 String[] sumAccHeadIdArr=getSumAccHeadIdForAdvPayment(sussessReceiptNumberArr, advVoucherCategoryIds);
		 String sql=AccWebErpSqlUtil.getSumAccInfoForMoreVouCateSql(AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H, "SUMMARY_VOUCHER_HEAD_ID",
		 StringUtils.join(sumAccHeadIdArr,","), advVoucherCategoryIds, true);
		 sussessSumAccHeadJsonArray=accWebErpService.execQuerySql(sql, LogicDB.PAY_DB);
		 //修改汇总凭证表的核算状态
		 String updateSql=AccWebErpSqlUtil.getUpdateAccStautsSql(AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H, accountStatusEnumId,
		 "SUMMARY_VOUCHER_HEAD_ID", StringUtils.join(sumAccHeadIdArr, ","),sysUser==null?0:sysUser.cloudUserId);
		 updateSumAccHeadFlag=accWebErpService.execUpdateSql(updateSql, LogicDB.PAY_DB);
		 if(updateSumAccHeadFlag){
		 // 记录日志
		 SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest(sysUser, "0",
		 SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE, SMPAccLogServiceUtil.BACTH, "0",
		 SMPAccLogServiceUtil.TABLE_OPRT, AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H,
		 "撤销"+sourceCode +"接口回写,回写业务表" + AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H + "的最后修改人、最后修改时间、核算状态="
		 +accountStatusEnumId + "修改数据的SUMMARY_VOUCHER_HEAD_ID为:"+ StringUtils.join(sumAccHeadIdArr, ","));
		 SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		 }
		 }else{
		 LogicDB logicDB = null;
		 if(AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H.equals(sumVouTableName)){
		 logicDB = LogicDB.INVC_DB;
		 }else if(AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H.equals(sumVouTableName)){
		 logicDB = LogicDB.PAY_DB;
		 }
		 //1.得到凭证类别对应的数据库、汇总凭证头表名等信息
		 Object[] dbAndTbInfoArr=AccConstantUtil.VOUCHER_CATEGORY_VS_DB_MAP.get(voucherCategoryId);
		 //2.根据单据编号得到汇总凭证头表的汇总凭证头ID和单据信息ID
		 //因为核算优化后，发票编号的取值都变成了凭证名称截取，所以不能再用VOUCHER_CATEGORY_VS_DB_MAP里面定义的dbAndTbInfoArr[2],
		 //另外，在获取撤销接口EAS_RECEIPT_NUMBER数据时，将凭证名称中“冲销-”去掉了，所以在与汇总凭证头表用EAS_RECEIPT_NUMBER关联时，需要把“冲销-”字段拼接上再进行关联
		 sussessSumAccHeadJsonArray=accComWebService.getSumAccInfo(logicDB, sumVouTableName,
		 "SUBSTRING_INDEX(VOUCHER_NAME, ' ', 1)",sussessReceiptNumberArr,voucherCategoryId,true);
		 //3.批量修改汇总凭证头表的核算状态
		 updateSumAccHeadFlag=accWebErpService.execBatchUpdateInvoiceCancelSta(sussessSumAccHeadJsonArray, voucherCategoryId,
		 accountStatusEnumId,sysUser==null?0:sysUser.cloudUserId);
		 if(updateSumAccHeadFlag){
		 //得到汇总凭证头id
		 String[] sumAccHeadIdArr=getJsonArrElementValueStrArr(sussessSumAccHeadJsonArray,"SUMMARY_VOUCHER_HEAD_ID");
		 // 记录日志
		 SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest(sysUser, "0",
		 SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE, SMPAccLogServiceUtil.BACTH, "0",
		 SMPAccLogServiceUtil.TABLE_OPRT, sumVouTableName,
		 "撤销"+sourceCode+"接口回写,回写业务表" + sumVouTableName + "的最后修改人、最后修改时间、核算状态="
		 +accountStatusEnumId + "修改数据的SUMMARY_VOUCHER_HEAD_ID为:"+ StringUtils.join(sumAccHeadIdArr, ","));
		 SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		 }
		 }
		 */
		/**
		 //ERP-2820财务核算优化——逆向核算及撤销接口逻辑改造 新增逻辑begin
		 //预付款支付、预付款发票(预付款的凭证类别传递参数为:5000404,5000169)
		 if(advVoucherCategoryIds.equals(voucherCategoryId)){
		 //预付款的设置凭证类别为预付款支付，为了后面更新业务表找到对应的表信息
		 voucherCategoryId=AccEnumUtil.ADVANCE_PAYMENT.getValue();
		 //得到撤销预付款的汇总凭证头id
		 String[] sumAccHeadIdArr=getSumAccHeadIdForAdvPayment(sussessReceiptNumberArr, advVoucherCategoryIds);
		 String sql=AccWebErpSqlUtil.getSumAccInfoForMoreVouCateSql(AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H, "SUMMARY_VOUCHER_HEAD_ID",
		 StringUtils.join(sumAccHeadIdArr,","), advVoucherCategoryIds, true);
		 sussessSumAccHeadJsonArray=accWebErpService.execQuerySql(sql, LogicDB.PAY_DB);
		 //修改汇总凭证表的核算状态
		 String updateSql=AccWebErpSqlUtil.getUpdateAccStautsSql(AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H, accountStatusEnumId,
		 "SUMMARY_VOUCHER_HEAD_ID", StringUtils.join(sumAccHeadIdArr, ","),sysUser==null?0:sysUser.cloudUserId);
		 updateSumAccHeadFlag=accWebErpService.execUpdateSql(updateSql, LogicDB.PAY_DB);
		 if(updateSumAccHeadFlag){
		 // 记录日志
		 SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest(sysUser, "0",
		 SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE, SMPAccLogServiceUtil.BACTH, "0",
		 SMPAccLogServiceUtil.TABLE_OPRT, AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H,
		 "撤销"+sourceCode +"接口回写,回写业务表" + AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H + "的最后修改人、最后修改时间、核算状态="
		 +accountStatusEnumId + "修改数据的SUMMARY_VOUCHER_HEAD_ID为:"+ StringUtils.join(sumAccHeadIdArr, ","));
		 SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		 }
		 }else{//接口表都成功才能回写汇总凭证头
		 String sql=AccWebErpSqlUtil.getImpSussHeadIdAndDocInfoIdSql( "'"+StringUtils.join(sussessReceiptNumberArr,"','")+"'",voucherCategoryId);
		 sussessSumAccHeadJsonArray=accWebErpService.execQuerySql(sql, LogicDB.INVC_DB);
		 String[] sumAccHeadIdArr=getJsonArrElementValueStrArr(sussessSumAccHeadJsonArray, "SUMMARY_VOUCHER_HEAD_ID");
		 updateSumAccHeadFlag=updateSumAccTableAccStatus(sumAccHeadIdArr, voucherCategoryId,sumVouTableName,sourceCode,sysUser);
		 }*/
		String sql=AccWebErpSqlUtil.getImpSussHeadIdAndDocInfoIdSql( "'"+StringUtils.join(sussessReceiptNumberArr,"','")+"'",voucherCategoryId);
		sussessSumAccHeadJsonArray=accWebErpService.execQuerySql(sql, LogicDB.INVC_DB);
		String[] sumAccHeadIdArr=getJsonArrElementValueStrArr(sussessSumAccHeadJsonArray, "SUMMARY_VOUCHER_HEAD_ID");
		updateSumAccHeadFlag=updateSumAccTableAccStatus(sumAccHeadIdArr, voucherCategoryId,sumVouTableName,sourceCode,sysUser);
		//ERP-2820财务核算优化——逆向核算及撤销接口逻辑改造 新增逻辑end
		//得到导入成功的单据信息ID
		String[] documentInfoIdArr=getJsonArrElementValueStrArr(sussessSumAccHeadJsonArray, "DOCUMENT_INFO_ID");
		//4.回写业务表核算状态
		boolean bussUpdateFlag=true;
		if(updateSumAccHeadFlag&&documentInfoIdArr!=null&&documentInfoIdArr.length>0){
			//因读写分离，可能导致数据主从复制滞后。暂停2秒同步,解决数据不同步问题
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			String module = AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H.equals(sumVouTableName)?AccConstantUtil.INVC:AccConstantUtil.PAY;
			GeneralServiceResponse generalServiceResponse = accComWebService.updateBusinessTableAccStatus(documentInfoIdArr, module, voucherCategoryId, true, sourceCode, sysUser);
			bussUpdateFlag=generalServiceResponse.isSuccess;
		}
		return updateSumAccHeadFlag&&bussUpdateFlag?true:false;
	}

	/**
	 * 得到撤销预付款的汇总凭证头id
	 * @param sussessReceiptNumberArr 导入成功单据编号信息
	 * @param voucherCategoryId 凭证类别
	 * @return String[]
	 */
	public String[] getSumAccHeadIdForAdvPayment(String[] sussessReceiptNumberArr,String voucherCategoryId){
		AccWebErpService accWebErpService=new AccWebErpService();
		//查询汇总凭证头id
		String sql=AccWebErpSqlUtil.getSumAccHeadIdForAdvPaymentSql(
				"'"+StringUtils.join(sussessReceiptNumberArr,"','")+"'", voucherCategoryId);
		JSONArray jsonArray=accWebErpService.execQuerySql(sql, LogicDB.INVC_DB);
		List<String> headIdList=new ArrayList<String>();
		for (Iterator iterator = jsonArray.iterator(); iterator.hasNext();) {
			JSONObject headIdObj = (JSONObject) iterator.next();
			//汇总凭证头是多个id逗号分隔
			String headIds=headIdObj.getString("SUMMARY_VOUCHER_HEAD_ID");
			String[] headIdArr=StringUtils.split(headIds,",");
			for (int i = 0; i < headIdArr.length; i++) {
				String headId = headIdArr[i];
				headIdList.add(headId);
			}
		}
		return headIdList.toArray(new String[headIdList.size()]);
	}
	/**
	 * 导入撤销发票导入成功的单据编号
	 * @param sussessArray 导入成功的数据
	 * @param voucherCategoryId 凭证类别编号
	 * @return String[]
	 */
	public String[] getSussImpInvoiceCancelRecNum(JSONArray sussessArray, String voucherCategoryId) {
		List<String> list = new ArrayList<String>();
		for (Iterator iterator = sussessArray.iterator(); iterator.hasNext();) {
			JSONObject jo = (JSONObject) iterator.next();
			String recNumber = jo.getString("rECORD_NUMBER");
			// 凭证类别为 暂估划转、发票价差、暂估上划时单据编号前加""
//			if (AccEnumUtil.ESTIMATED_TRANSFER.getValue().equals(voucherCategoryId)
//					|| AccEnumUtil.INVOICE_DIP.getValue().equals(voucherCategoryId)
//					|| AccEnumUtil.ACCRUED_DELIVERING.getValue().equals(voucherCategoryId)) {
//				recNumber = "冲销-" + recNumber;
//			}
			list.add(recNumber);
		}
		return list.toArray(new String[list.size()]);
	}
	/**
	 * 验证导入撤销发票服务验证成功的单据编号
	 * @param resultArray 验证成功的数据
	 * @param voucherCategoryId 凭证类别编号
	 * @return String[]
	 */
	public String[] getSussValidateInvoiceCancelRecNum(JSONArray resultArray, String voucherCategoryId) {
		List<String> list = new ArrayList<String>();
		for (Iterator iterator = resultArray.iterator(); iterator.hasNext();) {
			JSONObject jo = (JSONObject) iterator.next();
			//验证成功
			if("Y".equals(jo.getString("fLAG"))){
				String recNumber = jo.getString("eAS_RECEIPT_NUMBER");
				// 凭证类别为 暂估划转、发票价差、暂估上划时单据编号前加""
//				if (AccEnumUtil.ESTIMATED_TRANSFER.getValue().equals(voucherCategoryId)
//						|| AccEnumUtil.INVOICE_DIP.getValue().equals(voucherCategoryId)
//						|| AccEnumUtil.ACCRUED_DELIVERING.getValue().equals(voucherCategoryId)) {
//					recNumber = "冲销-" + recNumber;
//				}
				list.add(recNumber);
			}
		}
		return list.toArray(new String[list.size()]);
	}

	/**
	 * 对导入或验证接口成功的数据回写汇总凭证头表的核算状态
	 * @param sumAccHeadIdArr 导入或验证接口返回成功的汇总凭证头id数据
	 * @param voucherCategoryId 凭证类别
	 * @param sumVouTableName 汇总凭证表
	 * @param sourceCode 数据来源编码，import 指导入成功的数据回写，validate 指验证成功的数据回写
	 * @param sysUser 操作用户
	 * @return boolean
	 */
	public boolean updateSumAccTableAccStatus(String[] sumAccHeadIdArr, String voucherCategoryId,String sumVouTableName,String sourceCode,SysUser sysUser) {
		AccWebErpService ser = new AccWebErpService();
		LogicDB logicDB = null;
		if(AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H.equals(sumVouTableName)){
			logicDB = LogicDB.INVC_DB;
		}else if(AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H.equals(sumVouTableName)){
			logicDB = LogicDB.PAY_DB;
		}else if(AccConstantUtil.T_SAC_PAYMENT_BILL_SUM_VOU_H.equals(sumVouTableName)){//ERP-3217:应付票据
			logicDB = LogicDB.PAY_DB;
		}
		//得到对应需要修改的数据库名、表名等信息
		//Object[] dbAndTbInfoArr = AccConstantUtil.VOUCHER_CATEGORY_VS_DB_MAP.get(voucherCategoryId);
		//根据单据编号查询汇总凭证头ID和核算状态是否导入成功标识的sql
		String impSussHeadIdSql = AccWebErpSqlUtil.getInterfaceTabImpOrValiSussHeadIdSql(AccConstantUtil.T_SAC_BILLING_REV_ERP_INV_IF,
				"'" + StringUtils.join(sumAccHeadIdArr, "','") + "'",sourceCode);
		//根据单据编号查询汇总凭证头ID和核算状态是否导入成功标识结果集
		JSONArray impSussHeadIdJsArr = ser.execQuerySql(impSussHeadIdSql, LogicDB.INVC_DB);
		//得到需要更新核算状态为导入成功的汇总凭证头id
		String[] updateHeadIdArr = accComWebService.getAllSussElementValues(impSussHeadIdJsArr, "SUMMARY_VOUCHER_HEAD_ID");
		if(updateHeadIdArr==null||updateHeadIdArr.length==0) return true;
		//根据数据来源编码确认核算状态
		String accountStatusEnumId = AccConstantUtil.IMPORT.equals(sourceCode) ? AccEnumUtil.IMPORT_SUCCESS.getValue()
				: AccConstantUtil.VALIDATE.equals(sourceCode) ? AccEnumUtil.VOUCHER_CREATED.getValue() : "";
		//得到更新汇总凭证头表核算状态的sql
		String updateSql = AccWebErpSqlUtil.getWriteBackBusinessTableSql(sumVouTableName,
				"ACCOUNTING_STATUS_ENUM_ID", accountStatusEnumId, "SUMMARY_VOUCHER_HEAD_ID",
				"'" + StringUtils.join(updateHeadIdArr, "','") + "'",sysUser==null?0:sysUser.cloudUserId);
		boolean updateFlag = ser.execUpdateSql(updateSql, logicDB);
		if (updateFlag) {
			logger.info(sourceCode+"接口回写,回写业务表" + sumVouTableName+ "的最后修改人、最后修改时间、核算状态="
					+accountStatusEnumId + "修改数据的SUMMARY_VOUCHER_HEAD_ID为:"+ StringUtils.join(updateHeadIdArr, ","));
			// 记录日志
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest(sysUser, "0",
					SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE, SMPAccLogServiceUtil.BACTH, "0",
					SMPAccLogServiceUtil.TABLE_OPRT, sumVouTableName,
					sourceCode+"接口回写,回写业务表" + sumVouTableName+ "的最后修改人、最后修改时间、核算状态="
							+accountStatusEnumId + "修改数据的SUMMARY_VOUCHER_HEAD_ID为:"+ StringUtils.join(updateHeadIdArr, ","));
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
		return updateFlag;
	}
	/**
	 * 实现功能：总账接口调用失败时状态、失败信息回写
	 * @param module	模块标识：“invc”代表发票模块   “settle”代表结算模块
	 * @param fail	失败信息集合
	 * @param sysUser 操作用户
	 */
	public void updateGLFail(String module, JSONArray fail,SysUser sysUser) {
		StringBuffer queryStringBuffer = new StringBuffer();
		StringBuffer queryHead = new StringBuffer();
		String conditon = "";
		String headCondition = "";
		if(fail.size() > 0){
			queryStringBuffer.append(" update ?l ");
			queryStringBuffer.append(" set  ERROR_MESSAGE =");
			queryStringBuffer.append(" CASE ERP_PRI_KEY ");
			for(int i = 0;i < fail.size(); i++){
				JSONObject o = fail.getJSONObject(i);
				queryStringBuffer.append(" WHEN  ");
				queryStringBuffer.append("'"+o.keySet().iterator().next()+"'");
				queryStringBuffer.append(" THEN  ");
				queryStringBuffer.append("'"+o.get(o.keySet().iterator().next())+"'");
				if(StringUtils.isNotEmpty(o.keySet().iterator().next())){
					conditon += "'" + o.keySet().iterator().next()+"',";
				}
			}

			queryStringBuffer.append(" END ,");
			queryStringBuffer.append(" LAST_UPDATED_BY ="+sysUser.cloudUserId+",LAST_UPDATE_DATE = now() ");
			queryStringBuffer.append(" WHERE ERP_PRI_KEY in ( ");
			if(StringUtils.isNotEmpty(conditon)){
				queryStringBuffer.append(conditon.substring(0,conditon.length() - 1));
			}
			queryStringBuffer.append(" ) ");

			//更新汇总凭证头状态
			headCondition = AccWebErpSqlUtil.getHeadCondition(module,fail);
			queryHead.append(" update ?h ");
			queryHead.append(" set GEN_INTERFACE_STAT_ENUM_ID = '"+ AccEnumUtil.IMPORTFAIL.getValue() +"',WB_SERVICE_MESSAGE='总账导入失败!', ");
			queryHead.append(" LAST_UPDATED_BY ="+sysUser.cloudUserId+",IMP_ERP_DATE = now(),LAST_UPDATE_DATE = now() ");
			queryHead.append(" WHERE ERP_MODULE ="+ AccEnumUtil.ERP_GL.getValue() +" and SUMMARY_VOUCHER_HEAD_ID in ( ");
			queryHead.append(headCondition);
			queryHead.append(" ) ");
		}
		//更新汇总凭证行错误信息
		if(!"".equals(queryStringBuffer.toString())){
			updateResult(module,queryStringBuffer.toString());
			logger.info("更新["+module+"库汇总凭证行表]中ERP_PRI_KEY为["+conditon+"]的总账数据导入失败错误信息");
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, conditon, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, conditon, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_L,
							"更新[发票库汇总凭证行表]中ERP_PRI_KEY为["+conditon+"]的总账数据导入失败错误信息");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
		//跟新汇总凭证头错误状态
		if(!"".equals(headCondition)){
			logger.info("更新["+module+"库汇总凭证头表]中SUMMARY_VOUCHER_HEAD_ID为["+headCondition+"]的总账数据导入失败错误信息");
			updateResult(module,queryHead.toString());
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, headCondition, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, headCondition, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H,
							"更新[发票库汇总凭证头表]中SUMMARY_VOUCHER_HEAD_ID为["+headCondition+"]的总账数据导入失败错误信息");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
	}
	/**
	 * 实现功能：总账接口调用失败时，导入未成功且无错误信息返回的数据待导入状态回写
	 * @param module 模块标识：“invc”代表发票模块   “settle”代表结算模块
	 * @param tobeImportArr	将要回写为待导入的数据
	 * @param sysUser 操作用户
	 * @author yangyancq
	 */
	public void updateGLTobeImport(String module, JSONArray tobeImportArr,SysUser sysUser) {
		StringBuffer queryHead = new StringBuffer();
		StringBuffer queryLine = new StringBuffer();
		if(tobeImportArr.size() > 0){
			//更新导入未成功且无错误信息返回、状态为导入中的数据，更新为待导入
			String headCondition = AccWebErpSqlUtil.getImportingHeadCondition(module,tobeImportArr);
			queryHead.append(" update ?h ");
			queryHead.append(" set GEN_INTERFACE_STAT_ENUM_ID = '"+ AccEnumUtil.TOBEIMPORT.getValue() +"', ");
			queryHead.append(" LAST_UPDATED_BY ="+sysUser.cloudUserId+",LAST_UPDATE_DATE = now() ");
			queryHead.append(" WHERE SUMMARY_VOUCHER_HEAD_ID in ( ");
			queryHead.append(headCondition);
			queryHead.append(" ) and GEN_INTERFACE_STAT_ENUM_ID = '"+ AccEnumUtil.IMPORTING.getValue() +"'");

			//更新汇总凭证行错误信息sql封装
			String condition = "";
			//拼装条件
			for(int i = 0 ; i < tobeImportArr.size(); i++){
				condition += "'" + tobeImportArr.getString(i) + "'" + ",";
			}
			condition = condition.substring(0, condition.length()-1);
			queryLine.append(" update ?l ");
			queryLine.append(" set ERROR_MESSAGE = '因同批次有导入失败数据导致当前数据未导入!', ");
			queryLine.append(" LAST_UPDATED_BY ="+sysUser.cloudUserId+",LAST_UPDATE_DATE = now() ");
			queryLine.append(" WHERE ERP_PRI_KEY IN ( " + condition + " )");
			//更新汇总凭证头导入状态为待导入
			updateResult(module,queryHead.toString());
			logger.info("更新["+module+"库汇总凭证头表]中接口状态为导入中SUMMARY_VOUCHER_HEAD_ID为["+headCondition+"]的总账数据接口状态为[待导入]");
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, headCondition, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, headCondition, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H,
							"更新["+module+"库汇总凭证头表]中接口状态为导入中SUMMARY_VOUCHER_HEAD_ID为["+headCondition+"]的总账数据接口状态为[待导入]");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
			//更新汇总凭证行错误信息字段
			updateResult(module,queryLine.toString());
			logger.info("更新["+module+"库汇总凭证行表]中ERP_PRI_KEY为["+condition+"]的总账数据导入失败错误信息为空");
			SMPWriteLogRequest logReq = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, condition, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, condition, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_L,
							"更新["+module+"库汇总凭证行表]中ERP_PRI_KEY为["+condition+"]的总账数据导入失败错误信息为空");
			SMPAccLogServiceUtil.asyncWriteLog(logReq);
		}
	}
	/**
	 * 实现功能：总账接口调用失败时，导入异常的数据等待验证状态回写
	 * @param module 模块标识：“invc”代表发票模块   “settle”代表结算模块
	 * @param waitCheckArr	将要回写为待导入的数据
	 * @param sysUser 操作用户
	 * @author yangyancq
	 */
	public void updateGLToWaitCheck(String module, JSONArray waitCheckArr,SysUser sysUser) {
		StringBuffer queryHead = new StringBuffer();
		StringBuffer queryLine = new StringBuffer();
		if(waitCheckArr != null && waitCheckArr.size() > 0){
			//更新导入未成功且无错误信息返回、状态为导入中的数据，更新为待导入
			String headCondition = AccWebErpSqlUtil.getImportingHeadCondition(module,waitCheckArr);
			queryHead.append(" update ?h ");
			queryHead.append(" set GEN_INTERFACE_STAT_ENUM_ID = '"+ AccEnumUtil.IMPORTFAIL.getValue() +"', ");
			queryHead.append(" LAST_UPDATED_BY ="+sysUser.cloudUserId+",LAST_UPDATE_DATE = now() ");
			queryHead.append(" WHERE SUMMARY_VOUCHER_HEAD_ID in ( ");
			queryHead.append(headCondition);
			queryHead.append(" ) and GEN_INTERFACE_STAT_ENUM_ID = '"+ AccEnumUtil.IMPORTING.getValue() +"'");

			//更新汇总凭证行错误信息sql封装
			String condition = "";
			//拼装条件
			for(int i = 0 ; i < waitCheckArr.size(); i++){
				condition += "'" + waitCheckArr.getString(i) + "'" + ",";
			}
			condition = condition.substring(0, condition.length()-1);
			queryLine.append(" update ?l ");
			queryLine.append(" set ERROR_MESSAGE = '" + AccConstantUtil.IMP_ERP_FAIL_WAIT_MESSAGE).append("',");
			queryLine.append(" LAST_UPDATED_BY ="+sysUser.cloudUserId+",LAST_UPDATE_DATE = now() ");
			queryLine.append(" WHERE ERP_PRI_KEY IN ( " + condition + " )");
			//更新汇总凭证头导入状态为等待验证
			updateResult(module,queryHead.toString());
			logger.info("更新["+module+"库汇总凭证头表]中接口状态为导入中SUMMARY_VOUCHER_HEAD_ID为["+headCondition+"]的总账数据接口状态为[等待验证]");
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, headCondition, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, headCondition, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H,
							"更新["+module+"库汇总凭证头表]中接口状态为导入中SUMMARY_VOUCHER_HEAD_ID为["+headCondition+"]的总账数据接口状态为[等待验证]");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
			//更新汇总凭证行错误信息字段
			updateResult(module,queryLine.toString());
			logger.info("更新["+module+"库汇总凭证行表]中ERP_PRI_KEY为["+condition+"]的总账数据导入失败错误信息为空");
			SMPWriteLogRequest logReq = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, condition, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, condition, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_L,
							"更新["+module+"库汇总凭证行表]中ERP_PRI_KEY为["+condition+"]的总账数据导入异常错误信息");
			SMPAccLogServiceUtil.asyncWriteLog(logReq);
		}
	}

	/**
	 * 实现功能：调用总账接口成功，更新汇总凭证表信息
	 * @param module 模块类别
	 * @param success 成功数据集
	 * @param sysUser 操作用户
	 */
	public void updateGLSuccess(String module, JSONArray success,SysUser sysUser) {
		//汇总凭证头表状态更新sql
		String sql = "";
		//汇总凭证行表返回信息更新sql
		String voulSql = "";
		//操作日志更新ERP_PRI_KEY字段
		String condition = "";
		String priKeyCondition = "";
		//按批次更新汇总凭证头状态和批名
		for(int i =0 ; i < success.size() ; i++){
			JSONObject o = success.getJSONObject(i);
			//将导入成功的总账凭证信息转成JSON格式
			JSONArray jsons = o.getJSONArray(o.keySet().iterator().next());
			//拼装条件
			for(int j = 0 ; j < jsons.size(); j++){
				priKeyCondition += "'" + jsons.get(j) + "'" + ",";
			}
			sql += AccWebErpSqlUtil.getStatusSql(module,o,sysUser) + ";";
			voulSql += AccWebErpSqlUtil.getUpdateLineSuccessSql(o,sysUser) + ";";
		}
		priKeyCondition = "".equals(priKeyCondition)?"":priKeyCondition.substring(0,priKeyCondition.length()- 1);
		if(StringUtils.isNotEmpty(priKeyCondition)){
			condition +=  AccWebErpSqlUtil.getHeadIdByPriKey(module,priKeyCondition);
		}
		if(!"".equals(sql)){
			updateResult(module,sql);
			logger.info(module+"库[汇总凭证头表]主键ID为["+condition+"]的总账数据导入接口状态更新为[导入成功]");
			//更新头表导入成功操作日志
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, condition, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, condition, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H,
							"[发票库汇总凭证头表]主键ID为["+condition+"]的总账数据导入接口状态更新为[导入成功]");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
		if(!"".equals(voulSql)){
			updateResult(module,voulSql);
			logger.info(module+"[汇总凭证行表]头表ID为["+condition+"]的总账数据错误信息更新为[总账导入成功]");
			//更新行表导入成功操作日志
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, condition, SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, condition, SMPAccLogServiceUtil.TABLE_OPRT,
							AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_L,
							"[发票库汇总凭证行表]头表ID为["+condition+"]的总账数据错误信息更新为[总账导入成功]");
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
		//预付款核销总账时，回写预付款核销历史记录表
		if(AccConstantUtil.INVC.equals(module) && StringUtils.isNotEmpty(condition)){
			updateGLPreBillHisTableAccStatusByHeadId(condition, AccConstantUtil.IMPORT, sysUser);
		}
	}
	/*
	 * 总账根据汇总凭证查询回写预付款核销历史记录表
	 *
	 */
	public void updateGLPreBillHisTableAccStatusByHeadId(String headIds, String source,SysUser sysUser){
		if(StringUtils.isEmpty(headIds)){
			return ;
		}
		//根据汇总凭证头ID查询是否是预付款核销凭证，并返回预付款批次号信息
		JSONArray prepayBatchIdArr = BaseDaoUtil.queryForJSONArray(
				AccWebErpSqlUtil.getSumAccInfoByHeadIdSql(AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H, headIds),
				null, LogicDB.INVC_DB, null);
		if(!CollectionUtils.isEmpty(prepayBatchIdArr)){
			boolean updatePreBillHisTableFlag = accComWebService.updatePreBillHisTableAccStatus(prepayBatchIdArr,
					source, sysUser);
			if(updatePreBillHisTableFlag){
				logger.info("总账无预付款批次号，不是预付款核销凭证,无需更新核销历史表!,汇总凭证ID:{}",headIds);
				logger.info("核销历史记录表更新失败，无需更新业务表状态!");
			}
		}else{
			logger.info("总账无预付款批次号，不是预付款核销凭证,无需更新核销历史表!,汇总凭证ID:{}",headIds);
		}
	}
	/*
	 * ERP-3217：新增应付票据
	 * 应付票据导入总账时回写业务表
	 */
	public void updateBillBusiStatusByHeadId(String keyModule, String status, String headIds, SysUser sysUser){
		if(StringUtils.isEmpty(headIds)){
			return ;
		}
		AccCommonService commonService = new AccCommonService();
		LogicDB db = LogicDB.PAY_DB;//数据库
		String table = "T_SAC_PAYMENT_BILL_SUM_VOU_H";
		//根据汇总凭证头表的汇总凭证头获取单据信息ID
		String[] infoIds = accComWebService.getDocumentInfoIdByHeadIdToArr(headIds, db, table);
		//获取更新业务表状态的sql语句
		//根据单据信息ID查询汇总凭证表，返回状态为status状态的ID
		String[] sussessInfoIdArr = accComWebService.getSuccessIdsByInfoIdSql(db, table, infoIds, status);
		String sql = AccWebErpSqlUtil.getHeadCheckBillSql(status, sussessInfoIdArr, sysUser);
		logger.info("更新应付票据业务表sql:"+ sql);
		boolean flag = commonService.execUpdateSql(db, sql);
		if(flag){
			logger.info(sussessInfoIdArr + "更新业务表成功");
		}
	}
	/**
	 * 实现功能：更新业务数据状态(支付、发票)
	 * @param keyModule 模块类别
	 * @param status 状态
	 * @param headIds 汇总凭证头ID
	 * @param prebillFlag 预付款核销标记
	 * @param sysUser 操作用户
	 */
	public GeneralServiceResponse updateBusiStatusByHeadId(String keyModule,String status,String headIds,boolean prebillFlag,SysUser sysUser) {
		GeneralServiceResponse generalServiceResponse = new GeneralServiceResponse();
		generalServiceResponse.params = new HashMap<>();
		if(StringUtils.isEmpty(headIds)){
			generalServiceResponse.isSuccess = false;
			return generalServiceResponse;
		}
		String source = AccEnumUtil.VOUCHER_CREATED.getValue().equals(status) ? AccConstantUtil.VALIDATE
				: AccConstantUtil.IMPORT;
		AccCommonService commonService = new AccCommonService();//核算基础服务
		LogicDB logicDB = AccConstantUtil.PAY.equals(keyModule)?LogicDB.PAY_DB:LogicDB.INVC_DB;
		String table = AccConstantUtil.PAY.equals(keyModule)?
				AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H:AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H;
		if(AccConstantUtil.CHANGEPAY.equals(keyModule)){
			logicDB = LogicDB.PAY_DB;
			table = AccConstantUtil.T_SAC_PAYMENT_ACC_SUM_VOU_H;
		}
		//根据汇总凭证头表的汇总凭证头ID获取单据信息ID
		String[] infoIds = accComWebService.getDocumentInfoIdByHeadIdToArr(headIds,logicDB,table);
		//获取更新业务表状态的sql语句
		//根据单据信息ID查询汇总凭证表，返回状态为status状态的ID
		//String[] sussessInfoIdArr = accComWebService.getSuccessIdsByInfoIdSql(db,table,infoIds,status);
		String sussessInfoSql = AccWebErpSqlUtil.getBussTabImpOrValiSussessPriKeySql(table,
				StringUtils.join(infoIds, ","), false, source, prebillFlag);
		JSONArray docInfoIdJsArr = BaseDaoUtil.queryForJSONArray(sussessInfoSql, null, logicDB, null);
		// 反向过滤汇总凭证头表中核算状态导入或验证成功的单据信息id
		String[] sussessInfoIdArr = AccCommonHelper.getAllSussElementValues(docInfoIdJsArr, "DOCUMENT_INFO_ID");
		String sql = AccWebErpSqlUtil.getHeadCheckInvSql(status,prebillFlag,sussessInfoIdArr,sysUser);
		if(AccConstantUtil.PAY.equals(keyModule)){
			sql = AccWebErpSqlUtil.getHeadCheckPaySql(status,sussessInfoIdArr,sysUser);
		}
		if(AccConstantUtil.CHANGEPAY.equals(keyModule)){
			sql = AccWebErpSqlUtil.getHeadCheckChangePaySql(status,sussessInfoIdArr,sysUser);
		}
		//发票库，开票信息表业务状态更新
		if(StringUtils.isNotEmpty(sql)){
			boolean flag = commonService.execUpdateSql(logicDB, sql);
			generalServiceResponse.isSuccess=flag;
			//ERP-1894发票核算成功后再允许发起支付申请-触发推送
			//发票核算成功，即开票模板状态变为已入账后再推送支付，才可以发起支付申请。 以避免发起支付的时候，才发现发票核算有问题
			if(flag && AccEnumUtil.VOUCHER_CREATED.getValue().equals(status)
					&& AccConstantUtil.INVC.equals(keyModule) && !prebillFlag){
				logger.info(sussessInfoIdArr+"已入账，推送支付begin!");
				String infoIdShardingIdSql = AccWebErpSqlUtil.getShardingIdByInfoIds(sussessInfoIdArr);
				List<Map<String, String>> infoAndShardingIdList = commonService.execQueryListSql(infoIdShardingIdSql, logicDB);
				InvcUpdateBillDataServicePrx invcQueryBillDataService = (InvcUpdateBillDataServicePrx)ICEClientUtil.getSerivcePrx(InvcUpdateBillDataServicePrx.class);
				InvoiceVisualizationServicePrx invoiceVisualizationService = (InvoiceVisualizationServicePrx)ICEClientUtil.getSerivcePrx(InvoiceVisualizationServicePrx.class);
				for (int i = 0; i < infoAndShardingIdList.size(); i++) {
					Map<String, String> idMap = infoAndShardingIdList.get(i);
					//ERP-4147订单可视化——开票单核算入账后数据回传
					String billingCode = StringUtils.isEmpty(idMap.get("BILLING_CODE"))?"1":idMap.get("BILLING_CODE");
					if(/*!billingCode.startsWith("H") &&
					 */!SystemProperties.SYSTEM_DEPLOYMENT_ONB.equals(SystemProperties.getProperties("deployment"))){
						Map<String, String> paramMap = new HashMap<>();
						paramMap.put("billingId", idMap.get("BILLING_INFO_ID"));
						paramMap.put("shardingId", idMap.get("SHARDING_ID"));
						logger.info("订单可视化——开票单核算入账后数据回传:{}",JSON.toJSONString(paramMap));
						invoiceVisualizationService.insertSettleOrderProgress(paramMap);
						logger.info("商旅交通单据入账后实时调用税务接口传送账期信息开始{}",JSON.toJSONString(paramMap));
						invoiceVisualizationService.accountEntryCallTax(paramMap);
					}
					logger.info("invoke pushGroupSumToPayModule("+idMap.get("BILLING_INFO_ID")+","+idMap.get("SHARDING_ID"));
					invcQueryBillDataService.pushGroupSumToPayModule(Long.parseLong(idMap.get("BILLING_INFO_ID")),idMap.get("SHARDING_ID"));
					//ERP-3191 贷项通知单入账后调用释放接收的接口
					/**
					 * 调用释放的接口（仅正向的贷项通知单需要调用，作废的时候不需要调用），
					 * 可以根据billing_info表的CREDIT_MEM_FLAG判断是否为贷项通知单，该字段为1就是贷项通知单
					 */
					String creditMemFlag = idMap.get("CREDIT_MEM_FLAG");
					if(StringUtils.isNotEmpty(creditMemFlag) && "1".equals(creditMemFlag)){
						accComWebService.asyncInsertCompletedCreditNoticeDetail(Long.parseLong(idMap.get("BILLING_INFO_ID")),idMap.get("SHARDING_ID"));
					}
				}
				logger.info(sussessInfoIdArr+"已入账，推送支付end!");
			}
			//ERP-4580  能耗预付款退款-预付款退款核销凭证自动核算
			if (flag && AccEnumUtil.VOUCHER_CREATED.getValue().equals(status) && AccConstantUtil.INVC.equals(keyModule)
					&& !prebillFlag) {
				//触发核销核算的billInfoId返回至web层
				logger.info(sussessInfoIdArr+"总账入账能耗预付款退款-预付款退款核销凭证自动核算begin!");
				JSONArray jsonArray = new JSONArray();
				String infoIdShardingIdSql = AccWebErpSqlUtil.getWriteOffIdByInfoIds(sussessInfoIdArr);
				logger.info("能耗预付款退款-预付款退款核销凭证自动核算 sql = " + infoIdShardingIdSql);
				List<Map<String, String>> infoAndShardingIdList = commonService.execQueryListSql(infoIdShardingIdSql, logicDB);
				for(Map<String, String> map : infoAndShardingIdList){
					if("1".equals(map.get("ATTRIBUTE3"))){
						jsonArray.add(map.get("BILLING_INFO_ID"));
					}
				}
				Map<String, String> res = new HashMap<>();
				res.put("res"+System.currentTimeMillis(),jsonArray.toJSONString());
				generalServiceResponse.params = res;
				logger.info("能耗预付款退款-预付款退款核销凭证自动核算end! 结果="+jsonArray.toJSONString());
			}
			//ERP-4527 票据管理—单据入账后调用发票、付款推送税务接口
			//发票推税务接口已入账、更新表为发票
			if (flag && AccEnumUtil.VOUCHER_CREATED.getValue().equals(status) && AccConstantUtil.INVC.equals(keyModule)
					&& !prebillFlag) {
				logger.info("发票{}入账，推送税务接口begin!",StringUtils.join(sussessInfoIdArr, ","));
				//异步调用
				new Thread(){
					public void run(){
						InvcTicketManageServicePrx invcTicketManageService = (InvcTicketManageServicePrx) ICEClientUtil
								.getSerivcePrx(InvcTicketManageServicePrx.class);
						Map<String, String> resMap = new HashMap<>();
						resMap.put("billingInfoId", StringUtils.join(sussessInfoIdArr, ","));
						resMap.put("status", "4");
						resMap.put("pushModule","核算模块");
						resMap.put("operationDesc","总账接口调用状态回写updateBusiStatusByHeadId->发票{"+StringUtils.join(sussessInfoIdArr, ",")+"}入账，推送税务接口");
						InvcSysUser sysUser = new InvcSysUser();
						sysUser.cloudOrgId = "999999999";
						sysUser.cloudUserId = 999999999;
						sysUser.userid = "999999999";
						sysUser.empName = "systemUser";
						InvcBasicResponse invcBasicResponse = invcTicketManageService.pushTaxAttachment(resMap, sysUser);
						logger.info("总账接口调用状态回写updateBusiStatusByHeadId->发票{}入账，推送税务接口response={}",sussessInfoIdArr,invcBasicResponse.msg);
					}
				}.start();
				logger.info("发票{}入账，推送税务接口end!",StringUtils.join(sussessInfoIdArr, ","));
			}
			//付款推税务接口已入账、更新表为发票
			if(flag && AccEnumUtil.VOUCHER_CREATED.getValue().equals(status) && AccConstantUtil.PAY.equals(keyModule)){
				//异步调用
				new Thread(){
					public void run(){
						logger.info("付款{}入账，推送税务接口begin!",StringUtils.join(sussessInfoIdArr, ","));
						//付款推支付判断：
						//1）：推送标识为1，则判断该付款单下所有清单核算状态是否为已入账（排除无需核算5000410）
						//2) ：所有付款清单均为已入账，调用支付推送税务接口；
						//根据付款清单查询付款单推送标识和是否全部清单入账
						LogicDB logicDB = AccConstantUtil.PAY.equals(keyModule) ? LogicDB.PAY_DB : LogicDB.INVC_DB;
						String pushPaymentInfoIdSql = AccWebErpSqlUtil.getPushPaymentInfoIdByListId(StringUtils.join(sussessInfoIdArr, ","));
						List<Long> pushPaymentInfoIdList = BaseDaoUtil.queryForList(pushPaymentInfoIdSql, logicDB, null, Long.class);
						if(CollectionUtils.isEmpty(pushPaymentInfoIdList)){
							logger.info("付款入账数据中无推送税务标记为1的数据，无需推送!");
							return;
						}
						logger.info("付款推送税务标记为1的数据{}!",StringUtils.join(pushPaymentInfoIdList, ","));
						String paymentAccountStatusSql = AccWebErpSqlUtil.getAccountStatusByPaymentInfoId(StringUtils.join(pushPaymentInfoIdList, ","));
						JSONArray paymentAccountStatusArray = BaseDaoUtil.queryForJSONArray(paymentAccountStatusSql, null, logicDB, null);
						if(CollectionUtils.isEmpty(paymentAccountStatusArray)){
							logger.info("付款推送税务标记为1的数据未全部入账，无需推送!");
							return;
						}
						List<String> tobePushIdList = new ArrayList<String>();
						//判断付款单对应清单是否全部入账
						for (int i = 0; i < paymentAccountStatusArray.size(); i++) {
							if(((Integer) 0).equals(paymentAccountStatusArray.getJSONObject(i).getInteger("FLAG")) ){
								tobePushIdList.add(paymentAccountStatusArray.getJSONObject(i).getString("PAYMENT_INFO_ID"));
							}
						}
						if(!CollectionUtils.isEmpty(tobePushIdList)){
							logger.info("付款推送税务接口数据{}!",StringUtils.join(tobePushIdList, ","));
							PaySysUser user = new PaySysUser();
							SysUser sysUser = new SysUser();
							sysUser.cloudOrgId = "999999999";
							sysUser.cloudUserId = 999999999;
							sysUser.userid = "999999999";
							sysUser.empName = "systemUser";
							user.sysUser = sysUser;
							Map<String, String> params = new HashMap<>();
							params.put("paymentId", StringUtils.join(tobePushIdList, ","));
							params.put("status", "4");
							params.put("pushModule","核算模块");
							params.put("operationDesc","总账接口调用状态回写updateBusiStatusByHeadId->付款{"+StringUtils.join(tobePushIdList, ",")+"}入账，推送税务接口");
							PaymentProcessUpdaterServicePrx paymentProcessUpdaterService = (PaymentProcessUpdaterServicePrx) ICEClientUtil
									.getSerivcePrx(PaymentProcessUpdaterServicePrx.class);
							BasicPayResponse response = paymentProcessUpdaterService.checkAndPushAttachment(params, user);
							logger.info("总账接口调用状态回写updateBusiStatusByHeadId->付款{}入账，推送税务接口response={}",StringUtils.join(tobePushIdList, ","),response.msg);
						}else{
							logger.info("付款推送税务标记为1的付款单未无全部入账，无需推送!");
						}
						logger.info("付款{}入账，推送税务接口end!",StringUtils.join(sussessInfoIdArr, ","));
					}
				}.start();
			}
			//业务数据状态回写操作日志
			table = AccConstantUtil.PAY.equals(keyModule)?AccConstantUtil.T_SAC_PAYMENT_LIST:AccConstantUtil.T_SAC_BILLING_INFO;
			SMPWriteLogRequest logRequest = SMPAccLogServiceUtil.getSMPWriteLogRequest
					(sysUser, sussessInfoIdArr.toString(), SMPAccLogServiceUtil.INFO, SMPAccLogServiceUtil.UPDATE,
							SMPAccLogServiceUtil.BACTH, "", SMPAccLogServiceUtil.TABLE_OPRT, table,
							table+"业务表接口状态["+status+"]更新的操作:"+ flag);
			SMPAccLogServiceUtil.asyncWriteLog(logRequest);
		}
		return generalServiceResponse;
	}
	/**
	 *
	 * @Title: updateGLBusiStatusByHeadId
	 * @Description: 总账回写业务表状态
	 * @param keyModule 模块
	 * @param status 导入/验证状态
	 * @param headIds 汇总凭证头
	 * @param sysUser
	 * void
	 * @exception:可能抛出的异常
	 */
	public GeneralServiceResponse updateGLBusiStatusByHeadId(String keyModule, String status, String headIds, SysUser sysUser){
		GeneralServiceResponse generalServiceResponse = new GeneralServiceResponse();
		generalServiceResponse.params = new HashMap<>();
		if(AccConstantUtil.BILL.equals(keyModule)){
			//ERP-3217:新增应付票据（回写业务表）
			updateBillBusiStatusByHeadId(keyModule,status,headIds,sysUser);
			return generalServiceResponse;
		}else if(AccConstantUtil.INVC.equals(keyModule)){
			String voucherTypeSql = AccWebErpSqlUtil.getVoucherTypeBySumHeadIdSql(headIds, AccConstantUtil.T_SAC_BILLING_ACC_SUM_VOU_H);
			JSONArray voucherTypeArr = BaseDaoUtil.queryForJSONArray(voucherTypeSql, null, LogicDB.INVC_DB, null);
			Set<String> billHeadIds = new HashSet<String>();
			Set<String> prebillHeadIds = new HashSet<String>();
			for (int i = 0; i < voucherTypeArr.size(); i++) {
				JSONObject obj = voucherTypeArr.getJSONObject(i);
				if(AccEnumUtil.PREBILL_VOUCHER.getValue().equals(obj.getString("VOUCHER_TODO_TYPE"))){
					prebillHeadIds.add(obj.getString("SUMMARY_VOUCHER_HEAD_ID"));
				}else{
					billHeadIds.add(obj.getString("SUMMARY_VOUCHER_HEAD_ID"));
				}
			}
			if(!CollectionUtils.isEmpty(billHeadIds)){
				generalServiceResponse.params.putAll(updateBusiStatusByHeadId(keyModule, status, StringUtils.join(billHeadIds, ","), false, sysUser).params);
			}
			if(!CollectionUtils.isEmpty(prebillHeadIds)){
				updateBusiStatusByHeadId(keyModule,status,StringUtils.join(prebillHeadIds, ","),true,sysUser);
			}
			return generalServiceResponse;
		}else{
			generalServiceResponse=updateBusiStatusByHeadId(keyModule,status,headIds,false,sysUser);
			return generalServiceResponse;
		}
	}
}
