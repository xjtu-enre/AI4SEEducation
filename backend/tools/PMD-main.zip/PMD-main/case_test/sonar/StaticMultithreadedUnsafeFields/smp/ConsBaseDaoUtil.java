package com.dtt.sett.utils;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.dtt.sett.framework.dao.BaseDaoUtil;
import com.dtt.sett.framework.dao.DataSourceConnet;
import com.dtt.sett.framework.dao.LogicDB;
import com.dtt.sett.framework.dao.PreparedStatementParamSetter;
import com.dtt.sett.framework.exception.SMPException;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.IncorrectResultSizeDataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.RowMapperResultSetExtractor;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.util.Assert;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConsBaseDaoUtil extends BaseDaoUtil {
    private final static Logger logger = LoggerFactory.getLogger(ConsBaseDaoUtil.class);


    public static <T> T queryForObject(String sql, LogicDB logicDB, List<Object> params, Class<T> requiredType) throws DataAccessException {
        return queryForObject(sql, logicDB, params, getSingleColumnRowMapper(requiredType));
    }

    public static Map<String, Object> queryForMap(String sql, LogicDB logicDB, List<Object> params) throws DataAccessException {
        return queryForObject(sql, logicDB, params, getColumnMapRowMapper());
    }

    public static List<Map<String, Object>> queryForMapList(String sql, LogicDB logicDB, List<Object> params) throws DataAccessException {
        return query(sql, logicDB, params, getColumnMapRowMapper());
    }

    public static <T> List<T> queryForList(String sql, LogicDB logicDB, List<Object> params, Class<T> elementType) throws DataAccessException {
        return query(sql, logicDB, params, getSingleColumnRowMapper(elementType));
    }

    public static <T> List<T> queryForList(String sql, LogicDB logicDB, List<Object> params, RowMapper<T> rowMapper) throws DataAccessException {
        return query(sql, logicDB, params, rowMapper);
    }

    public static <T> T queryForObject(String sql, LogicDB logicDB, List<Object> params, RowMapper<T> rowMapper) throws DataAccessException {
        List<T> results = query(sql, logicDB, params, rowMapper);
        int size = (results != null) ? results.size() : 0;
        if (size == 0) {
            logger.warn("没有查询到任何结果，逻辑库：{}, SQL:{}", logicDB.getText(), sql);
            return null;
        }
        if (results.size() > 1) {
            logger.error("有多条查询结果，请检查SQL或使用逻辑是否错误，逻辑库：{}, SQL:{}", logicDB.getText(), sql);
            throw new IncorrectResultSizeDataAccessException(1, size);
        }
        return results.iterator().next();
    }


    /**
     * Query data according to logic DB, sql scripts and parameter list.<br/>
     * 根据逻辑数据库，SQL语句 和参数列表查询获取数据，并返回ResultSet对象。
     * @param sql SQL语句
     * @param logicDB 逻辑数据库
     * @param params 参数列表
     * @param rowMapper Mapper接口
     * @return ResultSet 结果集
     */
    public static <T> List<T> query(String sql, LogicDB logicDB, List<Object> params, RowMapper<T> rowMapper) {
        return query(sql, logicDB, ps -> {
            if (null != params) {
                for (int i = 0; i < params.size(); i++) {
                    Object p = params.get(i);
                    if (p instanceof Integer) {
                        ps.setInt(i + 1, (Integer) p);
                    } else if (p instanceof String) {
                        ps.setString(i + 1, (String) p);
                    }else if(p instanceof Character){
                        ps.setString(i + 1, String.valueOf(p));
                    } else if (p instanceof Blob) {
                        ps.setBlob(i + 1, (Blob) p);
                    } else if (p instanceof Long) {
                        ps.setLong(i + 1, (Long) p);
                    } else if (p instanceof Boolean) {
                        ps.setBoolean(i + 1, (Boolean) p);
                    } else if (p instanceof BigDecimal) {
                        ps.setBigDecimal(i + 1, (BigDecimal) p);
                    } else if (p instanceof Float) {
                        ps.setFloat(i + 1, (Float) p);
                    } else if (p instanceof Double) {
                        ps.setDouble(i + 1, (Double) p);
                    } else if (p instanceof java.sql.Date) {
                        ps.setDate(i + 1, (java.sql.Date) p);
                    } else if (p instanceof java.sql.Timestamp) {
                        ps.setTimestamp(i + 1, (java.sql.Timestamp) p);
                    } else if (p instanceof java.sql.Time) {
                        ps.setTime(i + 1, (Time) p);
                    } else if (p instanceof java.util.Date) {
                        ps.setTimestamp(i + 1, new java.sql.Timestamp(((java.util.Date) p).getTime()));
                    } else {
                        ps.setObject(i + 1, p);
                    }
                }
            }
        }, rowMapper);
    }


    /**
     * Query data according to logic DB, sql scripts and parameters setter interface<br/>
     * 根据逻辑数据库, SQL语句和参数设置接口查询获取数据，并返回ResultSet对象。
     * @param <T> 数据对象 POJO Bean/DTO
     * @param sql SQL语句
     * @param logicDB 逻辑数据库
     * @param setter Preparedtatement 参数设置接口
     * @param rowMapper Mapper接口
     * @return ResultSet 结果集
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static <T> List<T> query(String sql, LogicDB logicDB, PreparedStatementParamSetter setter,
                                    RowMapper<T> rowMapper) {
        Assert.notNull(sql, "SQL must not be null");
        Assert.notNull(logicDB, "logicDB must not be null");
        Assert.notNull(setter, "PreparedStatementParamSetter must not be null");
        Assert.notNull(rowMapper, "RowMapper must not be null");

        Connection con = null;
        java.sql.PreparedStatement ps = null;
        ResultSet rs = null;
        List<T> result = null;
        try {
            con = (Connection) DataSourceConnet.getConnect(logicDB);
            ps = con.prepareStatement(sql);
            setter.doSetPreparedStatementParams(ps);
            logger.info("SQL Statement: " + ps.toString());
            rs = ps.executeQuery();
            RowMapperResultSetExtractor rse = new RowMapperResultSetExtractor<T>(rowMapper);
            result = (List<T>) rse.extractData(rs);

        } catch (SMPException | SQLException e) {
            logger.error("SQL Exception happened.", e);
            logger.error(BaseDaoUtil.getSqlStatementLogString(sql));
            if (null != ps) {
                logger.error("SQL Statement: " + ps.toString());
            }
        }catch (Exception e){
            logger.error("ConsBaseDaoUtil.query Exception happened.", e);
        }finally {
            if(rs!=null){
                JdbcUtils.closeResultSet(rs);
            }
            if(ps!=null){
                JdbcUtils.closeStatement(ps);
            }
            if (con != null) {
             JdbcUtils.closeConnection(con);
            }
        }
        return result;

    }



    public static int update(String sql, LogicDB logicDB, List<Object> args) {
        int res = 0;
        try {
            res = update(sql, logicDB, ps -> {
                if (null != args) {
                    for (int i = 0; i < args.size(); i++) {
                        Object p = args.get(i);
                        if (p instanceof Integer) {
                            ps.setInt(i + 1, (Integer) p);
                        } else if (p instanceof String) {
                            ps.setString(i + 1, (String) p);
                        }else if(p instanceof Character){
                            ps.setString(i + 1, String.valueOf(p));
                        }  else if (p instanceof Blob) {
                            ps.setBlob(i + 1, (Blob) p);
                        } else if (p instanceof Long) {
                            ps.setLong(i + 1, (Long) p);
                        } else if (p instanceof Boolean) {
                            ps.setBoolean(i + 1, (Boolean) p);
                        } else if (p instanceof BigDecimal) {
                            ps.setBigDecimal(i + 1, (BigDecimal) p);
                        } else if (p instanceof Float) {
                            ps.setFloat(i + 1, (Float) p);
                        } else if (p instanceof Double) {
                            ps.setDouble(i + 1, (Double) p);
                        } else if (p instanceof java.sql.Date) {
                            ps.setDate(i + 1, (java.sql.Date) p);
                        } else if (p instanceof java.sql.Timestamp) {
                            ps.setTimestamp(i + 1, (java.sql.Timestamp) p);
                        } else if (p instanceof java.sql.Time) {
                            ps.setTime(i + 1, (Time) p);
                        } else if (p instanceof java.util.Date) {
                            ps.setTimestamp(i + 1, new java.sql.Timestamp(((java.util.Date) p).getTime()));
                        } else {
                            ps.setObject(i + 1, p);
                        }
                    }
                }
            });
        } catch (SMPException e) {
            logger.error("Exception happened.", e);
        }
        return res;
    }

    public static int update(String sql, LogicDB logicDB, PreparedStatementParamSetter setter) throws SMPException {
        Assert.notNull(sql, "SQL must not be null");
        Assert.notNull(logicDB, "logicDB must not be null");
        logger.info("BaseDaoUtil.update() is running...");
        Connection con = null;
        java.sql.PreparedStatement ps = null;
        int res = 0;

        try {
            con = (Connection) DataSourceConnet.getConnect(logicDB);
            ps = con.prepareStatement(sql);
            setter.doSetPreparedStatementParams(ps);
            res = ps.executeUpdate();
            logger.info("SQL Statement: " + ps.toString());

        } catch (SMPException | SQLException e) {
            logger.error("SQL Exception happened.", e);
            if (null != ps) {
                logger.error("SQL Statement: " + ps.toString());
            }
            throw new SMPException("更新时异常发生:", e);
        }catch (Exception e){
        logger.error("ConsBaseDaoUtil.query Exception happened.", e); }
        finally {
            if(ps!=null){
                JdbcUtils.closeStatement(ps);
            }
            if (con != null) {
                JdbcUtils.closeConnection(con);
            }
        }
        return res;
    }


//===================在业务代码中commit============================

    public static ThreadLocal<Map<String,String>> localMap=new ThreadLocal<>();

    public static Map<String,String> getLocalMap(){
        if(localMap.get()==null){
            localMap.set(new HashMap<>());
        }
        return localMap.get();
    }



    public static int update(String sql, Connection con, List<Object> args) {
        int res = 0;
        try {
            res = update(sql, con, ps -> {
                if (null != args) {
                    for (int i = 0; i < args.size(); i++) {
                        Object p = args.get(i);
                        if (p instanceof Integer) {
                            ps.setInt(i + 1, (Integer) p);
                        } else if (p instanceof String) {
                            ps.setString(i + 1, (String) p);
                        }else if(p instanceof Character){
                            ps.setString(i + 1, String.valueOf(p));
                        }  else if (p instanceof Blob) {
                            ps.setBlob(i + 1, (Blob) p);
                        } else if (p instanceof Long) {
                            ps.setLong(i + 1, (Long) p);
                        } else if (p instanceof Boolean) {
                            ps.setBoolean(i + 1, (Boolean) p);
                        } else if (p instanceof BigDecimal) {
                            ps.setBigDecimal(i + 1, (BigDecimal) p);
                        } else if (p instanceof Float) {
                            ps.setFloat(i + 1, (Float) p);
                        } else if (p instanceof Double) {
                            ps.setDouble(i + 1, (Double) p);
                        } else if (p instanceof java.sql.Date) {
                            ps.setDate(i + 1, (java.sql.Date) p);
                        } else if (p instanceof java.sql.Timestamp) {
                            ps.setTimestamp(i + 1, (java.sql.Timestamp) p);
                        } else if (p instanceof java.sql.Time) {
                            ps.setTime(i + 1, (Time) p);
                        } else if (p instanceof java.util.Date) {
                            ps.setTimestamp(i + 1, new java.sql.Timestamp(((java.util.Date) p).getTime()));
                        } else {
                            ps.setObject(i + 1, p);
                        }
                    }
                }
            });
        } catch (SMPException e) {
            logger.error("Exception happened.", e);
            if(localMap.get()!=null){
                localMap.get().put("eMsg",e.getCause().getMessage());
            }
        }
        return res;
    }

    public static int update(String sql, Connection con, PreparedStatementParamSetter setter) throws SMPException {
        Assert.notNull(sql, "SQL must not be null");
        Assert.notNull(con, "Connection must not be null");
        logger.info("BaseDaoUtil.update() is running...");
        java.sql.PreparedStatement ps = null;
        int res = 0;

        try {
            ps = con.prepareStatement(sql);
            setter.doSetPreparedStatementParams(ps);
            res = ps.executeUpdate();
            logger.info("SQL Statement: " + ps.toString());

        } catch (SQLException e) {
            logger.error("SQL Exception happened.", e);
            if (null != ps) {
                logger.error("SQL Statement: " + ps.toString());
            }
            throw new SMPException("更新时异常发生:", e);
        }catch (Exception e){
            logger.error("ConsBaseDaoUtil.query Exception happened.", e);
            throw new SMPException("更新操作时发生异常:", e);
        }
        finally {
            if(ps!=null){
                JdbcUtils.closeStatement(ps);
            }
/*            if (con != null) {
                JdbcUtils.closeConnection(con);
            }*/
        }
        return res;
    }


    public static int[] batchUpdate(String sql, Connection con, List<List<Object>> batchArgs) {
        return batchUpdate(sql, con, batchArgs, 500, false);
    }

    public static int[] batchUpdate(String sql, Connection con, List<List<Object>> batchArgs, int batchSize) {
        return batchUpdate(sql, con, batchArgs, batchSize, false);
    }

    public static int[] batchUpdate(String sql,Connection con, List<List<Object>> batchArgs, int batchSize, boolean autoCommit) {

        Assert.notNull(sql, "SQL must not be null");
        Assert.notNull(con, "Connection must not be null");
        logger.info("BaseDaoUtil.update() is running...");
        java.sql.PreparedStatement ps = null;
        int[] total = {};
        //List<Object> rowsAffected = new ArrayList<>();

        try {
            //     con = getDaaSConnection(logicDB);
            //     con.setAutoCommit(autoCommit);
            ps = con.prepareStatement(sql);
            int bi = 1;
            for (List<Object> args : batchArgs) {
                if (null != args) {
                    bi++;
                    for (int i = 0; i < args.size(); i++) {
                        Object p = args.get(i);
                        if (p instanceof Integer) {
                            ps.setInt(i + 1, (Integer) p);
                        } else if (p instanceof String) {
                            ps.setString(i + 1, (String) p);
                        } else if (p instanceof Blob) {
                            ps.setBlob(i + 1, (Blob) p);
                        } else if (p instanceof Long) {
                            ps.setLong(i + 1, (Long) p);
                        } else if (p instanceof Boolean) {
                            ps.setBoolean(i + 1, (Boolean) p);
                        } else if (p instanceof BigDecimal) {
                            ps.setBigDecimal(i + 1, (BigDecimal) p);
                        } else if (p instanceof Float) {
                            ps.setFloat(i + 1, (Float) p);
                        } else if (p instanceof Double) {
                            ps.setDouble(i + 1, (Double) p);
                        } else if (p instanceof java.sql.Date) {
                            ps.setDate(i + 1, (java.sql.Date) p);
                        } else if (p instanceof java.sql.Timestamp) {
                            ps.setTimestamp(i + 1, (java.sql.Timestamp) p);
                        } else if (p instanceof java.sql.Time) {
                            ps.setTime(i + 1, (Time) p);
                        } else if (p instanceof java.util.Date) {
                            ps.setTimestamp(i + 1, new java.sql.Timestamp(((java.util.Date) p).getTime()));
                        } else {
                            ps.setObject(i + 1, p);
                        }
                    }
                }

                ps.addBatch();

                if (bi % batchSize == 0) {
                    bi = 1;
                    total=ArrayUtils.addAll(total,ps.executeBatch());
                    ps.clearBatch();
                }
            }
            total=ArrayUtils.addAll(total,ps.executeBatch());
/*            con.commit();
            con.setAutoCommit(true);*/

            logger.info("SQL Statement: " + ps.toString());

        } catch (SQLException e) {
            logger.error("SQL Exception happened.", e);
            logger.error(BaseDaoUtil.getSqlStatementLogString(sql));
            if (null != ps) {
                logger.error("SQL Statement: " + ps.toString());
            }
            if(localMap.get()!=null){
                localMap.get().put("eMsg",e.toString());
            }
        }catch (Exception e){
            logger.error("批处理中发生异常，异常信息",e);
            if(localMap.get()!=null){
                localMap.get().put("eMsg",e.toString());
            }
        }
        finally {
            JdbcUtils.closeStatement(ps);
/*            if (con != null) {
                try {
                    BaseDaoUtil.closeDaaSConnection(con, logicDB);
                } catch (SMPException e) {
                    logger.error("Failed to close connection.", e);
                }
            }*/
        }

       /* int[] total = new int[batchArgs.size()];
        int[][] result = new int[rowsAffected.size()][];
        for (int i = 0; i < result.length; ++i) {
            result[i] = ((int[]) rowsAffected.get(i));
            for (int j = 0; j < result[i].length; ++j) {
                total[(i + 1) * j] = result[i][j];
            }
        }*/
        return total;

    }



    private static final SimpleDateFormat DTF_TIMES =new SimpleDateFormat("yyMMddHHmmssSSS");

    public static String timeId() {
        return DTF_TIMES.format(new java.util.Date()) + RandomStringUtils.randomNumeric(4);
    }




    /**
     * 读取 SQL 文件，获取 SQL 语句
     *
     * @param sqlFile SQL 脚本文件
     * @return List<sql> 返回所有 SQL 语句的 List
     * @throws Exception
     */
    public static List<String> loadSql(String sqlFile) {
        List<String> sqlList = new ArrayList<String>();
        try {
            InputStream sqlFileIn = Thread.currentThread().getContextClassLoader().getResource(sqlFile).openStream();
            StringBuffer sqlSb = new StringBuffer();
            String line;
            BufferedReader br = new BufferedReader(new InputStreamReader(sqlFileIn));
            while ((line = br.readLine()) != null) {
                line = line.replaceAll("--.*", "").trim();
                sqlSb.append(" " + line);

            }
            if (StrUtil.isNotEmpty(sqlSb)) {
                sqlList.add(sqlSb.toString());
            }
        } catch (Exception ex) {
            logger.error("Loading SQL file Exception", ex);
            sqlList = null;
        }

        return sqlList;
    }

    /**
     * 读取 SQL 文件，获取 SQL 语句
     *
     * @param sqlFile SQL 脚本文件
     * @return List<sql> 返回所有 SQL 语句的 List
     * @throws Exception
     */
    public static String loadSingleSql(String sqlFile) {
        List<String> sqlList = loadSql(sqlFile);
        String sql = null;
        if (CollUtil.isNotEmpty(sqlList)) {
            sql = sqlList.get(0);
        } else {
            logger.error("不能读取SQL文件或这SQl文件为空:{}", sqlFile);
            return "";
        }
        return sql;
    }

}
