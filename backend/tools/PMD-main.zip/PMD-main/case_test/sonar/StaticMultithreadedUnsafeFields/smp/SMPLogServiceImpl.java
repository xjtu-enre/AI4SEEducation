package com.dtt.sett.framework.common.service;

import Ice.Current;
import Ice.ObjectAdapter;
import com.dtt.sett.common.GeneralServiceResponse;
import com.dtt.sett.common.SMPQueryLogRequest;
import com.dtt.sett.common.SMPWriteLogRequest;
import com.dtt.sett.common._SMPLogServiceDisp;
import com.dtt.sett.framework.base.DateStyle;
import io.mycat.ice.server.ServantLifcycle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.regex.Pattern;

public class SMPLogServiceImpl extends _SMPLogServiceDisp implements ServantLifcycle {

	private static final long serialVersionUID = 273040959023687010L;
	private final static Logger LOGGER = LoggerFactory.getLogger(SMPLogServiceImpl.class);

	private final static String APP_ID = "BM_9EE23463E6DA432FA57EF1EAE4C164A1";
	private final static String GROUP_APP_ID = "BM_9EE23463E6DA432FA57EF1EAE4C164A1";
	private final static String LOG_LV_DEBUG = "DEBUG";
	private final static String LOG_LV_INFO = "INFO";
	private final static String LOG_LV_WARN = "WARN";
	private final static String LOG_LV_ERROR = "ERROR";
	private final static String LOG_LV_FATAL = "FATAL";

	private final static SimpleDateFormat dateFormat = new SimpleDateFormat(DateStyle.YYYY_MM_DD_HH_MM_SS.getValue());
	private final static Pattern LOG_LV_PATTERN = Pattern.compile("DEBUG|INFO|WARN|ERROR|FATAL");

	public SMPLogServiceImpl() {
		//PaasAgentLoader.startup();
	}

	@Override
	public void init(ObjectAdapter adapter) {
		//PaasAgentLoader.startup();
		//LOGGER.info("启动SMP结算平台操作日志服务======>");
	}

	@Override
	public void destroy() {
		LOGGER.info("停止SMP结算平台操作日志服务======>");
	}

	@Override
	public GeneralServiceResponse writeLog(SMPWriteLogRequest request, Current __current) {
		/*
		if (null == request) {
			LOGGER.error("SMP结算平台操作日志服务： 写日志请求内容为空！");
			return null;
		}

		if (SMPStringUtil.isEmpty(request.orgId)) {
			return handleEmptyValue(request.orgId, "SMP结算平台操作日志服务调用失败:", "组织ID");
		}

		if (SMPStringUtil.isEmpty(request.refBizId)) {
			return handleEmptyValue(request.refBizId, "SMP结算平台操作日志服务调用失败:", "业务流水号");
		}

		if (SMPStringUtil.isEmpty(request.userId)) {
			return handleEmptyValue(request.userId, "SMP结算平台操作日志服务调用失败:", "操作用户ID");
		}

		if (SMPStringUtil.isEmpty(request.logLevel)) {
			return handleEmptyValue(request.logLevel, "SMP结算平台操作日志服务调用失败:", "日志级别");
		}
		Matcher dateMatcher = LOG_LV_PATTERN.matcher(request.logLevel);
		if (!dateMatcher.find()) {
			return handleErrorMsg("SMP结算平台操作日志服务调用失败: 日志级别错误!(DEBUG,INFO,WARN,ERROR,FATAL)", request.logLevel);
		}

		if (SMPStringUtil.isEmpty(request.operType)) {
			return handleEmptyValue(request.operType, "SMP结算平台操作日志服务调用失败", "操作类型");
		}

		if (SMPStringUtil.isEmpty(request.operObjType)) {
			return handleEmptyValue(request.operObjType, "SMP结算平台操作日志服务调用失败", "操作对象类型");
		}

		if (SMPStringUtil.isEmpty(request.operObjId)) {
			return handleEmptyValue(request.operObjId, "SMP结算平台操作日志服务调用失败", "操作对象ID");
		}

		if (SMPStringUtil.isEmpty(request.logContent)) {
			return handleEmptyValue(request.logContent, "SMP结算平台操作日志服务调用失败", "日志内容");
		}

		// 操作时间 格式校验
		String opDateTime = request.opDateTime;
		if (SMPStringUtil.isEmpty(opDateTime)) {
			LOGGER.error("SMP结算平台操作日志服务： 操作时间为空！");
			return new GeneralServiceResponse(false, "操作时间为空！", null);
		}

		Date opDate = null;
		try {
			// 设置lenient为false. 否则SimpleDateFormat会比较宽松地验证日期，比如2007/02/29会被接受，并转换成2007/03/01
			dateFormat.setLenient(false);
			opDate = dateFormat.parse(opDateTime);
		} catch (ParseException e) {
			LOGGER.warn("SMP结算平台操作日志服务： 操作时间格式(yyyy-MM-dd HH:mm:ss)不匹配：{}", opDateTime);
			opDate = DateUtil.getCurrentDate();
		}

		QueryParameterObject query = new QueryParameterObject();
		query.setAppId(APP_ID);
		query.setAppGroupId(GROUP_APP_ID);
		query.setCreateTime(new Timestamp(System.currentTimeMillis()));
		query.setOrgId(request.orgId);
		query.setRefBizId(request.refBizId);
		query.setUserId(request.userId);
		query.setLogLevel(request.logLevel);
		query.setOperType(request.operType);
		query.setOperSubType(request.operSubType);
		query.setOperObjId(request.operObjId);
		query.setOperObjType(request.operObjType);
		query.setOperObjSubType(request.operObjSubType);
		query.setLogContent(request.logContent);
		query.setOpDateTime(opDate);

		LogService service = new LogService();
		String logMsg = null;
		boolean isOk = true;
		try {
			logMsg = service.writeLogService(query);
		} catch (PaasException e1) {
			LOGGER.error("写日志失败， PaaS平台内部错误！", e1);
			isOk = false;
		}
		LOGGER.info("写日志结束，PaaS返回消息：{}", logMsg);
		 */
		String logMsg = "";
		GeneralServiceResponse res = new GeneralServiceResponse(true, "写日志结束：" + logMsg, new HashMap<>());
		res.params.put("userId", request.userId);
		res.params.put("logContent", request.logContent);
		res.params.put("logMsg", logMsg);

		return res;
	}

	public GeneralServiceResponse queryLog(SMPQueryLogRequest request, Current __current) {
		/*
		if (null == request) {
			LOGGER.error("request is empty. Cannot query any log from PaaS.");
			return null;
		}

		QueryParameterObject query = new QueryParameterObject();
		query.setAppId(APP_ID);
		query.setAppGroupId(GROUP_APP_ID);
		query.setCreateTime(new Timestamp(System.currentTimeMillis()));
		query.setOrgId(request.orgId);
		query.setRefBizId(request.refBizId);
		query.setUserId(request.userId);
		query.setLogLevel(request.logLevel);
		query.setOperType(request.operType);
		query.setOperSubType(request.operSubType);
		query.setOperObjId(request.operObjId);
		query.setOperObjType(request.operObjType);
		query.setOperObjSubType(request.operObjSubType);
		query.setLogContent(request.logContent);
		java.util.Date opDateTime;
		try {
			opDateTime = new SimpleDateFormat("YYYYMMDDHH24MISS").parse(request.opDateTime);
		} catch (ParseException e2) {
			LOGGER.error("操作时间解析出错(YYYYMMDDHH24MISS):{}", request.opDateTime);
			opDateTime = new Date();
		}
		query.setOpDateTime(opDateTime);

		// Query conditions
		String logId = request.logId;
		String destAppGroupId = "";
		String destAppId = APP_ID;
		String orgId = request.orgId;
		String refBizId = request.refBizId;
		String userId = request.userId;
		String logLevel = request.logLevel;
		String operType = request.operType;
		Date OpDatesTime = null;
		try {
			OpDatesTime = DateUtil.string2Date("", request.OpDatesTime);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Date OpDateeTime = null;
		try {
			OpDateeTime = DateUtil.string2Date("", request.OpDateeTime);
		} catch (Exception e) {
			LOGGER.error("操作时间解析出错(YYYYMMDDHH24MISS):{}", request.opDateTime);
			e.printStackTrace();
		}
		String operSubType = request.operSubType;
		String operObjId = request.operObjId;
		String operObjType = request.operObjType;
		String operObjSubType = request.operObjSubType;
		String logContentKeyWord = request.logContent;
		String pageSize = request.pageSize;
		String pageNo = request.pageNo;

		LogService service = new LogService();
		PaasLogResult logMsg = null;
		boolean isOk = true;
		try {
			logMsg = service.queryLog(logId, destAppGroupId, destAppId, orgId, refBizId, userId, logLevel, operType,
					OpDatesTime, OpDateeTime, operSubType, operObjId, operObjType, operObjSubType, logContentKeyWord,
					pageSize, pageNo);
		} catch (PaasException e1) {
			LOGGER.error("读取日志失败， PaaS平台内部错误！", e1);
			isOk = false;
		}
		LOGGER.info("写日志结束，PaaS返回消息：{}", logMsg);
		 */
		GeneralServiceResponse res = new GeneralServiceResponse(true, "写日志结束", new HashMap<>());
		res.params.put("userId", request.userId);
		res.params.put("logContent", request.logContent);
		return res;
	}

	private GeneralServiceResponse handleEmptyValue(String param, String msgPrefix, String msgFieldName) {
		return handleErrorMsg(msgPrefix + msgFieldName + "为空", param);
	}

	private GeneralServiceResponse handleErrorMsg(String msg, Object param) {
		LOGGER.error(msg + ", 传入参数为：{}", param);
		return new GeneralServiceResponse(false, msg, null);
	}


	public static void main(String[] args) {
		 SMPLogServiceImpl client = new SMPLogServiceImpl();
		 SMPWriteLogRequest request = new SMPWriteLogRequest();
		 request.orgId = "999999999";
			request.refBizId = "999999999";
			request.userId = "999999999";
			request.logLevel = "DEBUG";
			request.operType = "999999999";
			request.operSubType = "999999999";
			request.operObjId = "999999999";
			request.operObjType = "999999999";
			request.operObjSubType = "999999999";
			request.logContent = "日志内容，测试";
			request.opDateTime = "2016-10-27 16:16:16 666";

			long s = System.currentTimeMillis();
			int i =0;
			while(i++<1000) {
				GeneralServiceResponse res = client.writeLog(request);
			}
			System.out.println(System.currentTimeMillis() -s );
//		 	System.out.println(res.isSuccess?res.params.get("logMsg"):"Failed!!!");
	}

}
