package com.dtt.sett.webservice.cons;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dtt.sett.common.GeneralServiceResponse;
import com.dtt.sett.cons.innerquery.bean.OrderRecBaseDto;
import com.dtt.sett.cons.innerquery.service.ConsInnerQueryServicePrx;
import com.dtt.sett.cons.innerwriteback.service.ConsInnerWriteBackServicePrx;
import com.dtt.sett.cons.innerwriteback.service.ReturnToVendorDto;
import com.dtt.sett.framework.base.DateStyle;
import com.dtt.sett.framework.base.GeneralResponse;
import com.dtt.sett.framework.constant.SMPEnumValueCode;
import com.dtt.sett.framework.constant.SysLog;
import com.dtt.sett.framework.dao.BaseDaoUtil;
import com.dtt.sett.framework.utils.SMPPropertyUtil;
import com.dtt.sett.framework.utils.SMPStringUtil;
import com.dtt.sett.webservice.common.WSHelper;
import com.sdicons.json.validator.impl.predicates.Str;
import com.unicom.mss.SB_EBS_AP_ImportAPInvMatchRecInfoSrv.SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem;
import com.unicom.mss.SB_EBS_AP_ImportAPInvMatchRecInfoSrv.SB_EBS_AP_ImportAPInvMatchRecInfoSrvProxy;
import com.unicom.mss.SB_EBS_AP_ImportAPInvMatchRecInfoSrv.SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest;
import com.unicom.mss.SB_EBS_AP_ImportAPInvMatchRecInfoSrv.SB_EBS_AP_ImportAPInvMatchRecInfoSrvResponse;
import io.mycat.ice.utils.ICEClientUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 推送发票匹配采购接收信息服务 <br>
 * 报账系统、结算平台将发票匹配采购接收信息导入ERP核心系统<br>
 * 结算平台作为服务消费方，复用该服务去推送发票匹配采购接收信息给核心ERP<br>
 *
 * @author lijd
 * @since 2016年8月23日
 */
public class ImportAPInvMatchRecInfoClientForWeb {

    private static final Logger logger = LoggerFactory.getLogger(ImportAPInvMatchRecInfoClientForWeb.class);
    private static SimpleDateFormat FORMAT_YYYY_MM_DD_HH_MM_SS = new SimpleDateFormat(
            DateStyle.YYYY_MM_DD_HH_MM_SS.getValue());

    private final static Map<String, String> MSGMAP = new HashMap<>();

    private final static Map<String, Integer> NUMMAP = new HashMap<>();

    /**
     * 定时推送发票匹配采购接收信息服务 ，即推送订单接受信息给核心ERP。<br>
     * 目前只推送支持广东，吉林和集团的数据， 若要支持全国，需修改framework.properties 的usable.sharding.id
     */
    public GeneralResponse pushAPInvMatchRecInfo() {
        GeneralResponse response = null;
        String shardIds = SMPPropertyUtil.getFrameworkProperty("usable.sharding.id");
        if (SMPStringUtil.isEmpty(shardIds)) {
            logger.error("推送至核心ERP发票匹配采购接收信息服务调用失败, 可用分片ID列表获取失败");
            return new GeneralResponse(false, "推送至核心ERP发票匹配采购接收信息服务调用失败,  可用分片ID列表获取失败。");
        }

        String[] shardIdArr = shardIds.split(",");
        if (shardIdArr.length < 1) {
            logger.error("推送至核心ERP发票匹配采购接收信息服务调用失败, 可用分片ID列表获取失败");
            return new GeneralResponse(false, "推送至核心ERP发票匹配采购接收信息服务调用失败,  可用分片ID列表获取失败。");
        }

        int totalNum = 0, successNum = 0;

        for (String shardId : shardIdArr) {
            if (SMPStringUtil.isEmpty(shardId)) {
                logger.info("待推送省份的分片id为空，结束本次推送,继续下一个省分");
                continue;
            }
            // 实例SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest设置查询信息
            SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest request = new SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest();

            // 将msgHeader放入请求报文中
            request.setMsgHeader(WSHelper.genMsgHeader4ERP());
            SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem[] result = null;
            // prepareInputItems(getPoRecData2(shardId));


            if (result == null || result.length < 1) {
                continue;
            } else {
                totalNum += result.length;

                request.setSB_EBS_AP_ImportAPInvMatchRecInfoSrvInputCollection(result);
                response = doAPInvMatchRecHeaderRequest(request);

                if (response.isSuccess() == false) {

                    // 记录 错误 转换日志
                    MSGMAP.put("msgBusType", "退货控制推送信息");
                    MSGMAP.put("msgBusKey", SysLog.KEY_NOTHING);
                    MSGMAP.put("msgFailedMsg", "从中间表导入合同基本信息到基表失败，该条数据为空");
                    MSGMAP.put("msgCanSuccess", "");
                    MSGMAP.put("provinceCode", shardId.substring(2, 4));
                    MSGMAP.put("vendorNumber", "");

                    getInnerWriteBackProxy().getAddSysLog(SysLog.REC2ERP_SYSLOGTYPEMAP, response.getResultMap().get("instanceID"), null, MSGMAP);
                } else {
                    successNum += result.length;
                }
            }
        }

        // 记录 转换日志
        NUMMAP.put("totalNum", totalNum);
        NUMMAP.put("successNum", successNum);
        NUMMAP.put("failedNum", totalNum - successNum);

        getInnerWriteBackProxy().getAddSysLog(SysLog.REC2ERP_SYSLOGTYPEMAP, response.getResultMap().get("instanceID"), NUMMAP, null);

        return response;
    }

    /**
     * 推送订单接受信息给核心ERP， 把订单接收行上的退货控制信息同步给核心ERP
     *
     * @param settAccNum 结算单编号
     * @author Ervin 2017/3/7
     */
    public GeneralResponse pushPoRecInfo2ERP(Map<String, String> params) {


        GeneralResponse response = null;

        ConsInnerQueryServicePrx proxy = (ConsInnerQueryServicePrx) ICEClientUtil.getSerivcePrx(ConsInnerQueryServicePrx.class);
        String poData = proxy.getPoRecReturn(params);

        JSONObject poDataJson = JSONObject.parseObject(poData);

        Integer total = poDataJson.getInteger("total");

        if (total < 1) {
            logger.error("您要处理的数据均已完成释放，无需重复提交！");
            return new GeneralResponse(false, "您要处理的数据均已完成释放，无需重复提交！");
        } else if (total >= 1000) {
            logger.error("您要处理的数据量超过系统规定，请增加条件后再释放！查询到数据总数为{}", total);
            return new GeneralResponse(false, "您要处理的数据量超过系统规定，请增加条件后再释放！");
        }


        JSONArray jaPoData = JSON.parseArray(poDataJson.getString("rows"));


        SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem[] inputItem = prepareInputItems(jaPoData);


        if (inputItem == null || inputItem.length < 1) {
            logger.error("同步订单接收行上的退货控制信息到核心ERP服务调用失败, 查询到的数据为空");
            return new GeneralResponse(false, "同步订单接收行上的退货控制信息到核心ERP服务调用失败, 查询到的数据为空");
        }
        // 实例SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest设置查询信息
        SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest request = new SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest();

        // 将msgHeader放入请求报文中
        request.setMsgHeader(WSHelper.genMsgHeader4ERP());
        int totalNum = 0, successNum = 0;

        logger.info("result ", inputItem.length);
        String inputItemJsonString = JSON.toJSONString(inputItem);
        logger.info("json string :", inputItemJsonString);
        totalNum += inputItem.length;

        request.setSB_EBS_AP_ImportAPInvMatchRecInfoSrvInputCollection(inputItem);
        response = doAPInvMatchRecHeaderRequest(request);

        if (response.isSuccess() == false) {

            // 记录 错误 转换日志
            MSGMAP.put("msgBusType", "退货控制推送信息");
            MSGMAP.put("msgBusKey", inputItemJsonString);
            MSGMAP.put("msgFailedMsg", response.getMsg());
            MSGMAP.put("msgCanSuccess", "");
            MSGMAP.put("provinceCode", inputItem[0].getPROVINCE_CODE());
            MSGMAP.put("vendorNumber", "");

            getInnerWriteBackProxy().getAddSysLog(SysLog.REC2ERP_SYSLOGTYPEMAP, response.getResultMap().get("instanceID"), null, MSGMAP);
        } else {
            successNum += inputItem.length;

            List<String> rtvRecordIds = jaPoData.stream().map(obj ->
                    ((JSONObject) obj).getString("RTV_RECORD_ID")
            ).collect(Collectors.toList());

            // 回写推送成功标识为1
            GeneralServiceResponse re1Sp = getInnerWriteBackProxy().writeBackReturnToVendorRecordPushFlagByIds(rtvRecordIds.toArray(new String[rtvRecordIds.size()]));

            if (!re1Sp.isSuccess) {
                logger.error("推送至核心ERP成功后回写推送状态为1失败,{}", re1Sp.message);
            }
        }

        // 记录 转换日志
        NUMMAP.put("totalNum", totalNum);
        NUMMAP.put("successNum", successNum);
        NUMMAP.put("failedNum", totalNum - successNum);

        getInnerWriteBackProxy().getAddSysLog(SysLog.REC2ERP_SYSLOGTYPEMAP, response.getResultMap().get("instanceID"), NUMMAP, null);
        return response;
    }

    private GeneralResponse doAPInvMatchRecHeaderRequest(SB_EBS_AP_ImportAPInvMatchRecInfoSrvRequest aPInvMatchRecHeaderRequest) {
        Map<String, String> resMap = new HashMap<>();
        GeneralResponse res = new GeneralResponse(false, null);

        logger.info("推送至核心ERP发票匹配采购接收信息服务请求调用中...");
        if (null == aPInvMatchRecHeaderRequest) {
            logger.error("推送至核心ERP发票匹配采购接收信息服务调用失败, 请求内容为空：" + aPInvMatchRecHeaderRequest);
            resMap.put("instanceID", "");
            res.setSuccess(false);
            res.setMsg("内部支付银行信息服务调用失败, 请求内容为空。");
            res.setResultMap(resMap);
            return res;
        }

        // 调用Web Service
        SB_EBS_AP_ImportAPInvMatchRecInfoSrvProxy proxy = new SB_EBS_AP_ImportAPInvMatchRecInfoSrvProxy();
        SB_EBS_AP_ImportAPInvMatchRecInfoSrvResponse response = null;
        try {
            response = proxy.process(aPInvMatchRecHeaderRequest);
        } catch (RemoteException e) {
            logger.error("推送至核心ERP发票匹配采购接收信息服务调用失败, 异常发生：", e);
            WSHelper.getFailLogProx().addMidFromSysLogFromWeb(SMPEnumValueCode.FROM_SYS_SMP, "核心ERP系统", "1",
                    "推送至核心ERP发票匹配采购接收信息服务WSDL调用失败, 没有实例报文号");

            resMap.put("instanceID", "");
            res.setSuccess(false);
            res.setMsg("推送至核心ERP发票匹配采购接收信息服务调用失败, 异常发生：" + e.getMessage());
            res.setResultMap(resMap);
            return res;
        }
        if (response == null) {
            logger.error("推送至核心ERP发票匹配采购接收信息服务调用失败, 返回对象为空.");
            WSHelper.getFailLogProx().addMidFromSysLogFromWeb(SMPEnumValueCode.FROM_SYS_SMP, "核心ERP系统", "1",
                    "推送至核心ERP发票匹配采购接收信息服务WSDL调用失败,返回对象response为空,没有实例报文号");
            resMap.put("instanceID", "");
            res.setSuccess(false);
            res.setMsg("推送至核心ERP发票匹配采购接收信息服务调用失败, 返回对象为空.");
            res.setResultMap(resMap);
            return res;
        }

        String soapMsg = JSON.toJSONString(response);
        String serviceflag = response.getSERVICE_FLAG();
        String serviceMsg = response.getSERVICE_MESSAGE();
        BigDecimal instance_ID = response.getINSTANCE_ID();
        logger.info("推送至核心ERP发票匹配采购接收信息服务调用结束， 返回状态：" + serviceflag + ", 返回消息：" + serviceMsg + "实例：" + instance_ID);
        boolean parseBoolean = Boolean.parseBoolean(serviceflag);

        WSHelper.getFailLogProx().addMidFromSysLogFromWeb(SMPEnumValueCode.FROM_SYS_SMP, "核心ERP系统", "1",
                "推送至核心ERP发票匹配采购接收信息服务WSDL调用" + (parseBoolean ? "成功" : "失败") + ",实例报文号:" + instance_ID + ",报文体:" + soapMsg);
        // 快速失败Fast-Fail， 及时返回失败结果。
        if (!parseBoolean) {
            //2、在t_sac_basic_re_vendor_record表中增加一个ERR_MSG字段（varchar（320）），
            // 当外部接口SERVICE_FLAG为FALSE时记录ErrorCollection中ERROR_MESSAGE字段值，
            // 当外部接口SERVICE_FLAG为TRUE时记录PUSH_FALG为 0；
            com.unicom.mss.SB_EBS_AP_ImportAPInvMatchRecInfoSrv.ErrorItem[] errs = response.getErrorCollection();
            GeneralServiceResponse errResp = addErrMsg(errs);
            if (!errResp.isSuccess) {
                logger.error("推送至核心ERP发票匹配采购接收信息服务调用失败, 回写ERR_MSG失败：{}", errResp.message);
            }
            logger.error("推送至核心ERP发票匹配采购接收信息服务调用失败, 返回消息：" + serviceMsg);
            resMap.put("instanceID", instance_ID.toString());
            res.setSuccess(false);
            res.setMsg("推送至核心ERP发票匹配采购接收信息服务调用失败, 返回消息：" + serviceMsg + errResp.message);
            res.setResultMap(resMap);
            return res;
        }
        logger.info("推送至核心ERP发票匹配采购接收信息服务调用成功, 返回消息：" + serviceMsg);
        resMap.put("instanceID", instance_ID.toString());
        res.setSuccess(true);
        res.setMsg("推送至核心ERP发票匹配采购接收信息服务成功！");
        res.setResultMap(resMap);
        return res;
    }

    /**
     * PRI_KEY+RECORD_NUMBER+RESERVED_1  进行更新
     *
     * @param errs
     */
    private GeneralServiceResponse addErrMsg(com.unicom.mss.SB_EBS_AP_ImportAPInvMatchRecInfoSrv.ErrorItem[] errs) {
        if (errs == null || errs.length < 1)
            return new GeneralServiceResponse(false, "com.unicom.mss.SB_EBS_AP_ImportAPInvMatchRecInfoSrv.ErrorItem中错误记录为空", null);
        Map<String, String>[] errMsgs = new HashMap[errs.length];
        for (int ei = 0; ei < errs.length; ei++) {
            Map<String, String> err = new HashMap<>();
            err.put("ERR_MSG", errs[ei].getERROR_MESSAGE());
            err.put("PRI_KEY", errs[ei].getPRI_KEY());
            err.put("RECORD_NUMBER", errs[ei].getRECORD_NUMBER());
            err.put("RESERVED_1", errs[ei].getRESERVED_1());
            errMsgs[ei] = err;
        }
        return getInnerWriteBackProxy().writeBackReturnToVendorRecordErrMsgs(errMsgs);

    }


    private static SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem[] prepareInputItems(JSONArray ja) {
        SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem[] array = {};

        if (ja == null || ja.size() < 1) {
            return array;
        }
        array = new SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem[ja.size()];

        ReturnToVendorDto[] returnArray = new ReturnToVendorDto[ja.size()];
        for (int jai = 0; jai < ja.size(); jai++) {
            JSONObject jao = ja.getJSONObject(jai);
            SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem InputItem = new SB_EBS_AP_ImportAPInvMatchRecInfoSrvInputItem();
            InputItem.setPROVINCE_CODE(jao.getString("PROVINCE_CODE"));
            InputItem.setPRI_KEY(jao.getString("PRI_KEY"));
            InputItem.setORG_NAME(jao.getString("ORG_NAME"));
            InputItem.setEAS_RECEIPT_NUMBER(jao.getString("EAS_RECEIPT_NUMBER"));
            InputItem.setOPERATION_TYPE(jao.getString("OPERATION_TYPE"));
            InputItem.setQUANTITY_INVOICED(new BigDecimal(jao.getString("QUANTITY_INVOICED")));

            InputItem.setPO_NUMBER(jao.getString("PO_NUMBER"));
            InputItem.setPO_LINE_NUMBER(new BigDecimal(jao.getString("PO_LINE_NUMBER")));
            InputItem.setPO_SHIPMENT_NUM(StringUtils.isEmpty(jao.getString("PO_SHIPMENT_NUM")) ? null : new BigDecimal(jao.getString("PO_SHIPMENT_NUM")));
            InputItem.setPO_DISTRIBUTION_NUM(StringUtils.isEmpty(jao.getString("PO_DISTRIBUTION_NUM")) ? null : new BigDecimal(jao.getString("PO_DISTRIBUTION_NUM")));
            InputItem.setRECEIPT_NUMBER(jao.getString("RECEIPT_NUMBER"));
            InputItem.setRECEIPT_LINE_NUM(StringUtils.isEmpty(jao.getString("RECEIPT_LINE_NUM")) ? null : new BigDecimal(jao.getString("RECEIPT_LINE_NUM")));
            InputItem.setRESERVED_1(jao.getString("RESERVED_1"));
            array[jai] = InputItem;
        }
        return array;
    }

    /**
     * @return 内部查询的ice代理类
     * @desc 得到内部查询的ice代理类
     * @author Ervin
     * @date 2017年2月24日 上午7:42:17
     */
    private static ConsInnerWriteBackServicePrx getInnerWriteBackProxy() {
        ConsInnerWriteBackServicePrx pxy = (ConsInnerWriteBackServicePrx) ICEClientUtil
                .getSerivcePrx(ConsInnerWriteBackServicePrx.class);

        if (pxy == null) {
            logger.error("不能获取ICE服务代理：ConsInnerQueryServicePrx");
            throw new RuntimeException();
        }

        return pxy;
    }
}
