package com.dtt.sett.webservice.cons;


import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import java.util.List;
import javax.xml.namespace.QName;
import javax.xml.rpc.encoding.TypeMapping;
import javax.xml.rpc.encoding.TypeMappingRegistry;

import com.alibaba.fastjson.JSONObject;
import com.dtt.sett.framework.base.DateStyle;
import com.dtt.sett.framework.exception.SMPException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.dtt.sett.cons.innerquery.service.ConsInnerQueryServicePrx;
import com.dtt.sett.cons.tradedata2mid.bean.PoHeaderInfoMidDto;
import com.dtt.sett.cons.tradedatapoheaderinfo2mid.ConsTradeDataPoHeaderInfo2MidServicePrx;
import com.dtt.sett.framework.base.GeneralResponse;
import com.dtt.sett.framework.common.service.SMPCommonService;
import com.dtt.sett.framework.constant.Constant;
import com.dtt.sett.framework.constant.SMPEnumValueCode;
import com.dtt.sett.framework.constant.Table;
import com.dtt.sett.framework.utils.SMPStringUtil;
import com.dtt.sett.webservice.common.WSHelper;
import com.dtt.sett.webservice.custom.CustomizedCalendarDeserializerFactory;
import com.dtt.sett.webservice.custom.CustomizedCalendarSerializerFactory;
import com.unicom.mss.SB_EBS_PO_InquiryPoHeaderInfoSrv.SB_EBS_PO_InquiryPoHeaderInfoSrvOutputItem;
import com.unicom.mss.SB_EBS_PO_InquiryPoHeaderInfoSrv.SB_EBS_PO_InquiryPoHeaderInfoSrvProxy;
import com.unicom.mss.SB_EBS_PO_InquiryPoHeaderInfoSrv.SB_EBS_PO_InquiryPoHeaderInfoSrvRequest;
import com.unicom.mss.SB_EBS_PO_InquiryPoHeaderInfoSrv.SB_EBS_PO_InquiryPoHeaderInfoSrvResponse;
import com.unicom.mss.SB_EBS_PO_InquiryPoHeaderInfoSrv.SB_EBS_PO_InquiryPoHeaderInfoSrv_ServiceLocator;

import io.mycat.ice.utils.ICEClientUtil;

/**
 * SOA 查询核心ERP采购订单头服务客户端实现类。
 * 从WebService获取{核心ERP采购订单头信息导入(拉)},并插入到中间表
 * @author huarlin
 * @since 2016-7-25
 */
public class InquiryPoHeaderInfoClient {

	private final static Logger LOGGER = LoggerFactory.getLogger(InquiryPoHeaderInfoClient.class);

	/**
	 * 定时查询核心ERP采购订单头服务，获取订单头数据。
	 * @param proviceCode 输入查询条件,省份代码(Y, 必录查询条件)
	 * @param lutStart 输入查询条件,最后更新时间开始(Y, 定时查询必录条件)
	 * @param lutEnd 输入查询条件,最后更新时间结束(Y, 定时查询必录条件)
	 * 如果是采取定时同步查询的方式，则两个DATE类型字段值必须同时录入，且结束时间必须大于开始时间，精确到秒，
	 * @return GeneralResponse 基础服务应答对象。
	 */
	public GeneralResponse getPoHeaderData(String proviceCode, Calendar lutStart, Calendar lutEnd, String startTime, String endTime ) {
		// 实例SB_EBS_PO_InquiryPoHeaderInfoSrvRequest设置查询信息
		
		SB_EBS_PO_InquiryPoHeaderInfoSrvRequest poHeaderRequest = new SB_EBS_PO_InquiryPoHeaderInfoSrvRequest();
		
		writeBackNewRecordStatusTo5(startTime, endTime);
		
		// 将msgHeader放入请求报文中
		poHeaderRequest.setMsgHeader(WSHelper.genMsgHeader4ERP());

		// 输入查询条件,省份代码(Y, 必录条件)
		poHeaderRequest.setPROVINCE_CODE(proviceCode);
		
		// 纠正8小时差
		lutStart.add(Calendar.HOUR, 8);
		lutEnd.add(Calendar.HOUR, 8);
		
		// 输入查询条件,最后更新时间开始(Y, 定时必录条件)
		poHeaderRequest.setSTART_LAST_UPDATE_DATE(lutStart);
		// 输入查询条件,最后更新时间结束(Y, 定时必录条件)
		poHeaderRequest.setEND_LAST_UPDATE_DATE(lutEnd);
		
		GeneralResponse result = getPoHeaderData(poHeaderRequest,1);
		
		writeBackNewRecordStatus(result.isSuccess(), startTime, endTime);
	
		return result;
	}

	/**
	 * 精确查询核心ERP采购订单头服务，获取订单头数据。
	 * @param proviceCode 输入查询条件,省份代码(Y, 必录条件)
	 * @param orgName 输入查询条件,OU名称(Y, 精确查询可选条件)
	 * @param poNumber 输入查询条件,采购订单号(Y/N, 精确查询可选条件)
	 * @param contractNumber 输入查询条件,合同编号(Y/N, 精确查询可选条件)
	 * poNumber和contractNumber两个字段在精确查询时必须选择其中一个
	 * @return GeneralResponse 基础服务应答对象。
	 */
	public GeneralResponse getPoHeaderData(String proviceCode, String orgName, String poNumber, String contractNumber) {

		// 实例SB_EBS_PO_InquiryPoHeaderInfoSrvRequest设置查询信息
		SB_EBS_PO_InquiryPoHeaderInfoSrvRequest poHeaderRequest = new SB_EBS_PO_InquiryPoHeaderInfoSrvRequest();

		// 将msgHeader放入请求报文中
		poHeaderRequest.setMsgHeader(WSHelper.genMsgHeader4ERP());

		// 输入查询条件,省份代码(Y, 必录条件)
		poHeaderRequest.setPROVINCE_CODE(proviceCode);
		// 输入查询条件,OU名称(Y, 精确可选条件)
		poHeaderRequest.setORG_NAME(orgName);
		// 输入查询条件,订单头ID(Y/N, 可选条件)
		poHeaderRequest.setPO_NUMBER(poNumber);
		// 输入查询条件,合同编号(Y/N, 可选条件)
		poHeaderRequest.setCONTRACT_NUMBER(contractNumber);
		return getPoHeaderData(poHeaderRequest,1);
	}
    private static SimpleDateFormat FORMAT_YYYY_MM_DD_HH_MM_SS = new SimpleDateFormat(
            DateStyle.YYYY_MM_DD_HH_MM_SS.getValue());
	/**
	 * 调用查询核心ERP采购订单头服务，获取订单头数据。
	 * @param poLineRequest Web Service 请求头。
	 * @return GeneralResponse 基础服务应答对象。
	 */
	private GeneralResponse getPoHeaderData(SB_EBS_PO_InquiryPoHeaderInfoSrvRequest request,int times) {

		LOGGER.info("开始第"+times+"次SOA查询核心ERP采购订单头服务请求调用中...");
		
		if (null == request) {
			LOGGER.error("第"+times+"次SOA查询核心ERP采购订单头服务调用失败, 请求内容为空：" + request);
			return new GeneralResponse(false, "第"+times+"次SOA查询核心ERP采购订单头服务调用失败, 请求内容为空。");
		}
		
		GeneralResponse result = new GeneralResponse(true,"");
		//调用信息,用于日志记录
		String requestInfo = "调用信息: " + "PROVINCE_CODE:" + request.getPROVINCE_CODE() + ",ORG_NAME:" + request.getORG_NAME() 
			+ ",PO_NUMBER:" + request.getPO_NUMBER() + ",CONTRACT_NUMBER:" + request.getCONTRACT_NUMBER() + "--";
		try {
		LOGGER.info(requestInfo);

			//注册日期为空可通过
			registNullDate(new SB_EBS_PO_InquiryPoHeaderInfoSrv_ServiceLocator());
	
			// 调用Web Service
			SB_EBS_PO_InquiryPoHeaderInfoSrvProxy proxy = new SB_EBS_PO_InquiryPoHeaderInfoSrvProxy();
			//GeneralServiceResponse result = null;

            try {
                LOGGER.info("调用WS服务前信息打印：\n 类名:{},\n 方法名:{},\n 请求WS服务名：{}\n 请求参数对象信息：{}\n "
                        ,this.getClass().getName()
                        ,Thread.currentThread().getStackTrace()[1].getMethodName()
                        ,proxy.getClass().getName()
                        , JSONObject.toJSONString(request));
            } catch (Exception e) {
            }
			SB_EBS_PO_InquiryPoHeaderInfoSrvResponse response = proxy.process(request);
			
			if (null == response) {
				LOGGER.error("第"+times+"次SOA查询核心ERP采购订单头服务调用失败, 返回对象为空.");
				WSHelper.getFailLogProx().addMidFromSysLogFromWeb(SMPEnumValueCode.FROM_SYS_CORE_ERP, "结算平台",
						Table.T_SAC_MID_ERP_PO_HEADER,requestInfo + "调用核心ERP采购订单头WSDL失败,返回对象response为空,没有实例报文号");
				return new GeneralResponse(false, "第"+times+"次SOA查询核心ERP采购订单头服务调用失败, 返回对象为空,没有实例报文号---");
			}

            String serviceflag = response.getSERVICE_FLAG();
			String serviceMsg = response.getSERVICE_MESSAGE();
			String instanceId = SMPStringUtil.objectToString(response.getINSTANCE_ID());
			
			boolean issuccess = Boolean.parseBoolean(serviceflag);
	
	
			// 快速失败Fast-Fail， 及时返回失败结果。
			if (!issuccess) {
				WSHelper.getFailLogProx().addMidFromSysLogFromWeb(SMPEnumValueCode.FROM_SYS_CORE_ERP, "结算平台",
					Table.T_SAC_MID_ERP_PO_HEADER,requestInfo + "调用核心ERP采购订单头WSDL失败,返回消息:"+serviceMsg+",实例报文号:"+instanceId);
				LOGGER.info("第"+times+"次SOA查询核心ERP采购订单头服务调用失败,实例报文号:"+instanceId+",返回错误调用消息"+serviceMsg);
				return new GeneralResponse(false, "第"+times+"次SOA查询核心ERP采购订单头服务调用失败,实例报文号:"+instanceId+",返回错误调用消息"+serviceMsg+"---");
			}
	
			// 从应答对象抽取数据集合，进行下一步处理。
			SB_EBS_PO_InquiryPoHeaderInfoSrvOutputItem[] collection = response
					.getSB_EBS_PO_InquiryPoHeaderInfoSrvOutputCollection();
	
			int len = null==collection?0:collection.length;
			
			if (len < 1) {
				LOGGER.info("第"+times+"次SOA查询核心ERP采购订单头服务调用成功， 但是没有数据返回,结束调用");
				WSHelper.getFailLogProx().addMidFromSysLogFromWeb(SMPEnumValueCode.FROM_SYS_CORE_ERP, "结算平台",
					Table.T_SAC_MID_ERP_PO_HEADER,requestInfo + "调用核心ERP采购订单头WSDL成功, 但是没有数据返回,实例报文号:"+instanceId);
				return new GeneralResponse(true, "第"+times+"次SOA查询核心ERP采购订单头服务调用成功,实例报文号:"+instanceId+", 但是没有数据返回, 结束调用---");
			}
	
			// 调用erp订单头插入中间表的ice服务
			ConsTradeDataPoHeaderInfo2MidServicePrx serivcePrx = (ConsTradeDataPoHeaderInfo2MidServicePrx) ICEClientUtil
					.getSerivcePrx(ConsTradeDataPoHeaderInfo2MidServicePrx.class);
			StringBuffer poHeadIdsBuf = new StringBuffer();
			PoHeaderInfoMidDto[] dtos = prepareData4IceService(collection, poHeadIdsBuf);
			serivcePrx.pullPoHeaderInfo(dtos);
			result.getResultMap().put("poHeadIds", poHeadIdsBuf.toString());

			result.setMsg("第"+times+"次SOA查询核心ERP采购订单头服务成功,实例报文号:"+instanceId+",拉取到"+len+"条---");
			
			//若本次拉取条数>=页大小,默认1000条,则进行递归调用
			if(len>=request.getMsgHeader().getPAGE_SIZE().intValue()){
				//设置+1的新查询页码 
				BigDecimal currentPage = request.getMsgHeader().getCURRENT_PAGE();
				BigDecimal newPage = currentPage.add(new BigDecimal(1));
				request.getMsgHeader().setCURRENT_PAGE(newPage);
				//调用次数加1,调用
				GeneralResponse nextResponse = getPoHeaderData(request,times+1);
				//拼接返回消息
				result.setSuccess(result.isSuccess()&&nextResponse.isSuccess());
				result.setMsg(result.getMsg()+nextResponse.getMsg());;
			}
		} catch(Exception e){
			LOGGER.error("第"+times+"次SOA查询核心ERP采购订单头服务调用失败, 异常发生：", e);
			WSHelper.getFailLogProx().addMidFromSysLogFromWeb(SMPEnumValueCode.FROM_SYS_CORE_ERP,"结算平台",
				Table.T_SAC_MID_ERP_PO_HEADER,requestInfo + "调用项目信息WSDL失败,出现异常,没有实例报文号");
			return new GeneralResponse(false, "第"+times+"次SOA查询核心ERP采购订单头服务调用失败,没有实例报文号,异常发生："+ e.getMessage()+"---");
		}
		//输出所有的调用情况
		if(1==times){
			LOGGER.info("-----------核心ERP采购订单头WSDL全部调用结果展示start------------------------");
			String[] msgArray = result.getMsg().split("---");
			for(String s : msgArray){
				LOGGER.info(s);
			}
			LOGGER.info("-----------核心ERP采购订单头WSDL全部调用结果展示end------------------------");
		}
		return result;
	}

	/**
	 * ERP-3183 核心订单头信息拉取优化修改
	 * @author andyswang
	 * @date 2019-4-25 11:24
	 */
	/**
	 * 准备ICE写入中间表服务的请求数据。
	 * @param collection SB_EBS_PO_InquiryPoHeaderInfoSrvOutputItem WS返回的数据集合
	 * @return PoHeaderInfoMidDto 中间表用数据对象数组
	 */
	private PoHeaderInfoMidDto[] prepareData4IceService(SB_EBS_PO_InquiryPoHeaderInfoSrvOutputItem[] collection, StringBuffer poHeadIdsBuf) {

		if (null == collection || collection.length < 1 ) {
			return null;
		}

		int len = collection.length;
//		PoHeaderInfoMidDto[] array = new PoHeaderInfoMidDto[len];

        List<PoHeaderInfoMidDto> list = new ArrayList<>();

		PoHeaderInfoMidDto poHeader = null;
		

		// 转换数据结构
		for (int i = 0; i < len; i++) {
			
			//先纠正Calender的8小时时间差
			if(collection[i].getSTART_DATE_ACTIVE()!=null){collection[i].getSTART_DATE_ACTIVE().add(Calendar.HOUR, -8);}
			if(collection[i].getEND_DATE_ACTIVE()!=null){collection[i].getEND_DATE_ACTIVE().add(Calendar.HOUR, -8);}
			if(collection[i].getCREATION_DATE()!=null){collection[i].getCREATION_DATE().add(Calendar.HOUR, -8);}
			if(collection[i].getAPPROVED_DATE()!=null){collection[i].getAPPROVED_DATE().add(Calendar.HOUR, -8);}
			if(collection[i].getLAST_UPDATE_DATE()!=null){collection[i].getLAST_UPDATE_DATE().add(Calendar.HOUR, -8);}
			
			poHeader = new PoHeaderInfoMidDto();
			String orgName = collection[i].getORG_NAME();

			poHeader.provinceCode=SMPStringUtil.objectToString(collection[i].getPROVINCE_CODE()); //省份代码
			poHeader.orgName=SMPStringUtil.objectToString(orgName); //OU名称
			poHeader.poHeaderId=SMPStringUtil.objectToString(collection[i].getPO_HEADER_ID()); //订单头ID
			poHeader.poNumber=SMPStringUtil.objectToString(collection[i].getPO_NUMBER()); //采购订单号
			poHeadIdsBuf.append(SMPStringUtil.objectToString(collection[i].getPO_HEADER_ID()) + ",");
			poHeader.poAmount=SMPStringUtil.objectToString(collection[i].getPO_AMOUNT()); //采购订单总金额
			poHeader.orderType=SMPStringUtil.objectToString(collection[i].getORDER_TYPE()); //采购订单类型名称
			poHeader.agentId=SMPStringUtil.objectToString(collection[i].getAGENT_ID()); //采购员ID
			poHeader.agentName=SMPStringUtil.objectToString(collection[i].getAGENT_NAME()); //采购员
			poHeader.vendorId=SMPStringUtil.objectToString(collection[i].getVENDOR_ID()); //供应商ID
			poHeader.vendorName=SMPStringUtil.objectToString(collection[i].getVENDOR_NAME()); //供应商名称
			poHeader.vendorSiteId=SMPStringUtil.objectToString(collection[i].getVENDOR_SITE_ID()); //供应商地点ID
			poHeader.vendorSiteCode=SMPStringUtil.objectToString(collection[i].getVENDOR_SITE_CODE()); //供应商地点
			poHeader.vendorContactId=SMPStringUtil.objectToString(collection[i].getVENDOR_CONTACT_ID()); //供应商联系人ID
			poHeader.vendorContact=SMPStringUtil.objectToString(collection[i].getVENDOR_CONTACT()); //供应商联系人
			poHeader.shipToLocationId=SMPStringUtil.objectToString(collection[i].getSHIP_TO_LOCATION_ID()); //收货方ID
			poHeader.shipToLocation=SMPStringUtil.objectToString(collection[i].getSHIP_TO_LOCATION()); //收货方
			poHeader.billToLocationId=SMPStringUtil.objectToString(collection[i].getBILL_TO_LOCATION_ID()); //收单方ID
			poHeader.billToLocation=SMPStringUtil.objectToString(collection[i].getBILL_TO_LOCATION()); //收单方
			poHeader.startDateActive=SMPStringUtil.objectToString(collection[i].getSTART_DATE_ACTIVE()); //开始有效日期
			poHeader.endDateActive=SMPStringUtil.objectToString(collection[i].getEND_DATE_ACTIVE()); //失效日期
			poHeader.creationDate=SMPStringUtil.objectToString(collection[i].getCREATION_DATE()); //创建时间
			poHeader.currencyCode=SMPStringUtil.objectToString(collection[i].getCURRENCY_CODE()); //币种
			poHeader.approvedDate=SMPStringUtil.objectToString(collection[i].getAPPROVED_DATE()); //审批日期
			poHeader.controlStatus=SMPStringUtil.objectToString(collection[i].getCONTROL_STATUS()); //订单状态
			poHeader.vendorOrderNum=SMPStringUtil.objectToString(collection[i].getVENDOR_ORDER_NUM()); //供应商订单编号供应商订单编号
			poHeader.comments=SMPStringUtil.objectToString(collection[i].getCOMMENTS()); //注释
			poHeader.reserved1=SMPStringUtil.objectToString(collection[i].getRESERVED_1()); //审批状态
			poHeader.reserved2=SMPStringUtil.objectToString(collection[i].getRESERVED_2()); //结算单号
			poHeader.reserved3=SMPStringUtil.objectToString(collection[i].getRESERVED_3()); //供应商编号
			poHeader.reserved4=SMPStringUtil.objectToString(collection[i].getRESERVED_4()); //一点结算标识
			poHeader.reserved5=SMPStringUtil.objectToString(collection[i].getRESERVED_5()); //预留字段5
			poHeader.reserved6=SMPStringUtil.objectToString(collection[i].getRESERVED_6()); //预留字段6
			poHeader.reserved7=SMPStringUtil.objectToString(collection[i].getRESERVED_7()); //预留字段7
			poHeader.reserved8=SMPStringUtil.objectToString(collection[i].getRESERVED_8()); //预留字段8
			poHeader.contractNumber=SMPStringUtil.objectToString(collection[i].getCONTRACT_NUMBER()); //合同编号
			poHeader.lastUpdateDate=SMPStringUtil.objectToString(collection[i].getLAST_UPDATE_DATE()); //最后更新时间

			poHeader.shipType=SMPStringUtil.objectToString(collection[i].getSHIP_TYPE()); //发货类型
			poHeader.shipSource=SMPStringUtil.objectToString(collection[i].getSHIP_SOURCE()); //来源
			poHeader.purOrderNumber=SMPStringUtil.objectToString(collection[i].getPUR_ORDER_NUMBER()); //采购管理系统订单编号
			poHeader.contractVersion=SMPStringUtil.objectToString(collection[i].getCONTRACT_VERSION()); //合同版本

			try {
				String orgCode = StringUtils.substring(orgName, 0, 6);
				poHeader.shardingId= SMPStringUtil.objectToString(SMPCommonService.getShardingIdByOrgCode(orgCode));
			} catch (Exception e) {//某些orgCode可能会出现ice.unkonwexception,需要正常抛出异常并打印出错的orgCode
				LOGGER.info("SOA查询核心ERP采购订单头服务响应数据中当前头信息orgName={}",orgName,e);

                continue;
			}
			poHeader.loadingFlag=Constant.LOADING_STATUS_NULL;//传送标识
			poHeader.loadingTime=SMPStringUtil.objectToString(new Date());//传送时间

			list.add(poHeader);
		}

		PoHeaderInfoMidDto[] array=list.toArray(new PoHeaderInfoMidDto[list.size()]);

		return array;
	}
	
	//注册空的日期可通过
	private void registNullDate(SB_EBS_PO_InquiryPoHeaderInfoSrv_ServiceLocator locate){
		//注册日期映射，使可接收空日期字段
		TypeMappingRegistry tmr = locate.getTypeMappingRegistry();
		TypeMapping tm = tmr.getDefaultTypeMapping();
		tm.register(java.util.Date.class, new QName(
				"http://www.w3.org/2001/XMLSchema", "dateTime"),
				new CustomizedCalendarSerializerFactory(java.util.Date.class,
						new javax.xml.namespace.QName(
								"http://www.w3.org/2001/XMLSchema",
								"dateTime")),
				new CustomizedCalendarDeserializerFactory(
						java.util.Date.class,
						new javax.xml.namespace.QName(
								"http://www.w3.org/2001/XMLSchema",
								"dateTime")));
		tm.register(java.util.Calendar.class, new QName(
				"http://www.w3.org/2001/XMLSchema", "dateTime"),
				new CustomizedCalendarSerializerFactory(java.util.Calendar.class,
						new javax.xml.namespace.QName(
								"http://www.w3.org/2001/XMLSchema",
								"dateTime")),
				new CustomizedCalendarDeserializerFactory(
						java.util.Calendar.class,
						new javax.xml.namespace.QName(
								"http://www.w3.org/2001/XMLSchema",
								"dateTime")));
	}
	
	/**
	 * @desc 得到内部查询的ice代理类
	 * @author Ervin
	 * @date 2017年2月24日 上午7:42:17
	 * @return 内部查询的ice代理类
	 */
	private ConsInnerQueryServicePrx getInnerQueryProxy() {
		ConsInnerQueryServicePrx pxy = (ConsInnerQueryServicePrx) ICEClientUtil
				.getSerivcePrx(ConsInnerQueryServicePrx.class);

		if (pxy == null) {
			LOGGER.error("不能获取ICE服务代理：ConsInnerQueryServicePrx");
			throw new RuntimeException();
		}

		return pxy;
	}
	
	/**
	 * @desc 改记录状态为5
	 * @author Ervin
	 * @date 2017年2月24日 上午7:42:17
	 */
	private void writeBackNewRecordStatusTo5 (String startTime, String endTime) {
		StringBuffer sql = new StringBuffer();
		sql.append("UPDATE t_sac_job_schedule_rec SET JOB_END_TIME = now(), JOB_STATUS = '5' WHERE JOB_STATUS = '1' AND DELETED_FLAG = 0 AND JOB_NAME = '");
		sql.append(Table.T_SAC_MID_ERP_PO_HEADER);
		sql.append("' AND DATA_START_TIME = '");
		sql.append(startTime);
		sql.append("' AND DATA_END_TIME = '");
		sql.append(endTime);
		sql.append("'");
		getInnerQueryProxy().queryUpdateDataBySql(sql.toString(), "t_sac_job_schedule_rec");
	}
	
	/**
	 * @desc 改记录状态
	 * @author Ervin
	 * @date 2017年2月24日 上午7:42:17
	 */
	private void writeBackNewRecordStatus (boolean success, String startTime, String endTime) {
		StringBuffer sql = new StringBuffer();
		if (success) {
			sql.append("UPDATE t_sac_job_schedule_rec SET JOB_END_TIME = now(), JOB_STATUS = '1' WHERE JOB_STATUS = '5' AND DELETED_FLAG = 0 AND JOB_NAME = '");
			sql.append(Table.T_SAC_MID_ERP_PO_HEADER);
			sql.append("' AND DATA_START_TIME = '");
			sql.append(startTime);
			sql.append("' AND DATA_END_TIME = '");
			sql.append(endTime);
			sql.append("'");
		} else {
			sql.append("UPDATE t_sac_job_schedule_rec SET JOB_END_TIME = now(), JOB_STATUS = '0' WHERE JOB_STATUS = '5' AND  DELETED_FLAG = 0 AND JOB_NAME = '");
			sql.append(Table.T_SAC_MID_ERP_PO_HEADER);
			sql.append("' AND DATA_START_TIME = '");
			sql.append(startTime);
			sql.append("' AND DATA_END_TIME = '");
			sql.append(endTime);
			sql.append("'");
		}
		getInnerQueryProxy().queryUpdateDataBySql(sql.toString(), "t_sac_job_schedule_rec");
	}
	
	/*public static void main(String[] args) throws ParseException {
		InquiryPoHeaderInfoClient client = new InquiryPoHeaderInfoClient();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sstart = "2017-02-22 00:00:00";
		String send = "2017-02-22 23:59:59";

		//输入查询条件,最后更新时间开始(Y/N)
		Calendar start = Calendar.getInstance();
		start.setTime(df.parse(sstart));
		//输入查询条件,最后更新时间结束(Y/N)
		Calendar end = Calendar.getInstance();
		end.setTime(df.parse(send));
		
		client.getPoHeaderData("11", start, end);
	}*/
}
