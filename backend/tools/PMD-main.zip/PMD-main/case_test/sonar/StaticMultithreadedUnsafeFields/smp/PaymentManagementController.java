package com.dtt.smp.synergy.controller.pay;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dtt.sett.pay.bean.BasicPayResponse;
import com.dtt.sett.pay.service.innerservice.PaymentInnerHandlerServicePrx;
import com.dtt.smp.synergy.bean.Result;
import com.dtt.smp.synergy.bean.pay.PaymentBean;
import com.dtt.smp.synergy.bean.pay.PaymentBillingRelation;
import com.dtt.smp.synergy.bean.pay.PaymentInfo;
import com.dtt.smp.synergy.bean.pay.PaymentList;
import com.dtt.smp.synergy.util.ServiceProxyClient;
import com.dtt.smp.synergy.util.StaticEnumStorage;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@Api(value="支付管理相关接口", tags={"Payment"})
@RestController
@RequestMapping("payment")
public class PaymentManagementController {

	private static final Logger logger = LoggerFactory.getLogger(PaymentManagementController.class);
	private static final SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd");
	private static final SimpleDateFormat timeFormatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static final int DATE_TYPE_DATE = 1;
	private static final int DATE_TYPE_TIME = 2;
	
	/**
	 * 查询付款信息
	 * @param dateBegin 最近修改日期范围开始
	 * @param dateEnd 最近修改日期范围结束
	 * @param vendorIds 供应商ID集合
	 * @return
	 */
	@ApiOperation(value="查询付款信息", notes="查询付款信息")
	@ApiImplicitParams({
		@ApiImplicitParam(name="dateBegin",value="最近修改日期范围开始，格式\"yyyyMMdd\"，例：20180912",required=true,paramType="form",dataType="String"),
		@ApiImplicitParam(name="dateEnd",value="最近修改日期范围结束，格式\"yyyyMMdd\"，例：20180914",required=true,paramType="form",dataType="String"),
		@ApiImplicitParam(name="vendorIds",value="供应商ID,多供应商ID以\",\"分隔",required=true,paramType="form",dataType="String")
	})
	@RequestMapping(value="query", method=RequestMethod.POST)
	public Result<List<PaymentBean>> open(String dateBegin, String dateEnd, String vendorIds) {
		// 校验参数
		if (StringUtils.isEmpty(dateBegin)) {
			return new Result<>("SMP-000001", "参数开始时间缺失.");
		}
		if (StringUtils.isEmpty(dateEnd)) {
			return new Result<>("SMP-000001", "参数结束时间缺失.");
		}
		if (StringUtils.isEmpty(vendorIds)) {
			return new Result<>("SMP-000001", "参数供应商ID缺失.");
		}
		// 转换参数并调用服务
		Map<String, String> request = new HashMap<>();
		request.put("dateBegin", dateBegin);
		request.put("dateEnd", dateEnd);
		request.put("vendorIds", vendorIds);
		PaymentInnerHandlerServicePrx serviceProxy = ServiceProxyClient.getPaymentInnerHandlerServicePrx();
		BasicPayResponse basicPayResponse = serviceProxy.querySynergyPayments(request);
		// 服务结果处理
		if (basicPayResponse == null) {
			return new Result<>("SMP-000009", "服务未知错误.");
		}
		if (!basicPayResponse.isSuccess) {
			return new Result<>("SMP-000002", "服务处理异常：" + basicPayResponse.msg);
		}
		String jsonStrResult = basicPayResponse.result;
		JSONArray arrayResult = null;
		try{
			arrayResult = JSONArray.parseArray(jsonStrResult);
		}catch (Exception e) {
			logger.error("/payment/query,服务处理异常：不能转换的结果 -> " + jsonStrResult);
			return new Result<>("SMP-000002", "服务处理异常：不能转换的结果" );
		}
		if (arrayResult == null) {
			logger.error("/payment/query,服务处理异常：不能转换的结果 -> " + jsonStrResult);
			return new Result<>("SMP-000002", "服务处理异常：不能转换的结果" );
		}
		// 服务结果转换
		List<PaymentBean> payments = transferResult(arrayResult);
		return new Result<>(payments);
	}
	
	/**
	 * 将JsonArray转换为对象List
	 * @param array
	 * @return
	 */
	private List<PaymentBean> transferResult(JSONArray array){
		List<PaymentBean> payments = new ArrayList<>();
		Map<String, PaymentInfo> infoMap = new HashMap<>();
		Map<String, Map<String, PaymentList>> listMap = new HashMap<>();
		Map<String, Map<String, PaymentBillingRelation>> relationMap = new HashMap<>();
		if (array != null && array.size() > 0) {
			// 行处理，抽取每行数据的各个实体
			for(int i = 0; i < array.size(); i ++){
				JSONObject object = array.getJSONObject(i);
				// 获取并临时存储付款单信息
				PaymentInfo info = this.getPaymentInfo(object);
				infoMap.put(info.getPaymentInfoId(), info);
				// 获取并临时存储付款清单信息 
				PaymentList list = this.getPaymentList(object);
				PaymentBillingRelation relation = this.getPaymentBillingRelation(object);
				infoMap.put(info.getPaymentInfoId(), info);
				Map<String, PaymentList> paymentListMap = listMap.get(info.getPaymentInfoId());
				if (paymentListMap == null) {
					paymentListMap = new HashMap<>();
				}
				// 获取并临时存储付款关联开票信息 
				paymentListMap.put(list.getPaymentListId(), list);
				listMap.put(info.getPaymentInfoId(), paymentListMap);
				Map<String, PaymentBillingRelation> paymentRelationMap = relationMap.get(info.getPaymentInfoId());
				if (paymentRelationMap == null) {
					paymentRelationMap = new HashMap<>();
				}
				paymentRelationMap.put(relation.getPaymentRelBillingInfoId(), relation);
				relationMap.put(info.getPaymentInfoId(), paymentRelationMap);
			}
			// 将临时存储转换为正式对象
			for(String key : infoMap.keySet()){
				// 保存付款单对象
				PaymentBean paymentBean = new PaymentBean();
				paymentBean.setPaymentInfo(infoMap.get(key));
				// 保存付款清单列表
				List<PaymentList> lists = new ArrayList<>();
				Map<String, PaymentList> paymentListMap = listMap.get(key);
				if (paymentListMap != null) {
					for (PaymentList paymentList : paymentListMap.values()) {
						lists.add(paymentList);
					}
				}
				paymentBean.setPaymentLists(lists);
				// 保存付款关联开票列表
				List<PaymentBillingRelation> relations = new ArrayList<>();
				Map<String, PaymentBillingRelation> paymentRelationMap = relationMap.get(key);
				if (paymentRelationMap != null) {
					for(PaymentBillingRelation paymentBillingRelation : paymentRelationMap.values()){
						relations.add(paymentBillingRelation);
					}
				}
				paymentBean.setPaymentBillingRelations(relations);
				// 目标列表中保存完整支付单对象
				payments.add(paymentBean);
			}
		}
		return payments;
	}
	
	/**
	 * 提取付款单对象
	 * @param jsonObject
	 * @return
	 */
	private PaymentInfo getPaymentInfo(JSONObject jsonObject){
		PaymentInfo info = new PaymentInfo();
		info.setAccountingStatus(jsonObject.getString("INFO$ACCOUNTING_STATUS"));
		info.setActivityDefName(jsonObject.getString("INFO$ACTIVITY_DEF_NAME"));
		info.setApprovalDate(transferDateTime(jsonObject.getString("INFO$APPROVAL_DATE"), DATE_TYPE_DATE));
		info.setBussinessType(jsonObject.getString("INFO$BUSSINESS_TYPE"));
		info.setContractInfoId(jsonObject.getString("INFO$CONTRACT_INFO_ID"));
		info.setContractName(jsonObject.getString("INFO$CONTRACT_NAME"));
		info.setContractNum(jsonObject.getString("INFO$CONTRACT_NUM"));
		info.setEmsTransNum(jsonObject.getString("INFO$EMS_TRANS_NUM"));
		info.setMallType(jsonObject.getString("INFO$MALL_TYPE"));
		info.setOriginalCurrencyAmount(jsonObject.getString("INFO$ORIGINAL_CURRENCY_AMOUNT"));
		info.setPartnerCode(jsonObject.getString("INFO$PARTNER_CODE"));
		info.setPartnerHandlePersonCode(jsonObject.getString("INFO$PARTNER_HANDLE_PERSON_CODE"));
		info.setPartnerHandlePersonId(jsonObject.getString("INFO$PARTNER_HANDLE_PERSON_ID"));
		info.setPartnerHandlePersonName(jsonObject.getString("INFO$PARTNER_HANDLE_PERSON_NAME"));
		info.setPartnerInfoId(jsonObject.getString("INFO$PARTNER_INFO_ID"));
		info.setPartnerName(jsonObject.getString("INFO$PARTNER_NAME"));
		info.setPaymentAmount(jsonObject.getString("INFO$PAYMENT_AMOUNT"));
		info.setPaymentBankAccountName(jsonObject.getString("INFO$PAYMENT_BANK_ACCOUNT_NAME"));
		info.setPaymentBankAccountNo(jsonObject.getString("INFO$PAYMENT_BANK_ACCOUNT_NO"));
		info.setPaymentBankBranchName(jsonObject.getString("INFO$PAYMENT_BANK_BRANCH_NAME"));
		info.setPaymentBankName(jsonObject.getString("INFO$PAYMENT_BANK_NAME"));
		info.setPaymentCurrency(jsonObject.getString("INFO$PAYMENT_CURRENCY"));
		info.setPaymentDate(transferDateTime(jsonObject.getString("INFO$PAYMENT_DATE"), DATE_TYPE_DATE));
		info.setPaymentDesc(jsonObject.getString("INFO$PAYMENT_DESC"));
		info.setPaymentExchangeRate(jsonObject.getString("INFO$PAYMENT_EXCHANGE_RATE"));
		info.setPaymentInfoCode(jsonObject.getString("INFO$PAYMENT_INFO_CODE"));
		info.setPaymentInfoId(jsonObject.getString("INFO$PAYMENT_INFO_ID"));
		info.setPaymentMethods(jsonObject.getString("INFO$PAYMENT_METHODS"));
		info.setPaymentOrgId(jsonObject.getString("INFO$PAYMENT_ORG_ID"));
		info.setPaymentStatus(jsonObject.getString("INFO$PAYMENT_STATUS"));
		info.setPaymentType(jsonObject.getString("INFO$PAYMENT_TYPE"));
		info.setRemark(jsonObject.getString("INFO$REMARK"));
		info.setReversedTime(transferDateTime(jsonObject.getString("INFO$REVERSED_TIME"), DATE_TYPE_TIME));
		info.setSettlePattern(jsonObject.getString("INFO$SETTLE_PATTERN"));
		info.setUnicomBankInfoId(jsonObject.getString("INFO$UNICOM_BANK_INFO_ID"));
		info.setVendorSiteCode(jsonObject.getString("INFO$VENDOR_SITE_CODE"));
		info.setVendorSiteId(jsonObject.getString("INFO$VENDOR_SITE_ID"));
		// 替换枚举
		info.setAccountingStatus(StaticEnumStorage.getEnumMeaning("ACCOUNTING_STATUS", info.getAccountingStatus()));
		info.setPaymentCurrency(StaticEnumStorage.getEnumMeaning("CURRENCY", info.getPaymentCurrency()));
		info.setPaymentMethods(StaticEnumStorage.getEnumMeaning("PAYMENT_METHODS", info.getPaymentMethods()));
		info.setPaymentType(StaticEnumStorage.getEnumMeaning("PAYMENT_TYPE", info.getPaymentType()));
		info.setSettlePattern(StaticEnumStorage.getEnumMeaning("SETTLE_PATTERN", info.getSettlePattern()));
		return info;
	}
	
	/**
	 * 提取付款清单对象
	 * @param jsonObject
	 * @return
	 */
	private PaymentList getPaymentList(JSONObject jsonObject){
		PaymentList list = new PaymentList();
		list.setAccountingStatus(jsonObject.getString("LIST$ACCOUNTING_STATUS"));
		list.setActualPaidOffDate(transferDateTime(jsonObject.getString("LIST$ACTUAL_PAID_OFF_DATE"), DATE_TYPE_TIME));
		list.setAttachmentSheets(jsonObject.getString("LIST$ATTACHMENT_SHEETS"));
		list.setErpPushStatusFlag(jsonObject.getString("LIST$ERP_PUSH_STATUS_FLAG"));
		list.setErpVouchaerNum(jsonObject.getString("LIST$ERP_VOUCHAER_NUM"));
		list.setIsFrozenFlag(jsonObject.getString("LIST$IS_FROZEN_FLAG"));
		list.setListSeq(jsonObject.getString("LIST$LIST_SEQ"));
		list.setOriginalCurrencyAmount(jsonObject.getString("LIST$ORIGINAL_CURRENCY_AMOUNT"));
		list.setPartnerInfoId(jsonObject.getString("LIST$PARTNER_INFO_ID"));
		list.setPartnerPayBAInfoId(jsonObject.getString("LIST$PARTNER_PAY_B_A_INFO_ID"));
		list.setPaymentDate(transferDateTime(jsonObject.getString("LIST$PAYMENT_DATE"), DATE_TYPE_DATE));
		list.setPaymentDesc(jsonObject.getString("LIST$PAYMENT_DESC"));
		list.setPaymentInfoId(jsonObject.getString("LIST$PAYMENT_INFO_ID"));
		list.setPaymentListId(jsonObject.getString("LIST$PAYMENT_LIST_ID"));
		list.setPaymentListStat(jsonObject.getString("LIST$PAYMENT_LIST_STAT"));
		list.setPaymentType(jsonObject.getString("LIST$PAYMENT_TYPE"));
		list.setReceivableAccountNo(jsonObject.getString("LIST$RECEIVABLE_ACCOUNT_NO"));
		list.setReceivableBankOfDeposit(jsonObject.getString("LIST$RECEIVABLE_BANK_OF_DEPOSIT"));
		list.setReceivablesAccountCode(jsonObject.getString("LIST$RECEIVABLES_ACCOUNT_CODE"));
		list.setReceivablesAccountName(jsonObject.getString("LIST$RECEIVABLES_ACCOUNT_NAME"));
		list.setReversedTime(transferDateTime(jsonObject.getString("LIST$REVERSED_TIME"), DATE_TYPE_TIME));
		list.setReversedVoucherNum(jsonObject.getString("LIST$REVERSED_VOUCHER_NUM"));
		list.setThisPaidOffAmount(jsonObject.getString("LIST$THIS_PAID_OFF_AMOUNT"));
		// 替换枚举
		list.setAccountingStatus(StaticEnumStorage.getEnumMeaning("ACCOUNTING_STATUS", list.getAccountingStatus()));
		list.setPaymentType(StaticEnumStorage.getEnumMeaning("PAYMENT_TYPE", list.getPaymentType()));
		return list;
	}
	
	/**
	 * 提取付款管理开票信息对象
	 * @param jsonObject
	 * @return
	 */
	private PaymentBillingRelation getPaymentBillingRelation(JSONObject jsonObject){
		PaymentBillingRelation relation = new PaymentBillingRelation();
		relation.setPaymentRelBillingInfoId(jsonObject.getString("RBI$PAYMENT_REL_BILLING_INFO_ID"));
		relation.setBillingGroupSumInfoId(jsonObject.getString("RBI$BILLING_GROUP_SUM_INFO_ID"));
		relation.setConItemId(jsonObject.getString("RBI$CON_ITEM_ID"));
		relation.setContractInfoId(jsonObject.getString("RBI$CONTRACT_INFO_ID"));
		relation.setContractNum(jsonObject.getString("RBI$CONTRACT_NUM"));
		relation.setPaymentPhaseSeq(jsonObject.getString("RBI$PAYMENT_PHASE_SEQ"));
		relation.setPaymentStageEnumId(jsonObject.getString("RBI$PAYMENT_STAGE_ENUM_ID"));
		relation.setProjectInfoId(jsonObject.getString("RBI$PROJECT_INFO_ID"));
		relation.setProjectNumber(jsonObject.getString("RBI$PROJECT_NUMBER"));
		relation.setProjectName(jsonObject.getString("RBI$PROJECT_NAME"));
		relation.setBillingInfoId(jsonObject.getString("RBI$BILLING_INFO_ID"));
		relation.setBillingCode(jsonObject.getString("RBI$BILLING_CODE"));
		relation.setBillingInclusiveTaxAmt(jsonObject.getString("RBI$BILLING_INCLUSIVE_TAX_AMT"));
		relation.setBillingDate(transferDateTime(jsonObject.getString("RBI$BILLING_DATE"), DATE_TYPE_DATE));
		relation.setThisPaymentAmount(jsonObject.getString("RBI$THIS_PAYMENT_AMOUNT"));
		relation.setPaymentInfoId(jsonObject.getString("RBI$PAYMENT_INFO_ID"));
		relation.setPaymentInfoCode(jsonObject.getString("RBI$PAYMENT_INFO_CODE"));
		relation.setPaymentListId(jsonObject.getString("RBI$PAYMENT_LIST_ID"));
		relation.setListSeq(jsonObject.getString("RBI$LIST_SEQ"));
		relation.setIsReversedFlag(jsonObject.getString("RBI$IS_REVERSED_FLAG"));
		relation.setReversedOriginalInfoId(jsonObject.getString("RBI$REVERSED_ORIGINAL_INFO_ID"));
		relation.setRescindedTime(transferDateTime(jsonObject.getString("RBI$RESCINDED_TIME"), DATE_TYPE_TIME));
		relation.setChargeTypeEnumId(jsonObject.getString("RBI$CHARGE_TYPE_ENUM_ID"));
		relation.setPoNumber(jsonObject.getString("RBI$PO_NUMBER"));
		relation.setOrderTransactionOrgId(jsonObject.getString("RBI$ORDER_TRANSACTION_ORG_ID"));
		relation.setOrderOrgCode(jsonObject.getString("RBI$ORDER_ORG_CODE"));
		relation.setOrderOrgName(jsonObject.getString("RBI$ORDER_ORG_NAME"));
		relation.setPurchaseUnitOrgCode(jsonObject.getString("RBI$PURCHASE_UNIT_ORG_CODE"));
		relation.setPurchaseUnitOrgName(jsonObject.getString("RBI$PURCHASE_UNIT_ORG_NAME"));
		relation.setConSignTransactionOrgId(jsonObject.getString("RBI$CON_SIGN_TRANSACTION_ORG_ID"));
		relation.setConSignTransactionOrgName(jsonObject.getString("RBI$CON_SIGN_TRANSACTION_ORG_NAME"));
		relation.setSettleAccCode(jsonObject.getString("RBI$SETTLE_ACC_CODE"));
		relation.setSettleAccTotalAmt(jsonObject.getString("RBI$SETTLE_ACC_TOTAL_AMT"));
		relation.setOrderHeaderId(jsonObject.getString("RBI$ORDER_HEADER_ID"));
		relation.setContractType(jsonObject.getString("RBI$CONTRACT_TYPE"));
		// 替换枚举
		relation.setPaymentStageEnumId(StaticEnumStorage.getEnumMeaning("PAYMENT_STAGE", relation.getPaymentStageEnumId()));
		relation.setChargeTypeEnumId(StaticEnumStorage.getEnumMeaning("CHARGE_TYPE", relation.getChargeTypeEnumId()));
		return relation;
	}
	
	private String transferDateTime(String strTimestamp, int type){
		String result = "";
		if (DATE_TYPE_DATE == type) {
			try{
				result = dateFormatter.format(new Date(Long.valueOf(strTimestamp)));
			}catch (Exception e) {
//				logger.warn("日期转换错误，传入：" + strTimestamp);
			}
		}else if (DATE_TYPE_TIME == type) {
			try{
				result = timeFormatter.format(new Date(Long.valueOf(strTimestamp)));
			}catch (Exception e) {
//				logger.warn("日期转换错误，传入：" + strTimestamp);
			}
		}
		return result;
	}
 }
