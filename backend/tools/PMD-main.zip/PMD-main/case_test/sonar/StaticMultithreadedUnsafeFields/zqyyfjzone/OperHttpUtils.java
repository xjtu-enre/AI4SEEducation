package com.ai.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URI;
import java.net.URISyntaxException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * 能力商店接口
 */
public class OperHttpUtils {

    private static final Logger logger = LoggerFactory.getLogger(OperHttpUtils.class);

    //TIMESTAMP格式
    private static final SimpleDateFormat TIMESTAMP_SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS");
    //TRANS格式
    private static final SimpleDateFormat TRANS_SDF = new SimpleDateFormat("yyyyMMddHHmmssSSS");
    //SERIAL_NUMBER 取值范围
    private static final int SERIAL_NUMBER_RANGE = 1000000;
    //连接超时时间,单位毫秒
    private static final int TIMEOUT = 40 * 1000;

    private static volatile HttpClient client = null;

    private static HttpClient getInstant() {
        if (null == client) {
            synchronized (OperHttpUtils.class) {
                if (null == client) {
                    HttpClientBuilder clientBuilder = HttpClients.custom();
                    PoolingHttpClientConnectionManager cm;
                    cm = new PoolingHttpClientConnectionManager();
                    cm.setDefaultMaxPerRoute(60);
                    cm.setMaxTotal(60);
                    clientBuilder.setConnectionManager(cm);
                    client = clientBuilder.build();
                }
            }
        }
        return client;
    }

    /**
     * @param apiUrl     接口地址
     * @param requestStr 请求数据
     * @return
     */
    public static String invoke(String apiUrl, String requestStr) {
        HttpClient httpClient = getInstant();
        //实际url
        URI url = null;
        HttpPost post = null;
        String resStr = null;
        try {
//            apiUrl = OperHttpUtils.ROOT_URL + apiUrl;
            logger.info("调用能力商店URL:{}", apiUrl);
            try {
                url = new URI(apiUrl);
            } catch (URISyntaxException e2) {
                logger.info("错误的请求url:{}", apiUrl);
            }
            post = new HttpPost(url);
            //设置连接超时
            RequestConfig timeOut = RequestConfig.custom()
                    .setSocketTimeout(TIMEOUT)
                    .setConnectionRequestTimeout(TIMEOUT)
                    .setConnectTimeout(TIMEOUT)
                    .build();
            post.setConfig(timeOut);
            //String requestStr = "";//buildRequest(requestContext);
//            logger.info("请求参数:" + requestStr);
//            requestStr = createRequest(requestStr);
            logger.info("调用能力商店实际请求串:" + requestStr);
            HttpEntity content = new StringEntity(requestStr, ContentType.create("application/json", "UTF-8"));
            post.setEntity(content);
            post.addHeader("Accept", "application/json");
            post.addHeader("Accept-Encoding", "");

            HttpResponse response = null;
            try {
                response = httpClient.execute(post);
            } catch (Exception e) {
                logger.error("execute(),调用能力商店调用接口接口异常:", e);
            }

            HttpEntity entity = response.getEntity();
            String responseStr = null;
            try {
                responseStr = EntityUtils.toString(entity);

            } catch (Exception e1) {
                logger.error("EntityUtils.toString(),调用能力商店调用接口接口异常:", e1);
            }
            logger.info("结果打印:", responseStr);
            resStr = getResData(responseStr);

        } catch (Exception e1) {
            logger.error("调用能力共享平台调用接口接口invoke异常:", e1);
            resStr = getResData(null);
        } finally {
            if (post != null) {
                post.releaseConnection();
            }
        }
        logger.info("调用能力商店调用接口最终返回串:" + resStr);
        return resStr;
    }

    //发送json格式的post
    public static String postByJson(String apiUrl, String requestStr) {
        HttpClient httpClient = getInstant();
        //实际url
        URI url = null;
        HttpPost post = null;
        String responseStr = null;
        try {
            logger.info("调用URL:{}", apiUrl);
            try {
                url = new URI(apiUrl);
            } catch (URISyntaxException e2) {
                logger.info("错误的请求url:{}", apiUrl);
                return null;
            }
            post = new HttpPost(url);
            //设置连接超时
            RequestConfig timeOut = RequestConfig.custom()
                    .setSocketTimeout(TIMEOUT)
                    .setConnectionRequestTimeout(TIMEOUT)
                    .setConnectTimeout(TIMEOUT)
                    .build();
            post.setConfig(timeOut);
            if (StringUtils.isNotBlank(requestStr)) {
                logger.info("实际请求串:" + requestStr);
                HttpEntity content = new StringEntity(requestStr, ContentType.create("application/json", "UTF-8"));
                post.setEntity(content);
            }
            post.addHeader("Accept", "application/json");
            post.addHeader("Accept-Encoding", "");

            HttpResponse response = null;
            response = httpClient.execute(post);
            HttpEntity entity = response.getEntity();
            responseStr = EntityUtils.toString(entity);
            logger.info("结果打印:", responseStr);
        } catch (Exception e1) {
            logger.error("调用接口异常:", e1);
        } finally {
            if (post != null) {
                post.releaseConnection();
            }
        }
        return responseStr;
    }

    private static String getSerialNumber(String timestamp) {

        int randomNum = new Random().nextInt(SERIAL_NUMBER_RANGE);

        return timestamp + StringUtils.leftPad(String.valueOf(randomNum), 6, "0");
    }

    //创建请求到能力商店中体请求体
//    private static String createRequest(String bodyStr) {
//
//        JSONObject head = new JSONObject();
//        Date date = new Date();
//        String timestamp = TIMESTAMP_SDF.format(date);
//        String transtamp = TRANS_SDF.format(date);
//        String serialNumber = getSerialNumber(transtamp);
//        String token = getToken(OperHttpUtils.APPID, OperHttpUtils.APPSECRET, timestamp, serialNumber);
//        head.put("APP_ID", OperHttpUtils.APPID);
//        head.put("TIMESTAMP", timestamp);
//        head.put("TRANS_ID", serialNumber);
//        head.put("TOKEN", token);
//        JSONArray reserved = new JSONArray();
//        head.put("RESERVED", reserved);
//
//        JSONObject attached = new JSONObject();
//        attached.put("MEDIA_INFO", "");
//
//        //实际的请求参数
//        JSONObject body = JSONObject.parseObject(bodyStr);
//
//        JSONObject reqObj = new JSONObject();
//        reqObj.put("UNI_BSS_HEAD", head);
//        reqObj.put("UNI_BSS_ATTACHED", attached);
//        reqObj.put("UNI_BSS_BODY", body);
//        return reqObj.toString();
//    }

    public static String createRequest(JSONObject body, String app_key, String app_secret) {

        JSONObject head = new JSONObject();
        Date date = new Date();
        String timestamp = TIMESTAMP_SDF.format(date);
        String transtamp = TRANS_SDF.format(date);
        String serialNumber = getSerialNumber(transtamp);
        String token = getToken(app_key, app_secret, timestamp, serialNumber);
        head.put("APP_ID", app_key);
        head.put("TIMESTAMP", timestamp);
        head.put("TRANS_ID", serialNumber);
        head.put("TOKEN", token);
        JSONArray reserved = new JSONArray();
        head.put("RESERVED", reserved);

        JSONObject attached = new JSONObject();
        attached.put("MEDIA_INFO", "");

        //实际的请求参数
//        JSONObject body = JSONObject.parseObject(bodyStr);

        JSONObject reqObj = new JSONObject();
        reqObj.put("UNI_BSS_HEAD", head);
        reqObj.put("UNI_BSS_ATTACHED", attached);
        reqObj.put("UNI_BSS_BODY", body);
        return reqObj.toString();
    }

    private static String getResData(String ret) {
        //{"UNI_BSS_HEAD":{"RESP_DESC":"Success","TRANS_ID":"20171104132859699997763","TIMESTAMP":"2017-11-04 13:28:59 699","RESP_CODE":"0000","APP_ID":"9TEGDqOv8G"},"UNI_BSS_ATTACHED":{"MEDIA_INFO":""},"UNI_BSS_BODY":{"UNIV_DEVELOP_ORGINFO_CHECK_RSP":{"respCode":"0000","respDesc":"调用成功","univDevelopOrgInfoCheckResp":[{"developValue":"380H034","developValueName":"林丹铃","valid":true}],"univDevelopOrgInfoCheckRespCount":1,"valid":true}}}
        JSONObject entity = new JSONObject();
        try {
            entity.put("CODE", "0000");
            entity.put("MESSAGE", "成功");
            if (StringUtils.isNotBlank(ret)) {
                JSONObject jsonO = JSONObject.parseObject(ret);
                JSONObject head = jsonO.getJSONObject("UNI_BSS_HEAD");
                String code = head.getString("RESP_CODE");
                if ("00000".equals(code) || "0000".equals(code)) {
                    JSONObject data = jsonO.getJSONObject("UNI_BSS_BODY");
                    entity.put("DATA", data);
                } else {
                    entity.put("CODE", code);
                    String resp_desc = head.getString("RESP_DESC");
                    entity.put("MESSAGE", resp_desc);
                }
            } else {
                entity.put("DATA", "");
                entity.put("CODE", "9999");
                entity.put("MESSAGE", "失败");
            }
        } catch (Exception e) {
            entity.put("CODE", "9999");
            entity.put("MESSAGE", "失败");
            entity.put("DATA", "");
            e.printStackTrace();
        }

        return entity.toString();
    }

    private static String getToken(String appKey, String appSecret, String timestamp, String serialNumber) {

        StringBuffer foo = new StringBuffer()
                .append("APP_ID")
                .append(appKey)
                .append("TIMESTAMP")
                .append(timestamp)
                .append("TRANS_ID")
                .append(serialNumber)
                .append(appSecret);

        return getMd5(foo.toString());
    }

    private static String getMd5(String plainText) {
        StringBuffer buf = new StringBuffer("");
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(plainText.getBytes());
            byte b[] = md.digest();

            int i;

            buf = new StringBuffer("");
            for (int offset = 0; offset < b.length; offset++) {
                i = b[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            //32位加密
            // return buf.toString();
        } catch (NoSuchAlgorithmException e) {

            e.printStackTrace();
        }
        return buf.toString();
    }

}
