package com.ai.gcrm.service.sys.impl;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import oracle.sql.BLOB;
import xframe.core.flexigrid.FlexiGridUtils;


import com.ai.appframe2.common.ServiceManager;
import com.ai.appframe2.service.ServiceFactory;
import com.ai.gcrm.action.cust.ChancePartnersAction;
import com.ai.gcrm.bean.sys.AiSysIntfLogEngine;
import com.ai.gcrm.bean.sys.AiSysUserBean;
import com.ai.gcrm.service.sys.interfaces.ISysIntfLogSV;
import com.ai.gcrm.service.sys.interfaces.IUserSV;
import com.ai.gcrm.usermodel.sys.LogSearchModel;
import com.ai.gcrm.usermodel.sys.UserModel;
import com.ai.utils.Constants;
import com.ai.utils.DBUtil;
import com.ai.utils.cache.UserBean;
import com.ai.webservice.util.IntfLog;

public class SysIntfLogSVImpl implements ISysIntfLogSV {
	private IUserSV userSV = (IUserSV) ServiceFactory.getService(IUserSV.class);
	private static final DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static Logger logger=LoggerFactory.getLogger(ChancePartnersAction.class);

	@SuppressWarnings("deprecation")
	@Override
	public void saveIntfLog(IntfLog log) throws Exception {
		//通过电话号码，或userCode获取userId
		long userId = 0;
		UserModel searchModel = new UserModel();
		searchModel.setUserLoginName(log.getUserCode());
		searchModel.setMobilePhone(log.getSvcNum());
		Long emplyId = userSV.getEmpIdByNameOPhone(searchModel);
		if(emplyId != null && emplyId != 0){
			AiSysUserBean bean = userSV.getSysUserBean(emplyId);
			userId = bean.getUserId();
		}

		long intfId = AiSysIntfLogEngine.getNewId().longValue();
		Connection conn = ServiceManager.getSession().getConnection();
		StringBuilder insertSql = new StringBuilder();
		insertSql.append("INSERT INTO AI_SYS_INTF_LOG(INTF_ID,BUSI_PROC_NUM,INTF_CODE,INTF_NAME,LOG_LEVEL,")
		.append("REQ_TIME,REQUEST,RESPONSE,RSP_TIME,RESULT,RET_DESC,USER_CODE,IMSI,IMEI,VERSION,BRAND,MODEL,OS,REMARK,COST_TIME,USER_ID) ")
		.append(" VALUES(?,?,?,?,?,to_date(?,'yyyy-mm-dd hh24:mi:ss'),?,?,to_date(?,'yyyy-mm-dd hh24:mi:ss'),?,?,?,?,?,?,?,?,?,?,?,?)");
		PreparedStatement pstmt = conn.prepareStatement(insertSql.toString());
		pstmt.setLong(1, intfId);
		pstmt.setString(2,log.getBusiProcNum());
		pstmt.setString(3,log.getIntfCode());
		pstmt.setString(4,log.getIntfName());
		pstmt.setString(5,log.getLogLevel());
		pstmt.setString(6, df.format(log.getReqTime()));
		//		oracle 11.2+jdbc4.0 ,目前系统使用数据库版本10.2，不支持以下方法
		//		Blob blobRequst = conn.createBlob();
		//		if(log.getRequest() != null){
		//			OutputStream reqOut = blobRequst.setBinaryStream(0);
		//			reqOut.write(log.getRequest(), 0, log.getRequest().length);
		//		}
		//		Blob blobResponse = conn.createBlob();
		//		if(log.getResponse() != null){
		//			OutputStream rspOut = blobResponse.setBinaryStream(0);
		//			rspOut.write(log.getResponse(), 0, log.getResponse().length);
		//		}
		pstmt.setBlob(7, BLOB.getEmptyBLOB());
		pstmt.setBlob(8, BLOB.getEmptyBLOB());
		pstmt.setString(9, df.format(log.getRspTime()));
		pstmt.setString(10,log.getResult());
		pstmt.setString(11,log.getRetDesc());
		pstmt.setString(12,log.getUserCode() == null ? log.getSvcNum() : log.getUserCode());
		pstmt.setString(13,log.getImsi());
		pstmt.setString(14,log.getImei());
		pstmt.setString(15,log.getVersion());
		pstmt.setString(16,log.getBrand());
		pstmt.setString(17,log.getModel());
		pstmt.setString(18,log.getOs());
		pstmt.setString(19,log.getRemark());
		pstmt.setLong(20, log.getCostTime());
		pstmt.setLong(21, userId);
		StringBuilder querySql = new StringBuilder();
//		querySql.append("SELECT REQUEST,RESPONSE FROM AI_SYS_INTF_LOG WHERE INTF_ID = ? FOR UPDATE");
		querySql.append("SELECT REQUEST,RESPONSE FROM AI_SYS_INTF_LOG WHERE INTF_ID = ? ");
		ResultSet rs = null;
		PreparedStatement pst = null;
		OutputStream reqOut = null,rspOut = null;
		try{
			pstmt.executeUpdate();//执行插入
			pst = conn.prepareStatement(querySql.toString());
			pst.setLong(1, intfId);
			rs = pst.executeQuery();//执行查询更新
			if(!rs.next()){
				throw new IllegalArgumentException("根据日志ID："+intfId+"未找到记录！");
			}
			oracle.sql.BLOB reqBlob = (oracle.sql.BLOB)rs.getBlob(1);
			reqOut = reqBlob.getBinaryOutputStream();
			reqOut.write(log.getRequest(), 0, log.getRequest().length);
			oracle.sql.BLOB rspBlob = (oracle.sql.BLOB)rs.getBlob(2);
			rspOut = rspBlob.getBinaryOutputStream();
			rspOut.write(log.getResponse(), 0, log.getResponse().length);
		}catch(Exception e){
			throw e;
		}finally{
			if(reqOut != null)reqOut.close();
			if(rspOut != null)rspOut.close();
			if(rs != null)rs.close();
			if(pst != null)pst.close();
			if(pstmt != null)pstmt.close();
			if(conn != null)conn.close();
		}
	}

	@Override
	public void saveMsgLog(IntfLog log)     {

		try {
			long intfId = AiSysIntfLogEngine.getNewId().longValue();
			Connection conn = ServiceManager.getSession().getConnection();
			StringBuilder insertSql = new StringBuilder();
			insertSql.append("INSERT INTO AI_SYS_INTF_LOG(INTF_ID,INTF_CODE,")
			.append("REQ_TIME,REQUEST,RESPONSE,RSP_TIME,RESULT,RET_DESC,USER_CODE) ")
			.append(" VALUES(?,?,to_date(?,'yyyy-mm-dd hh24:mi:ss'),?,?,to_date(?,'yyyy-mm-dd hh24:mi:ss'),?,?,'0')");
			PreparedStatement pstmt = conn.prepareStatement(insertSql.toString());
			pstmt.setLong(1, intfId);
			pstmt.setString(2,"MSGSEND");
			pstmt.setString(3, df.format(log.getReqTime()));
			//		oracle 11.2+jdbc4.0 ,目前系统使用数据库版本10.2，不支持以下方法
			//		Blob blobRequst = conn.createBlob();
			//		if(log.getRequest() != null){
			//			OutputStream reqOut = blobRequst.setBinaryStream(0);
			//			reqOut.write(log.getRequest(), 0, log.getRequest().length);
			//		}
			//		Blob blobResponse = conn.createBlob();
			//		if(log.getResponse() != null){
			//			OutputStream rspOut = blobResponse.setBinaryStream(0);
			//			rspOut.write(log.getResponse(), 0, log.getResponse().length);
			//		}
			pstmt.setBlob(4, BLOB.getEmptyBLOB());
			pstmt.setBlob(5, BLOB.getEmptyBLOB());
			pstmt.setString(6, df.format(log.getRspTime()!=null?log.getRspTime():0));
			pstmt.setString(7,log.getResult());
			pstmt.setString(8,log.getRetDesc());
			StringBuilder querySql = new StringBuilder();
			querySql.append("SELECT REQUEST,RESPONSE FROM AI_SYS_INTF_LOG WHERE INTF_ID = ? FOR UPDATE");
			ResultSet rs = null;
			PreparedStatement pst = null;
			OutputStream reqOut = null,rspOut = null;
			try{
				pstmt.executeUpdate();//执行插入
				pst = conn.prepareStatement(querySql.toString());
				pst.setLong(1, intfId);
				rs = pst.executeQuery();//执行查询更新
				if(!rs.next()){
					throw new IllegalArgumentException("根据日志ID："+intfId+"未找到记录！");
				}
				oracle.sql.BLOB reqBlob = (oracle.sql.BLOB)rs.getBlob(1);
				reqOut = reqBlob.getBinaryOutputStream();
				reqOut.write(log.getRequest(), 0, log.getRequest().length);
				oracle.sql.BLOB rspBlob = (oracle.sql.BLOB)rs.getBlob(2);
				rspOut = rspBlob.getBinaryOutputStream();
				rspOut.write(log.getResponse(), 0, log.getResponse()!=null?log.getResponse().length:0);
			}catch(Exception e){
				logger.debug(e.getMessage());
			}finally{
				if(reqOut != null)reqOut.close();
				if(rspOut != null)rspOut.close();
				if(rs != null)rs.close();
				if(pst != null)pst.close();
				if(pstmt != null)pstmt.close();
				if(conn != null)conn.close();
			}
		} catch (SQLException e) {
			logger.debug(e.getMessage());
		} catch (IOException e) {
			logger.debug(e.getMessage());
		} catch (Exception e) {
			logger.debug(e.getMessage());
		}





	}


	/**
	 *功能描述：查询接口日志  数据分三级 queryLevel为0 时统计各个模块的访问情况，为1时统计各个接口的访问情况，为2时展示接口访问详情
	 *@author 徐广林
	 *@date 2015-10-28  下午2:24:33
	 *@param searchModel
	 *修改历史：
	 */
	@Override
	public String queryIntfLog(LogSearchModel searchModel,UserBean userBean) throws Exception{

		if(0 == searchModel.getQueryLevel())
			return this.queryIntfLogLevel1(searchModel,userBean);
		else if(1 == searchModel.getQueryLevel())
			return this.queryIntfLogLevel2(searchModel,userBean);
		else if(2 == searchModel.getQueryLevel())
			return this.queryIntfLogLevel3(searchModel,userBean);
		return  "";
	}


	private String queryIntfLogLevel1(LogSearchModel searchModel,UserBean userBean) throws NumberFormatException, SQLException, Exception{
		List<Object> paramList=new ArrayList<Object>();
		StringBuffer sb= new StringBuffer()
		.append("select f.biz_func, f.biz_func_name,count(v.user_id) res_cnt,  ")
		.append( "    sum(case ")
		.append("             when v.user_id is  null then 0 ")
		.append("             when l.result = '0000' then 1 ")
		.append("             when l.result = '0001' then 1 ")
		.append("             when l.result = '0002' then 1  ")
		.append("             when l.result = '0003' then 1 ")
		.append("             when l.result = '0004' then 1 ")
		.append("             when l.result = '0005' then 1 ")
		.append("             when l.result = '0011' then 1 ")
 		.append("             when l.result = '8888' then 1 ")
		.append("             else 0 end) success_total,")
		.append("    sum(case ")
		.append("             when v.user_id is  null then 0 ")
		.append("             when l.result = '0000' then 0 ")
		.append("             when l.result = '0001' then 0 ")
		.append("             when l.result = '0002' then 0 ")
		.append("             when l.result = '0003' then 0 ")
		.append("             when l.result = '0004' then 0 ")
		.append("             when l.result = '0005' then 0 ")
		.append("             when l.result = '0011' then 0 ")
 		.append("             when l.result = '8888' then 0 ")
		.append("             when l.result is null  then 0 ")
		.append( "             else 1 ")
		.append( "           end) error_total ")
		.append( "  from ai_sys_intf_log    l,")
		.append("        ai_sys_biz_func    f,")
		.append( "       ai_sys_bizcode_map m,")
		.append( "       ai_sys_user_info_v v")
		.append( "  where f.biz_func = m.biz_func(+) ")
		.append( "        and m.biz_code = l.intf_code(+) ")
		.append( "        and l.user_id = v.user_id(+) "  );
		//数据范围控制 
		//省级
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_PRO)){
			//（7）	省分管理：查看全省所有名单制客户所关联的商机信息
		}
		//地市
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_AREA)){
			sb.append(" AND v.city_code(+) ='"+userBean.getCityCode()+"'");
		}
		//区县
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_COUNTY)){
			sb.append(" AND v.county_code(+) ='"+userBean.getCountyCode()+"'");
		}
		//部门
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_DEPT)){
			sb.append(" AND v.dept_id(+) =  '"+userBean.getDeptId()+"'");
		}
		//团队 Constants.DEPT_PTYPE_02
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_TEAM)){
			sb.append(" AND v.team_id(+)  in  (select team_id from ai_sys_user_info_v where user_id ="+userBean.getUserId()+" ) ");
		}
		//个人
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_PERSON)){
			sb.append(" AND v.user_id(+)=  "+userBean.getUserId());
		}
		if(StringUtils.isNotBlank(searchModel.getCityCode())){
			sb.append(" and v.city_code(+) =? ");
			paramList.add(searchModel.getCityCode());
		}
		if(StringUtils.isNotBlank(searchModel.getCountyCode())){
			sb.append(" and v.county_code(+) = ? ");
			paramList.add(searchModel.getCountyCode());
		}
		if(StringUtils.isNotBlank(searchModel.getRequestTimeStart())){
			sb.append(" and l.req_time(+) >= to_date(?, 'yyyy-mm-dd') ");
			paramList.add(searchModel.getRequestTimeStart());
		}
		if(StringUtils.isNotBlank(searchModel.getRequestTimeEnd())){
			sb.append(" and l.req_time(+) <= to_date(?, 'yyyy-mm-dd') ");
			paramList.add(searchModel.getRequestTimeEnd());
		}
		sb.append(		" group by f.biz_func, f.biz_func_name");
		StringBuffer sqlCount = new StringBuffer();//count sql
		StringBuffer sqlList  = new StringBuffer();//分页 sql
		sqlCount.append("select count(*) from ("+sb.toString()+")");	
		//sqlList.append("select * from ( \n");
		sqlList.append("select B.*, rownum as row_index from (");
		sqlList.append(sb.toString());
		sqlList.append(") B \n");
		//sqlList.append(") where row_index >= "+searchModel.buildPageFirst()+" and row_index <= "+searchModel.buildPageLast()+" \n");
		//int totalCnt = Integer.valueOf( DBUtil.queryForString(ServiceManager.getSession().getConnection(), sqlCount.toString(),paramList.toArray()));
		List<Map<String, Object>> list= DBUtil.getQueryMap(ServiceManager.getSession().getConnection(), sqlList.toString(), paramList.toArray());
		//return FlexiGridUtils.generateFlexiGridJson(totalCnt, searchModel.getPage(),list,null);
		return FlexiGridUtils.generateFlexiGridJson(list!=null?list.size():0, searchModel.getPage(),list,null);

	}
	private String queryIntfLogLevel2(LogSearchModel searchModel,UserBean userBean)throws NumberFormatException, SQLException, Exception{
		List<Object> paramList=new ArrayList<Object>();

		StringBuffer sb= new StringBuffer("SELECT M.BIZ_CODE,M.BIZ_NAME,")
		.append("       COUNT(v.user_id) RES_CNT,") 
		.append( "    sum(case ")
		.append("             when v.user_id is  null then 0 ")
		.append("             when l.result = '0000' then 1 ")
		.append("             when l.result = '0001' then 1 ")
		.append("             when l.result = '0002' then 1  ")
		.append("             when l.result = '0003' then 1 ")
		.append("             when l.result = '0004' then 1 ")
		.append("             when l.result = '0005' then 1 ")
		.append("             when l.result = '0011' then 1 ")
 		.append("             when l.result = '8888' then 1 ")
		.append("             else 0 end) success_total,")
		.append("    sum(case ")
		.append("             when v.user_id is  null then 0 ")
		.append("             when l.result = '0000' then 0 ")
		.append("             when l.result = '0001' then 0 ")
		.append("             when l.result = '0002' then 0 ")
		.append("             when l.result = '0003' then 0 ")
		.append("             when l.result = '0004' then 0 ")
		.append("             when l.result = '0005' then 0 ")
		.append("             when l.result = '0011' then 0 ")
 		.append("             when l.result = '8888' then 0 ")
		.append("             when l.result is null  then 0 ")
		.append( "             else 1 ")
		.append( "           end) error_total ")
		.append( "  from ai_sys_intf_log    l,")
		.append("        ai_sys_biz_func    f,")
		.append( "       ai_sys_bizcode_map m,")
		.append( "       ai_sys_user_info_v v")
		.append( "  where f.biz_func = m.biz_func(+) ")
		.append( "        and m.biz_code = l.intf_code(+) ")
		.append( "        and l.user_id = v.user_id(+) "  )
		.append("        AND F.BIZ_FUNC= ? ");
		paramList.add(searchModel.getBizFunc());
		//数据范围控制 
		//省级
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_PRO)){
			//（7）	省分管理：查看全省所有名单制客户所关联的商机信息
		}
		//地市
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_AREA)){
			sb.append(" AND v.city_code(+) ='"+userBean.getCityCode()+"'");
		}
		//区县
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_COUNTY)){
			sb.append(" AND v.county_code(+) ='"+userBean.getCountyCode()+"'");
		}
		//部门
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_DEPT)){
			sb.append(" AND v.dept_id(+) =  '"+userBean.getDeptId()+"'");
		}
		//团队 Constants.DEPT_PTYPE_02
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_TEAM)){
			sb.append(" AND v.team_id(+)  in  (select team_id from ai_sys_user_info_v where user_id ="+userBean.getUserId()+" ) ");
		}
		//个人
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_PERSON)){
			sb.append(" AND v.user_id(+)=  "+userBean.getUserId());
		}
		if(StringUtils.isNotBlank(searchModel.getCityCode())){
			sb.append(" and v.city_code(+) =? ");
			paramList.add(searchModel.getCityCode());
		}
		if(StringUtils.isNotBlank(searchModel.getCountyCode())){
			sb.append(" and v.county_code(+) = ? ");
			paramList.add(searchModel.getCountyCode());
		}
		
		if(StringUtils.isNotBlank(searchModel.getRequestTimeStart())){
			sb.append(" and l.req_time(+) >= to_date(?, 'yyyy-mm-dd') ");
			paramList.add(searchModel.getRequestTimeStart());
		}
		if(StringUtils.isNotBlank(searchModel.getRequestTimeEnd())){
			sb.append(" and l.req_time(+) <= to_date(?, 'yyyy-mm-dd') ");
			paramList.add(searchModel.getRequestTimeEnd());
		}
		
		sb.append(" GROUP BY M.BIZ_CODE,M.BIZ_NAME");

		StringBuffer sqlCount = new StringBuffer();//count sql
		StringBuffer sqlList  = new StringBuffer();//分页 sql
		sqlCount.append("select count(*) from ("+sb.toString()+")");	
		sqlList.append("select * from ( \n");
		sqlList.append("select B.*, rownum as row_index from (");
		sqlList.append(sb.toString());
		sqlList.append(") B \n");
		//sqlList.append("where rownum <= "+searchModel.buildPageLast()+" \n");
		sqlList.append(") where row_index >= "+searchModel.buildPageFirst()+" and row_index <= "+searchModel.buildPageLast()+" \n");
		int totalCnt = Integer.valueOf( DBUtil.queryForString(ServiceManager.getSession().getConnection(), sqlCount.toString(),paramList.toArray()));
		List<Map<String, Object>> list= DBUtil.getQueryMap(ServiceManager.getSession().getConnection(), sqlList.toString(), paramList.toArray());
		return FlexiGridUtils.generateFlexiGridJson(totalCnt, searchModel.getPage(),list,null);
	}
	private String queryIntfLogLevel3(LogSearchModel searchModel,UserBean userBean) throws SQLException, Exception{

		List<Object> paramList=new ArrayList<Object>();
		StringBuffer sb= new StringBuffer("select  V.city_name, V.county_name, V.dept_name,V.team_name,V.user_name,L.REQ_TIME, l.ret_desc ")  
		.append("   from AI_SYS_INTF_LOG L, AI_SYS_USER_INFO_V V")
		.append("  where L.USER_ID = V.user_id")
		.append("    AND L.intf_code = ? ");
		paramList.add(searchModel.getIntfCode());
		//数据范围控制 
		//省级
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_PRO)){
			//（7）	省分管理：查看全省所有名单制客户所关联的商机信息
		}
		//地市
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_AREA)){
			sb.append(" AND v.city_code(+) ='"+userBean.getCityCode()+"'");
		}
		//区县
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_COUNTY)){
			sb.append(" AND v.county_code(+) ='"+userBean.getCountyCode()+"'");
		}
		//部门
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_DEPT)){
			sb.append(" AND v.dept_id(+) =  '"+userBean.getDeptId()+"'");
		}
		//团队 Constants.DEPT_PTYPE_02
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_TEAM)){
			sb.append(" AND v.team_id(+)  in  (select team_id from ai_sys_user_info_v where user_id ="+userBean.getUserId()+" ) ");
		}
		//个人
		if(userBean.getUserLevel()!=null && userBean.getUserLevel().equals(Constants.SYS_USER_LEVEL_PERSON)){
			sb.append(" AND v.user_id(+)=  "+userBean.getUserId());
		}
		if(StringUtils.isNotBlank(searchModel.getCityCode())){
			sb.append(" and v.city_code(+) =? ");
			paramList.add(searchModel.getCityCode());
		}
		if(StringUtils.isNotBlank(searchModel.getCountyCode())){
			sb.append(" and v.county_code(+) = ? ");
			paramList.add(searchModel.getCountyCode());
		}
		
		
		if(StringUtils.isNotBlank(searchModel.getRequestTimeStart())){
			sb.append(" and l.req_time(+) >= to_date(?, 'yyyy-mm-dd') ");
			paramList.add(searchModel.getRequestTimeStart());
		}
		if(StringUtils.isNotBlank(searchModel.getRequestTimeEnd())){
			sb.append(" and l.req_time(+) <= to_date(?, 'yyyy-mm-dd') ");
			paramList.add(searchModel.getRequestTimeEnd());
		}
		sb.append(" order by l.req_time desc   ");
		StringBuffer sqlCount = new StringBuffer();//count sql
		StringBuffer sqlList  = new StringBuffer();//分页 sql
		sqlCount.append("select count(*) from ("+sb.toString()+")");	
		sqlList.append("select * from ( \n");
		sqlList.append("select B.*, rownum as row_index from (");
		sqlList.append(sb.toString());
		sqlList.append(") B \n");
		//sqlList.append("where rownum <= "+searchModel.buildPageLast()+" \n");
		sqlList.append(") where row_index >= "+searchModel.buildPageFirst()+" and row_index <= "+searchModel.buildPageLast()+" \n");
		int totalCnt = Integer.valueOf( DBUtil.queryForString(ServiceManager.getSession().getConnection(), sqlCount.toString(),paramList.toArray()));
		List<Map<String, Object>> list= DBUtil.getQueryMap(ServiceManager.getSession().getConnection(), sqlList.toString(), paramList.toArray());
		return FlexiGridUtils.generateFlexiGridJson(totalCnt, searchModel.getPage(),list,null);
	}




}
