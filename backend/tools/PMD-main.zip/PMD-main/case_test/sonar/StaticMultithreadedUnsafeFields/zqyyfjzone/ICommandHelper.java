package com.ai.template.cmd;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jxl.Cell;
import jxl.DateCell;
import jxl.Sheet;

import org.apache.commons.lang.StringUtils;

import com.ai.appframe2.service.ServiceFactory;
import com.ai.gcrm.bean.sys.AiSysTemplateBean;
import com.ai.gcrm.bean.sys.AiSysTmpFieldBean;
import com.ai.gcrm.service.sys.interfaces.ISysTemplateSV;
import com.ai.gcrm.service.sys.interfaces.ISysTmpFieldSV;
import com.ai.template.cmd.resolver.IValueResolver;
import com.ai.template.cmd.validator.IFieldValidator;
import com.ai.template.xls.ct.CellContainer;
import com.ai.template.xls.ct.RowContainer;
import com.ai.utils.Constants;
import com.ai.utils.Struts2Utils;
import com.ai.utils.cache.UserBean;

public abstract class ICommandHelper<T> implements ICommand<T>{
	
	protected  static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
	private ISysTemplateSV templateSV = (ISysTemplateSV)ServiceFactory.getService(ISysTemplateSV.class);
	private ISysTmpFieldSV tmpfieldSV = (ISysTmpFieldSV)ServiceFactory.getService(ISysTmpFieldSV.class);
	
	/**
	 * 功能描述：根据模版标识加载模板定义的字段表
	 * @author sunyou
	 * @createDate 2015年6月10日
	 * @param tmpIdentity
	 * @param tmpType
	 * @return
	 * @throws Exception
	 */
	public  AiSysTmpFieldBean[] loadTmpfield(String tmpIdentity,String tmpType) throws Exception{
		if(StringUtils.isEmpty(tmpIdentity)){
			throw new Exception("未定义模板标识！");
		}
		Map<String,String> parameter = new HashMap<String,String>();
		parameter.put("TMP_IDENTITY", tmpIdentity);
		parameter.put("TMP_TYPE", tmpType);//0表示导入模板，1表示导出模板
		parameter.put("STATUS", "1");//表示有效
		
		AiSysTemplateBean[] tmpbeans = templateSV.queryTmpList(parameter);
		if(tmpbeans == null || tmpbeans.length == 0){
			throw new Exception("未配置导入|导出模板！");
		}
		parameter.clear();//清除缓存
		parameter.put("TMP_UUID", tmpbeans[0].getTmpUuid());
		AiSysTmpFieldBean[] fieldbeans = tmpfieldSV.queryTmpFieldList(parameter);
		if(fieldbeans == null || fieldbeans.length == 0){
			throw new Exception("模板未配置导入|导出字段！");
		}
		return fieldbeans;
	}
	
	/**
	 * 功能描述：
	 * @author sunyou
	 * @createDate 2015年6月25日
	 * @param tmpIdentity
	 * @param tmpType
	 * @param columnCount
	 * @return
	 * @throws Exception
	 */
	public  AiSysTmpFieldBean[] loadTmpfield(String tmpIdentity,String tmpType,int columnCount) throws Exception{
		AiSysTmpFieldBean[] fieldBeans = loadTmpfield(tmpIdentity, tmpType);
		if(columnCount != fieldBeans.length){
			throw new Exception("请确认导入模板同功能要求模板格式一致！");
		}
		return fieldBeans;
	}
	
	/**
	 *功能描述：获取excel 第一个sheet页第一行的实际列数   
	 *  不用sheet.getColumns() 的原因是：如果列的内容中只有空格也会被统计进去，
	 *  所以此方法的描述为：遍历列 ，如果列的内容为空，则停止统计列的数量
	 *@author 徐广林
	 *@date 2015-9-17  下午5:43:41
	 *@param sheet
	 *@return
	 *修改历史：
	 */
	public int getSheetColumnNum(Sheet sheet){
  		for(int i=0;i<sheet.getColumns();i++){
			//只以第一行的内容来统计列的数量
			Cell cell=sheet.getCell(i, 0);
 			if(!StringUtils.isNotBlank(cell.getContents())){
 				return i;
			}
		}
 		return sheet.getColumns();
	}
	/**
	 * 功能描述：
	 * @author sunyou
	 * @createDate 2015年6月17日
	 * @param sheet
	 * @param fieldBeans
	 * @return
	 * @throws Exception 
	 */
	public  List<RowContainer<T>> sheetResolve(Sheet sheet,AiSysTmpFieldBean[] fieldBeans,Class<T> clazz,IValueResolver valueResolver,IFieldValidator validator) throws Exception{
		//从sheet中提取信息
		RowContainer<T> row = null;
		CellContainer cell = null;
		String value = null;
		List<RowContainer<T>> rowlist = new ArrayList<RowContainer<T>>();
		for (int i = 1,len = sheet.getRows(); i < len; i++) {//i = 1,跳过title
			row = new RowContainer<T>(i,true);
			T bean = clazz.newInstance();
			for (AiSysTmpFieldBean field : fieldBeans) {
				int column = Long.valueOf(field.getColNo()).intValue();
				cell = new CellContainer(i,column);
				if("Date".equals(field.getJavaType())){
					try {
						   if(StringUtils.isBlank(sheet.getCell(column,i).getContents())){
							   //日期为空则不转换为日期格式  add by 徐广林
							   value = sheet.getCell(column,i).getContents();
						   }
						   else{
							   DateCell dateCell = (DateCell)sheet.getCell(column,i);
 								value = sdf.format(dateCell.getDate());
						   }
 					} catch (Exception e) {
						e.printStackTrace();
						cell.setVmsg(sheet.getCell(column,i).getContents()+":日期格式错误！");
						row.setInsertable(false);//表示该行不能执行插入
					}
				}else{
					value = sheet.getCell(column,i).getContents();
					if(valueResolver != null){
						String oldValue=value;
						value = valueResolver.transfer(field.getEnName(),value);//存在字典转义的情况 
						if(StringUtils.isNotEmpty(oldValue) && value.equals(Constants.TRANS_DICT_VALUE_ERROE)){
							value="";
							cell.setVmsg(oldValue+":不存在该值,请检查！");//字典中不存在该值   add by 徐广林
							row.setInsertable(false);//表示该行不能执行插入
						}
					}
 				}
				cell.setEnName(field.getEnName());
				cell.setName(field.getJavaName());
				cell.setType(field.getJavaType());
				value=value!=null?value.trim():"";
				cell.setValue(value);//去除空格
				 
				//step0:是否必须字段
				if(StringUtils.isEmpty(cell.getVmsg()) && "1".equals(field.getIsRequired()) && StringUtils.isEmpty(value)){
					cell.setVmsg("必须字段不能为空！");
					row.setInsertable(false);//表示该行不能执行插入
				}
				//step1:校验字段长度限制
				if( StringUtils.isEmpty(cell.getVmsg()) && StringUtils.isNotEmpty(value) && field.getMinLen() > 0 && value.length() < field.getMinLen()){
					cell.setVmsg(value+":字段值小于最小字段长度["+field.getMinLen()+"]约束\n");
					row.setInsertable(false);
				}else if( StringUtils.isEmpty(cell.getVmsg()) && StringUtils.isNotEmpty(value) && field.getMaxLen() > 0 && value.length() > field.getMaxLen()){
					cell.setVmsg(value+":字段值大于最大字段长度["+field.getMaxLen()+"]约束\n");
					row.setInsertable(false);
				}
				//step2:校验字段正则约束
				if( StringUtils.isEmpty(cell.getVmsg()) && StringUtils.isNotEmpty(value) && StringUtils.isNotEmpty(field.getRegex()) && !value.matches(field.getRegex())){
					cell.setVmsg(value+":不符合校验规则\n");
					row.setInsertable(false);
				}
				//step3:设值
				if(  StringUtils.isEmpty(cell.getVmsg()) && StringUtils.isNotBlank(cell.getValue())){
					if("String".equals(cell.getType())){
						clazz.getMethod("set"+Character.toUpperCase(cell.getName().charAt(0))+cell.getName().substring(1)
								, String.class).invoke(bean, cell.getValue());
					}else if("long".equals(cell.getType())){
						try {
							clazz.getMethod("set"+Character.toUpperCase(cell.getName().charAt(0))+cell.getName().substring(1)
									, long.class).invoke(bean, Long.valueOf(cell.getValue()).longValue());
						} catch (Exception e) {
							e.printStackTrace();
							cell.setVmsg(cell.getValue()+":请输入有效的整数！");// add by 徐广林
							row.setInsertable(false);//表示该行不能执行插入 
						}
					}else if("Date".equals(cell.getType())){
						try {
							clazz.getMethod("set"+Character.toUpperCase(cell.getName().charAt(0))+cell.getName().substring(1)
									, Timestamp.class).invoke(bean, new Timestamp(sdf.parse(cell.getValue()).getTime()));
						} catch (Exception e) {
							e.printStackTrace();
							cell.setVmsg(cell.getValue()+":日期格式错误！"); // add by 徐广林
							row.setInsertable(false);
						}
					}else if("float".equals(cell.getType())){
						try {
							clazz.getMethod("set"+Character.toUpperCase(cell.getName().charAt(0))+cell.getName().substring(1)
									, float.class).invoke(bean, Float.valueOf(cell.getValue()).floatValue());
						} catch (Exception e) {
							e.printStackTrace();
							cell.setVmsg(cell.getValue()+":请输入有效的数字！"); // add by 徐广林
							row.setInsertable(false);
						}
					}
				}
				//step4:自定义校验
				if(   validator != null){
					//如果该单元格已经出现错误校验信息 则不再校验自定义规则 // add by 徐广林
					if(StringUtils.isEmpty(cell.getVmsg())){
						validator.validate(cell, bean);
					}
					if(StringUtils.isNotEmpty(cell.getVmsg())){
						row.setInsertable(false);
					}
				}
				row.getCellMap().put(cell.getEnName(), cell);
			}
			row.setBean(bean);
			if(  validator != null){
				if(row.isInsertable())//如果该行已经出现错误校验信息 则不再校验行校验20171219
				    validator.rowValidate(row);
				if(StringUtils.isNotEmpty(row.getVmsg()))
					row.setInsertable(false);
			}
			rowlist.add(row);
		}
		return rowlist;
	}
	
}
